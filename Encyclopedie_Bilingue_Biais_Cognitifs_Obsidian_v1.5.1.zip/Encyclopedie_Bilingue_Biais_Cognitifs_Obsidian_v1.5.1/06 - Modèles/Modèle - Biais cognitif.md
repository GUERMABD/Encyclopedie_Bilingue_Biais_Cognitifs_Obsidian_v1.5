---
type: biais-cognitif
nom_fr: ""
nom_en: ""
statut_fr: "à vérifier"
traduction: "à vérifier"
present_liste_wikipedia_en_2026: false
present_codex_historique: false
date_verification: 2026-08-01
audit_scientifique: "non réalisé"
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex: []
aliases: []
---

# {{title}}

> **English:**

## Définition — français

## Definition — English

## Exemple

## Mécanisme probable

## Analyse critique

## Comment le limiter ?

## Classement

## Articles Wikipédia

## Sources et attribution
