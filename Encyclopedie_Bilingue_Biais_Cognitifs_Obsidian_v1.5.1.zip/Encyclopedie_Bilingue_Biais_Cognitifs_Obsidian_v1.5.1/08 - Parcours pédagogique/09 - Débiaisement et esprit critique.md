---
type: parcours-pedagogique
ordre: 9
version: 1.3.0
---

# Étape 9 — Débiaisement et esprit critique

## Objectif

Transformer la connaissance des biais en méthodes de travail concrètes, sans croire qu’il suffit de connaître leur nom pour les éviter.

## Fil conducteur

Les méthodes les plus utiles modifient le processus de décision : rechercher une alternative, utiliser une référence extérieure, chiffrer une prévision, séparer collecte et décision, ou demander une contradiction structurée.

## À lire dans cet ordre

1. [[Débiaisement]]
2. [[Métacognition]]
3. [[Biais de confirmation]]
4. [[Oubli de la fréquence de base]]
5. [[Biais d'excès de confiance]]
6. [[Biais de l'angle mort]]

## Mise en pratique

Avant une décision importante, écris : l’hypothèse principale, une explication concurrente, les données qui pourraient te faire changer d’avis et une estimation chiffrée de ton degré de confiance.

## À retenir

> Le débiaisement efficace repose davantage sur des procédures que sur la seule volonté d’être objectif.

---

[[08 - Groupe, influence et information|Étape précédente]] · [[15 - Parcours pédagogique|Terminer le parcours]]
