---
type: parcours-pedagogique
ordre: 5
version: 1.3.0
---

# Étape 5 — Décision et engagement

## Objectif

Comprendre pourquoi une décision peut rester difficile à corriger même lorsque la situation a changé.

## Fil conducteur

Les pertes, l’effort déjà investi, la responsabilité et la préférence pour l’option actuelle peuvent peser davantage que les bénéfices futurs réellement attendus.

## À lire dans cet ordre

1. [[Aversion à la perte]]
2. [[Biais du statu quo]]
3. [[Escalade d'engagement]]
4. [[Biais d'omission]]
5. [[Biais d'action]]
6. [[Compensation du risque]]

## Mise en pratique

Choisis un abonnement, un projet ou un objet que tu conserves. Imagine que tu ne le possèdes pas encore : l’achèterais-tu aujourd’hui au même prix et avec les informations actuelles ?

## À retenir

> Les coûts passés expliquent une décision, mais ne devraient pas déterminer seuls la décision future.

---

[[04 - Probabilités et jugement|Étape précédente]] · [[06 - Se juger soi-même|Étape suivante]]
