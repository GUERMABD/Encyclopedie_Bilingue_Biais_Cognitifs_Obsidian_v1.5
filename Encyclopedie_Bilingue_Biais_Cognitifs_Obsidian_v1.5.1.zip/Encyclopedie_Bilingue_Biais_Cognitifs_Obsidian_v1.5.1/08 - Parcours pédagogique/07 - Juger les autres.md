---
type: parcours-pedagogique
ordre: 7
version: 1.3.0
---

# Étape 7 — Juger les autres

## Objectif

Comprendre comment un trait visible ou une première impression influence l’interprétation globale d’une personne.

## Fil conducteur

Nous expliquons facilement les actes d’autrui par leur personnalité, alors que nous connaissons rarement toutes les contraintes de leur situation.

## À lire dans cet ordre

1. [[Effet de halo]]
2. [[Erreur fondamentale d'attribution]]
3. [[Effet acteur-observateur]]
4. [[Stéréotypage]]
5. [[Biais d'homogénéité de l'exogroupe]]
6. [[Biais d'attribution des traits]]

## Mise en pratique

Lorsque quelqu’un agit d’une manière qui t’agace, écris trois explications situationnelles plausibles avant de conclure à un trait de caractère.

## À retenir

> Un comportement observé ne suffit pas toujours à révéler une personnalité stable.

---

[[06 - Se juger soi-même|Étape précédente]] · [[08 - Groupe, influence et information|Étape suivante]]
