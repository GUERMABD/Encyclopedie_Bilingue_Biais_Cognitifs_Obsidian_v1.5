---
type: parcours-pedagogique
ordre: 6
version: 1.3.0
---

# Étape 6 — Se juger soi-même

## Objectif

Étudier les écarts entre l’image que l’on a de soi, ses prévisions et ses performances observables.

## Fil conducteur

Nous disposons de beaucoup d’informations sur nos intentions, mais moins sur la manière dont elles se traduisent réellement en résultats. Cette asymétrie favorise les évaluations trop indulgentes ou trop certaines.

## À lire dans cet ordre

1. [[Biais d'excès de confiance]]
2. [[Effet Dunning-Kruger]]
3. [[Biais d'optimisme]]
4. [[Biais de planification]]
5. [[Biais de l'angle mort]]
6. [[Biais d'autocomplaisance]]

## Mise en pratique

Avant une tâche, note une estimation chiffrée de sa durée et ton niveau de confiance. Compare ensuite avec le temps réel et conserve plusieurs observations.

## À retenir

> La calibration progresse lorsque les prévisions sont écrites puis comparées aux résultats.

---

[[05 - Décision et engagement|Étape précédente]] · [[07 - Juger les autres|Étape suivante]]
