---
type: parcours-pedagogique
ordre: 1
version: 1.3.0
---

# Étape 1 — Comprendre les biais sans les caricaturer

## Objectif

Comprendre qu’un biais n’est ni une faute morale ni une preuve d’irrationalité permanente. Il s’agit souvent d’un raccourci utile dans certains contextes, mais trompeur dans d’autres.

## Fil conducteur

Commence par distinguer les mécanismes cognitifs, les erreurs statistiques et les erreurs logiques. Cette distinction évite d’appeler « biais » tout désaccord, toute erreur ou tout comportement surprenant.

## À lire dans cet ordre

1. [[Heuristique]]
2. [[Rationalité limitée]]
3. [[Métacognition]]
4. [[Biais statistique]]
5. [[Distorsion cognitive]]
6. [[Sophisme]]

## Mise en pratique

Prends une décision récente qui s’est révélée imparfaite. Demande-toi si elle venait d’un manque d’information, d’un calcul erroné, d’un raisonnement logique invalide ou d’un raccourci mental raisonnable au moment des faits.

## À retenir

> Le mot *biais* décrit un mécanisme ou une tendance ; il ne permet pas, à lui seul, de juger une personne.

---

[[15 - Parcours pédagogique|Retour au parcours]] · [[02 - Perception et attention|Étape suivante]]
