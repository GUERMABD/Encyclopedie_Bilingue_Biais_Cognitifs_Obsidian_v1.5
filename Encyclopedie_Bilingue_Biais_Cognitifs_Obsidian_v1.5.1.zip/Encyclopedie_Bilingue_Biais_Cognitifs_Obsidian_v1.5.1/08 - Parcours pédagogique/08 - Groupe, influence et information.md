---
type: parcours-pedagogique
ordre: 8
version: 1.3.0
---

# Étape 8 — Groupe, influence et information

## Objectif

Voir comment les groupes, les autorités et la répétition transforment la circulation des opinions et des croyances.

## Fil conducteur

Une opinion peut sembler vraie parce qu’elle est répétée, partagée par le groupe ou portée par une personne légitime, sans que ces indices garantissent la qualité de la preuve.

## À lire dans cet ordre

1. [[Biais d'autorité]]
2. [[Pensée de groupe]]
3. [[Polarisation de groupe]]
4. [[Effet troisième personne]]
5. [[Biais de l'information partagée]]
6. [[Cascade de disponibilité]]

## Mise en pratique

Dans une réunion, demande à chacun de noter son avis avant la discussion. Compare ensuite les avis initiaux avec la décision collective et les informations qui n’ont pas été partagées.

## À retenir

> Le consensus est une information sociale utile, mais ce n’est pas une démonstration.

---

[[07 - Juger les autres|Étape précédente]] · [[09 - Débiaisement et esprit critique|Étape suivante]]
