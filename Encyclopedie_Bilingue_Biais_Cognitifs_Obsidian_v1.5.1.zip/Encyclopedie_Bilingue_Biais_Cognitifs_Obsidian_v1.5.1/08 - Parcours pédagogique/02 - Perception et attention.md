---
type: parcours-pedagogique
ordre: 2
version: 1.3.0
---

# Étape 2 — Perception et attention

## Objectif

Observer comment l’esprit sélectionne une petite partie de l’information disponible et interprète rapidement ce qu’il perçoit.

## Fil conducteur

Nous ne recevons pas passivement le monde : l’attention, les attentes et le premier cadre présenté orientent ce qui sera remarqué et la manière dont il sera compris.

## À lire dans cet ordre

1. [[Biais attentionnel]]
2. [[Ancrage]]
3. [[Heuristique de disponibilité]]
4. [[Effet de cadrage]]
5. [[Paréidolie]]
6. [[Biais de confirmation]]

## Mise en pratique

Lis deux titres décrivant le même résultat, l’un formulé en gains et l’autre en pertes. Note ta réaction immédiate avant de comparer les chiffres réels.

## À retenir

> Voir une information ne signifie pas la voir sans filtre.

---

[[01 - Comprendre les biais sans les caricaturer|Étape précédente]] · [[03 - Mémoire reconstructive|Étape suivante]]
