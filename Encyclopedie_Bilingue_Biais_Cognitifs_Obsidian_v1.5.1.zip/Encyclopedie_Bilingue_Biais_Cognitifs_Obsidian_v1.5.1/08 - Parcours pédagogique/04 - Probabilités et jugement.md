---
type: parcours-pedagogique
ordre: 4
version: 1.3.0
---

# Étape 4 — Probabilités et jugement

## Objectif

Apprendre à reconnaître les erreurs fréquentes lorsqu’il faut raisonner à partir de probabilités, de fréquences et de petits échantillons.

## Fil conducteur

Une histoire précise et frappante paraît souvent plus convaincante qu’une statistique générale, même lorsque la statistique est plus informative.

## À lire dans cet ordre

1. [[Oubli de la fréquence de base]]
2. [[Erreur de conjonction]]
3. [[Appariement des probabilités]]
4. [[Négligence des probabilités]]
5. [[Erreur d'appel à la probabilité]]
6. [[Erreur de la preuve anecdotique]]

## Mise en pratique

Face à un témoignage spectaculaire sur un produit ou un traitement, cherche d’abord le nombre total de cas, la fréquence habituelle du phénomène et la qualité du groupe de comparaison.

## À retenir

> Avant d’interpréter un cas particulier, il faut connaître la fréquence de base.

---

[[03 - Mémoire reconstructive|Étape précédente]] · [[05 - Décision et engagement|Étape suivante]]
