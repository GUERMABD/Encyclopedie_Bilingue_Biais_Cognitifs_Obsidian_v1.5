---
type: parcours-pedagogique
ordre: 3
version: 1.3.0
---

# Étape 3 — Mémoire reconstructive

## Objectif

Comprendre que la mémoire reconstruit le passé au lieu de le rejouer comme un enregistrement vidéo.

## Fil conducteur

Le souvenir dépend de l’encodage, des informations reçues ensuite, du contexte de rappel et de l’état présent. Une personne sincère peut donc produire un souvenir inexact.

## À lire dans cet ordre

1. [[Effet de désinformation]]
2. [[Confusion de la source]]
3. [[Biais rétrospectif]]
4. [[Effet de récence]]
5. [[Règle pic-fin]]
6. [[Effet de vérité illusoire]]

## Mise en pratique

Raconte de mémoire un événement vécu avec un proche, puis compare vos versions. Repère ce qui diffère : ordre, détails, causes ou intensité émotionnelle.

## À retenir

> La confiance dans un souvenir et son exactitude ne sont pas parfaitement équivalentes.

---

[[02 - Perception et attention|Étape précédente]] · [[04 - Probabilités et jugement|Étape suivante]]
