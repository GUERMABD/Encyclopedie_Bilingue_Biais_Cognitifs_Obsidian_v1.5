@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python n'est pas installe ou la commande py est indisponible.
  pause
  exit /b 1
)
py -m pip install -r requirements.txt
if errorlevel 1 pause & exit /b 1
py controler_integrite.py
if errorlevel 1 pause & exit /b 1
py controler_audit_scientifique.py
if errorlevel 1 pause & exit /b 1
py controler_exemples_pratiques.py
if errorlevel 1 pause & exit /b 1
py controler_encodage_et_liens.py
if errorlevel 1 pause & exit /b 1
py controler_ergonomie_parcours.py
pause
