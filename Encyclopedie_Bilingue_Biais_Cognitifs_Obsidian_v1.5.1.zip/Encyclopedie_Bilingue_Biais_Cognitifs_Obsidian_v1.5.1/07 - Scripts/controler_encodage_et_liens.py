from __future__ import annotations

import json
import re
import sys
import unicodedata
from pathlib import Path
from urllib.parse import unquote

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
TEXT_EXTENSIONS = {'.md', '.json', '.canvas', '.csv', '.py', '.bat', '.txt', '.yml', '.yaml'}
# Common traces of UTF-8 bytes decoded as CP437/Windows-1252. Written as escapes so
# this control script does not contain the suspicious glyphs it is searching for.
SUSPICIOUS_CHARS = tuple(chr(c) for c in (0x251C, 0x252C, 0x253C, 0xFFFD))
SUSPICIOUS_SEQUENCES = tuple(chr(c) for c in (0x00C3, 0x00C2)) + ('\u00e2\u20ac',)
WIKI_RE = re.compile(r'!?\[\[([^\]]+)\]\]')
MARKDOWN_RE = re.compile(r'(?<!!)\[[^\]]*\]\(([^)]+)\)')


def nfc(value: str) -> str:
    return unicodedata.normalize('NFC', value.replace('\\', '/').strip())


def has_suspicious_text(value: str) -> bool:
    return any(char in value for char in SUSPICIOUS_CHARS) or any(seq in value for seq in SUSPICIOUS_SEQUENCES)


all_files = [path for path in ROOT.rglob('*') if path.is_file()]
relative_map = {nfc(path.relative_to(ROOT).as_posix()).casefold(): path for path in all_files}
stem_map: dict[str, list[str]] = {}
name_map: dict[str, list[str]] = {}
for path in all_files:
    relative = nfc(path.relative_to(ROOT).as_posix())
    stem_map.setdefault(nfc(path.stem).casefold(), []).append(relative)
    name_map.setdefault(nfc(path.name).casefold(), []).append(relative)

encoding_errors: list[list[str]] = []
normalization_errors: list[list[str]] = []
mojibake_errors: list[list[str]] = []
broken_links: list[list[str]] = []
ambiguous_links: list[list[object]] = []
links_checked = 0

for path in ROOT.rglob('*'):
    relative = nfc(path.relative_to(ROOT).as_posix())
    original_relative = path.relative_to(ROOT).as_posix()
    if original_relative != relative:
        normalization_errors.append([original_relative, relative])
    if has_suspicious_text(original_relative):
        mojibake_errors.append(['nom', original_relative])
    if path.is_file() and path.suffix.lower() in TEXT_EXTENSIONS:
        try:
            content = path.read_bytes().decode('utf-8-sig')
        except UnicodeDecodeError as error:
            encoding_errors.append([relative, str(error)])
            continue
        if has_suspicious_text(content):
            mojibake_errors.append(['contenu', relative])


def resolve_target(target: str, source: Path, kind: str) -> list[str]:
    target = target.split('|', 1)[0].split('#', 1)[0].strip()
    target = unquote(target.strip('<>'))
    if not target or re.match(r'^[a-z]+://', target, re.I) or target.startswith(('mailto:', 'obsidian:')):
        return ['external-or-empty']
    target = nfc(target)
    candidates: list[str] = []

    exact_candidates = [target]
    if kind in {'wiki', 'canvas'}:
        # Always try note/canvas suffixes because a title can contain periods (v1.0, G. I. Joe, etc.).
        exact_candidates.extend([target + '.md', target + '.canvas'])
    for exact in exact_candidates:
        path = relative_map.get(exact.casefold())
        if path is not None:
            candidates.append(nfc(path.relative_to(ROOT).as_posix()))

    if kind == 'markdown':
        candidate_path = (source.parent / target).resolve()
        try:
            relative = nfc(candidate_path.relative_to(ROOT).as_posix())
        except ValueError:
            relative = ''
        if relative and relative.casefold() in relative_map:
            candidates.append(relative)

    if kind in {'wiki', 'canvas'} and '/' not in target:
        candidates.extend(stem_map.get(Path(target).name.casefold(), []))
        candidates.extend(name_map.get(Path(target).name.casefold(), []))

    return sorted(set(candidates))


for path in all_files:
    relative = nfc(path.relative_to(ROOT).as_posix())
    if path.suffix.lower() == '.md':
        try:
            content = path.read_text(encoding='utf-8-sig')
        except UnicodeDecodeError:
            continue
        for match in WIKI_RE.finditer(content):
            links_checked += 1
            target = match.group(1)
            candidates = resolve_target(target, path, 'wiki')
            if not candidates:
                broken_links.append([relative, target, 'wikilink'])
            elif len(candidates) > 1 and '/' not in target.split('|', 1)[0]:
                ambiguous_links.append([relative, target, candidates])
        for match in MARKDOWN_RE.finditer(content):
            links_checked += 1
            target = match.group(1)
            candidates = resolve_target(target, path, 'markdown')
            if not candidates:
                broken_links.append([relative, target, 'markdown'])
    elif path.suffix.lower() == '.canvas':
        try:
            canvas = json.loads(path.read_text(encoding='utf-8-sig'))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            encoding_errors.append([relative, f'Canvas invalide: {error}'])
            continue
        for node in canvas.get('nodes', []):
            if node.get('type') == 'file':
                links_checked += 1
                target = node.get('file', '')
                candidates = resolve_target(target, path, 'canvas')
                if not candidates:
                    broken_links.append([relative, target, 'canvas'])

result = {
    'root': str(ROOT),
    'files': len(all_files),
    'links_checked': links_checked,
    'encoding_error_count': len(encoding_errors),
    'normalization_error_count': len(normalization_errors),
    'mojibake_error_count': len(mojibake_errors),
    'broken_count': len(broken_links),
    'ambiguous_count': len(ambiguous_links),
    'encoding_errors': encoding_errors[:100],
    'normalization_errors': normalization_errors[:100],
    'mojibake_errors': mojibake_errors[:100],
    'broken': broken_links[:200],
    'ambiguous': ambiguous_links[:100],
}
print(json.dumps(result, ensure_ascii=False, indent=2))

if any((encoding_errors, normalization_errors, mojibake_errors, broken_links, ambiguous_links)):
    raise SystemExit(1)
