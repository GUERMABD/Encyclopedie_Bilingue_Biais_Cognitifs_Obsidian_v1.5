#!/usr/bin/env python3
"""Contrôle non destructif de la couverture et de la qualité minimale des exemples."""
from __future__ import annotations
from pathlib import Path
from collections import defaultdict
import json,re,sys

ROOT=Path(__file__).resolve().parents[1]
BIAS=ROOT/'01 - Fiches'/'Biais'
CONCEPTS=ROOT/'01 - Fiches'/'Concepts associés'
DATA=ROOT/'05 - Données'
errors=[]; warnings=[]; records=[]; normalized=defaultdict(list)

def inspect(path:Path, heading:str):
    text=path.read_text(encoding='utf-8')
    m=re.search(rf'^{re.escape(heading)}\s*\n(.*?)(?=\n## |\Z)',text,re.M|re.S)
    if not m:
        errors.append(f'{path.name} : section {heading} absente'); return
    body=m.group(1).strip()
    scenario=body.split('**Ce que cela illustre :**',1)[0].strip()
    words=re.findall(r"\b[\wÀ-ÿ'-]+\b",scenario)
    if len(words)<8: warnings.append(f'{path.name} : scénario très court ({len(words)} mots)')
    if '**Ce que cela illustre :**' not in body:
        errors.append(f'{path.name} : explication explicite absente')
    if re.search(r'\b(TODO|à compléter|à rédiger|exemple générique)\b',body,re.I):
        errors.append(f'{path.name} : texte provisoire dans l’exemple')
    key=re.sub(r'\W+',' ',scenario.casefold()).strip()
    normalized[key].append(path.name)
    records.append({'fichier':path.name,'mots_scenario':len(words),'caracteres':len(body)})

for p in sorted(BIAS.glob('*.md')): inspect(p,'## Exemple')
for p in sorted(CONCEPTS.glob('*.md')): inspect(p,'## Exemple concret')
for key,names in normalized.items():
    if key and len(names)>1: errors.append(f'Exemple dupliqué : {names}')

lengths=[r['mots_scenario'] for r in records]
result={
 'notes_controlees':len(records),
 'fiches_biais':len(list(BIAS.glob('*.md'))),
 'concepts_associes':len(list(CONCEPTS.glob('*.md'))),
 'minimum_mots_scenario':min(lengths) if lengths else 0,
 'maximum_mots_scenario':max(lengths) if lengths else 0,
 'moyenne_mots_scenario':round(sum(lengths)/len(lengths),1) if lengths else 0,
 'erreurs':errors,'avertissements':warnings,
}
(DATA/'controle_exemples_pratiques_v11.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
