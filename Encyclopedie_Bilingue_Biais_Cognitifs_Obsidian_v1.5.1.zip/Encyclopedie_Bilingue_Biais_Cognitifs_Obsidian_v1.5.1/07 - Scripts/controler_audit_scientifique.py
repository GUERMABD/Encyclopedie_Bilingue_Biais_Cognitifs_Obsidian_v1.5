#!/usr/bin/env python3
"""Contrôle local de cohérence des fiches scientifiquement auditées.

Ce contrôle vérifie la structure et la syntaxe bibliographique. La concordance
réelle auteur–titre–DOI reste un contrôle documentaire effectué auprès des
éditeurs ou bases bibliographiques.
"""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import json
import re
import sys

try:
    import yaml
except ImportError as exc:
    raise SystemExit("PyYAML est requis : py -m pip install pyyaml") from exc

ROOT = Path(__file__).resolve().parents[1]
BIAS_DIR = ROOT / "01 - Fiches" / "Biais"
DATA_DIR = ROOT / "05 - Données"
AUDITED = "initial critique avec références"
DOI_RE = re.compile(r"https?://doi\.org/(10\.\d{4,9}/[^\s]+)")

errors: list[str] = []
warnings: list[str] = []
dois: list[str] = []
audited_count = 0

for path in sorted(BIAS_DIR.glob("*.md")):
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        errors.append(f"{path.name} : frontmatter YAML absent")
        continue
    try:
        frontmatter = yaml.safe_load(text.split("---\n", 2)[1]) or {}
    except Exception as exc:  # noqa: BLE001
        errors.append(f"{path.name} : YAML invalide ({exc})")
        continue

    if frontmatter.get("audit_scientifique") != AUDITED:
        continue
    audited_count += 1

    for key in ("nature_scientifique", "robustesse"):
        if not str(frontmatter.get(key, "")).strip():
            errors.append(f"{path.name} : champ {key} absent")

    heading = "## Références scientifiques contrôlées"
    if heading not in text:
        errors.append(f"{path.name} : section de références absente")
        continue
    section = text.split(heading, 1)[1].split("## Sources et attribution", 1)[0]
    if not re.search(r"^- .+", section, flags=re.MULTILINE):
        errors.append(f"{path.name} : section de références vide")

    for placeholder in (
        "Fiche structurée à enrichir automatiquement",
        "À compléter automatiquement",
        "À documenter",
    ):
        if placeholder in text:
            errors.append(f"{path.name} : texte provisoire restant ({placeholder})")

    for match in DOI_RE.finditer(section):
        doi = match.group(1).rstrip(".,;")
        # Un DOI peut légitimement contenir des parenthèses.
        if doi.count("(") != doi.count(")"):
            warnings.append(f"{path.name} : parenthèses DOI déséquilibrées ({doi})")
        dois.append(doi)

stats = json.loads((DATA_DIR / "statistiques.json").read_text(encoding="utf-8"))
if audited_count != stats.get("total_audite"):
    errors.append(
        f"Nombre audité : {audited_count}, statistiques : {stats.get('total_audite')}"
    )

counts = Counter(dois)
result = {
    "fiches_auditees": audited_count,
    "doi_occurrences": len(dois),
    "doi_distincts": len(counts),
    "doi_reutilises": {doi: n for doi, n in counts.items() if n > 1},
    "erreurs": errors,
    "avertissements": warnings,
}
(DATA_DIR / "controle_bibliographique_v10.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps(result, ensure_ascii=False, indent=2))
sys.exit(1 if errors else 0)
