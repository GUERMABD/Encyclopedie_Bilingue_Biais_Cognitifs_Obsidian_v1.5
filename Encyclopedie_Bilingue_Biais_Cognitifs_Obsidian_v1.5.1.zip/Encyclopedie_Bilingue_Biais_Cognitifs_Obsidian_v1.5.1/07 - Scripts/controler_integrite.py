#!/usr/bin/env python3
"""Contrôle local non destructif de l'intégrité du vault."""
from __future__ import annotations
import csv, json, re, sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
import yaml

ROOT=Path(__file__).resolve().parents[1]
BIAS=ROOT/'01 - Fiches'/'Biais'
DATA=ROOT/'05 - Données'
errors=[]; warnings=[]; metrics={}

def err(msg): errors.append(msg)
def warn(msg): warnings.append(msg)

files=[p for p in ROOT.rglob('*') if p.is_file()]
rel={p.relative_to(ROOT).as_posix():p for p in files}
by_name=defaultdict(list); by_stem=defaultdict(list)
for p in files:
    by_name[p.name].append(p); by_stem[p.stem].append(p)

# YAML and semantic keys
metas=[]
for p in sorted(BIAS.glob('*.md')):
    text=p.read_text(encoding='utf-8')
    if not text.startswith('---\n') or '\n---\n' not in text[4:]:
        err(f'Frontmatter absent ou incomplet : {p.relative_to(ROOT)}'); continue
    try: meta=yaml.safe_load(text.split('---',2)[1]) or {}
    except Exception as e: err(f'YAML invalide : {p.relative_to(ROOT)} — {e}'); continue
    metas.append((p,meta))
    for key in ('nom_fr','nom_en','audit_scientifique'):
        if not meta.get(key): err(f'Champ {key} absent : {p.relative_to(ROOT)}')
    h1=re.search(r'^# (.+)$', text.split('\n---\n',1)[1], re.M)
    if not h1 or h1.group(1).strip()!=str(meta.get('nom_fr','')).strip():
        err(f'Titre H1 différent de nom_fr : {p.relative_to(ROOT)}')
    if meta.get('audit_scientifique')!='non réalisé':
        for key in ('nature_scientifique','robustesse'):
            if not str(meta.get(key,'')).strip():
                err(f'Champ {key} absent pour une fiche auditée : {p.relative_to(ROOT)}')
        if '## Références scientifiques contrôlées' not in text:
            err(f'Section de références contrôlées absente : {p.relative_to(ROOT)}')
        if re.search(r'\b(TODO|référence à ajouter|À RÉDIGER)\b', text, re.I):
            warn(f'Mention provisoire dans une fiche auditée : {p.relative_to(ROOT)}')
    aliases=meta.get('aliases') or []
    if isinstance(aliases,list) and any(a is None or (isinstance(a,str) and not a.strip()) for a in aliases):
        err(f'Alias vide : {p.relative_to(ROOT)}')

for key in ('nom_fr','nom_en'):
    groups=defaultdict(list)
    for p,m in metas: groups[str(m.get(key,'')).casefold()].append(p.name)
    for value,names in groups.items():
        if value and len(names)>1: err(f'Doublon {key} : {value} — {names}')

# JSON and Canvas
for p in [*ROOT.rglob('*.json'),*ROOT.rglob('*.canvas')]:
    try: data=json.loads(p.read_text(encoding='utf-8-sig'))
    except Exception as e: err(f'JSON invalide : {p.relative_to(ROOT)} — {e}'); continue
    if p.suffix=='.canvas':
        for node in data.get('nodes',[]):
            if node.get('type')=='file':
                target=node.get('file','')
                if target not in rel: err(f'Canvas vers fichier absent : {p.relative_to(ROOT)} → {target}')

# Wikilinks: exact path or unique basename/stem in vault
pat=re.compile(r'!?(?<!\\)\[\[([^\]]+)\]\]')
for p in ROOT.rglob('*.md'):
    text=p.read_text(encoding='utf-8')
    for raw in pat.findall(text):
        target=raw.split('|',1)[0].split('#',1)[0].strip()
        if not target or re.match(r'^[a-z]+://',target,re.I): continue
        normalized=target.replace('\\','/')
        known_ext=('.md','.canvas','.svg','.png','.jpg','.jpeg','.webp')
        has_known_ext=normalized.lower().endswith(known_ext)
        candidates=[normalized] + ([] if has_known_ext else [normalized+ext for ext in known_ext])
        if any(c in rel for c in candidates): continue
        name=Path(normalized).name
        stem=Path(normalized).stem if has_known_ext else name
        hits=by_name.get(name,[])+by_stem.get(stem,[])
        # unique object even if found through both maps
        hits=list(dict.fromkeys(hits))
        if len(hits)==1: continue
        if len(hits)>1: warn(f'Lien ambigu : {p.relative_to(ROOT)} → {target}')
        else: err(f'Lien absent : {p.relative_to(ROOT)} → {target}')

# Inventory and CSV synchronization
try: inv=json.loads((DATA/'inventaire_biais.json').read_text(encoding='utf-8'))
except Exception as e: inv=[]; err(f'Inventaire JSON illisible : {e}')
if len(inv)!=len(metas): err(f'Inventaire/fiches : {len(inv)} ≠ {len(metas)}')
inv_files={x.get('file_stem','')+'.md' for x in inv}
actual={p.name for p,_ in metas}
if inv_files!=actual:
    err(f'Inventaire désynchronisé : absents={sorted(actual-inv_files)}, superflus={sorted(inv_files-actual)}')
for fn in ('tableau_correspondance.csv','correspondance_fr_en.csv'):
    try:
        with (DATA/fn).open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f,delimiter=';'))
        if len(rows)!=len(metas): err(f'{fn} : {len(rows)} lignes au lieu de {len(metas)}')
        listed={r.get('fichier','') for r in rows}
        if listed!=actual: err(f'{fn} désynchronisé avec les fiches')
    except Exception as e: err(f'{fn} illisible : {e}')

# Windows filename restrictions
invalid=re.compile(r'[<>:"/\\|?*]|[ .]$')
reserved={'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}
for p in files:
    if invalid.search(p.name) or p.stem.upper() in reserved: err(f'Nom incompatible Windows : {p.relative_to(ROOT)}')


# Practical examples
example_count=0
for p,meta in metas:
    text=p.read_text(encoding='utf-8')
    match=re.search(r'^## Exemple\s*\n(.*?)(?=\n## |\Z)',text,re.M|re.S)
    if not match:
        err(f'Section Exemple absente : {p.relative_to(ROOT)}')
        continue
    example=match.group(1).strip()
    example_count+=1
    if len(re.findall(r"\b[\wÀ-ÿ'-]+\b",example))<18:
        warn(f'Exemple très court : {p.relative_to(ROOT)}')
    if '**Ce que cela illustre :**' not in example:
        err(f'Explication de l’exemple absente : {p.relative_to(ROOT)}')

concept_dir=ROOT/'01 - Fiches'/'Concepts associés'
concept_example_count=0
for p in sorted(concept_dir.glob('*.md')):
    text=p.read_text(encoding='utf-8')
    match=re.search(r'^## Exemple concret\s*\n(.*?)(?=\n## |\Z)',text,re.M|re.S)
    if not match:
        err(f'Exemple concret absent : {p.relative_to(ROOT)}')
        continue
    concept_example_count+=1
    if '**Ce que cela illustre :**' not in match.group(1):
        err(f'Explication du concept absente : {p.relative_to(ROOT)}')

statuses=Counter(m.get('audit_scientifique','') for _,m in metas)
metrics={
 'date_controle':datetime.now().astimezone().isoformat(timespec='seconds'),
 'fiches':len(metas),'fichiers':len(files),'statuts_audit':dict(statuses),
 'fiches_avec_exemple':example_count,'concepts_associes_avec_exemple':concept_example_count,
 'erreurs':len(errors),'avertissements':len(warnings)
}
result={'metrics':metrics,'errors':errors,'warnings':warnings}
(DATA/'dernier_controle_integrite.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
