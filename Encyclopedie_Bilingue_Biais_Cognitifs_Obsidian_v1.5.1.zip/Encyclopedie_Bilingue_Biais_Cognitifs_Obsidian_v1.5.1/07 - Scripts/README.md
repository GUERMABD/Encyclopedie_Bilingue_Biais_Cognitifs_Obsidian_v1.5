# Scripts de mise à jour

## Windows

1. Installer Python 3.11 ou plus récent.
2. Double-cliquer sur `Lancer la mise à jour.bat`.
3. La première exécution installe `requests`, `beautifulsoup4` et `markdownify`.
4. Par défaut, le script télécharge l'image principale de chaque article.

## Options

```powershell
py mettre_a_jour_wikipedia.py --images none
py mettre_a_jour_wikipedia.py --images lead
py mettre_a_jour_wikipedia.py --images all
py mettre_a_jour_wikipedia.py --limit 10
```

`--images all` peut créer un dossier très volumineux. Les fichiers sont placés dans `03 - Médias/Illustrations` et leurs attributions dans `04 - Sources et licences/Médias`.

## Précaution

Une mise à jour automatique importe la structure de Wikipédia, mais elle ne remplace pas l'audit critique. Les articles peuvent être incomplets, déséquilibrés ou employer des traductions différentes.

## Contrôle d’intégrité

Double-cliquer sur `Lancer le contrôle.bat` pour vérifier les YAML, JSON, Canvas, liens internes, inventaires et doublons de noms. Le résultat est enregistré dans `05 - Données/dernier_controle_integrite.json`.

Le contrôle v1.2 vérifie aussi l’encodage UTF-8 des noms et contenus, ainsi que les liens Wikilink, médias et Canvas.


## Contrôle ergonomique v1.3

`controler_ergonomie_parcours.py` vérifie le parcours pédagogique, les dimensions minimales des cartes Canvas, les fichiers liés et l’absence d’un dossier `Illustrations` vide.
