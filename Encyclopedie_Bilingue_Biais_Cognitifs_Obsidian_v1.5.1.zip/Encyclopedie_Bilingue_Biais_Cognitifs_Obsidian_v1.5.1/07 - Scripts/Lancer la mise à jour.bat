@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -m pip install -r requirements.txt
set /p WIKIMEDIA_CONTACT=Contact pour le User-Agent Wikimedia (email ou page utilisateur, facultatif) : 
if "%WIKIMEDIA_CONTACT%"=="" (
  py mettre_a_jour_wikipedia.py --images lead
) else (
  py mettre_a_jour_wikipedia.py --images lead --contact "%WIKIMEDIA_CONTACT%"
)
pause
