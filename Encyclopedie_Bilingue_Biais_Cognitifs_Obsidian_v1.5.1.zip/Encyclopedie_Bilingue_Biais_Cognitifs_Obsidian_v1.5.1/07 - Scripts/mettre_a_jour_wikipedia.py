#!/usr/bin/env python3
"""Importe Wikipédia sans écraser le contenu critique du vault.

Le script résout la correspondance FR via Wikidata, enregistre les révisions,
remplace uniquement un bloc délimité et conserve une attribution séparée pour
chaque média Wikimedia Commons.
"""
from __future__ import annotations

import argparse
import html
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import requests
from bs4 import BeautifulSoup
from markdownify import markdownify as to_markdown
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / '05 - Données' / 'inventaire_biais.json'
BIAS_DIR = ROOT / '01 - Fiches' / 'Biais'
MEDIA_DIR = ROOT / '03 - Médias' / 'Illustrations'
ATTR_DIR = ROOT / '04 - Sources et licences' / 'Médias'
CACHE_FILE = ROOT / '05 - Données' / 'cache_revisions.json'
LOG_FILE = ROOT / '05 - Données' / 'journal_mise_a_jour.json'
START = '<!-- WIKIPEDIA_IMPORT_START -->'
END = '<!-- WIKIPEDIA_IMPORT_END -->'
TEXT_LICENSE = 'CC BY-SA 4.0 — vérifier aussi le pied de page et l’historique de la page'


def make_session(contact: str) -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=4,
        connect=4,
        read=4,
        backoff_factor=1.0,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset({'GET'}),
        respect_retry_after_header=True,
    )
    session.mount('https://', HTTPAdapter(max_retries=retry))
    session.headers.update({
        'User-Agent': f'Obsidian-Cognitive-Bias-Encyclopedia/0.3 ({contact})',
        'Accept-Language': 'fr,en;q=0.8',
    })
    return session


def api(session: requests.Session, host: str, params: dict) -> dict:
    response = session.get(
        f'https://{host}/w/api.php',
        params={'format': 'json', 'formatversion': 2, 'maxlag': 5, **params},
        timeout=60,
    )
    response.raise_for_status()
    data = response.json()
    if 'error' in data:
        raise RuntimeError(f'{host}: {data["error"]}')
    return data


def resolve_page(session: requests.Session, lang: str, title: str) -> dict | None:
    data = api(session, f'{lang}.wikipedia.org', {
        'action': 'query',
        'redirects': 1,
        'converttitles': 1,
        'prop': 'info|extracts|pageprops|pageimages|revisions',
        'inprop': 'url',
        'exintro': 1,
        'explaintext': 1,
        'piprop': 'name|original',
        'rvprop': 'ids|timestamp',
        'rvlimit': 1,
        'titles': title,
    })
    pages = data.get('query', {}).get('pages', [])
    if not pages or pages[0].get('missing'):
        return None
    page = pages[0]
    revision = (page.get('revisions') or [{}])[0]
    return {
        'title': page['title'],
        'url': page.get('fullurl', ''),
        'summary': page.get('extract', '').strip(),
        'revid': revision.get('revid'),
        'revision_timestamp': revision.get('timestamp'),
        'qid': page.get('pageprops', {}).get('wikibase_item'),
        'lead_file': page.get('pageimage'),
    }


def french_sitelink(session: requests.Session, qid: str | None) -> str | None:
    if not qid:
        return None
    data = api(session, 'www.wikidata.org', {
        'action': 'wbgetentities',
        'ids': qid,
        'props': 'sitelinks',
        'sitefilter': 'frwiki',
    })
    entity = data.get('entities', {}).get(qid, {})
    return entity.get('sitelinks', {}).get('frwiki', {}).get('title')


def parse_article(session: requests.Session, lang: str, title: str) -> dict:
    data = api(session, f'{lang}.wikipedia.org', {
        'action': 'parse',
        'page': title,
        'redirects': 1,
        'prop': 'text|images|revid|displaytitle',
        'disableeditsection': 1,
        'disabletoc': 1,
    })['parse']
    return {
        'html': data.get('text', ''),
        'images': data.get('images', []),
        'revid': data.get('revid'),
        'displaytitle': BeautifulSoup(html.unescape(data.get('displaytitle', title)), 'html.parser').get_text(' ', strip=True),
    }


def clean_markdown(raw_html: str) -> str:
    soup = BeautifulSoup(raw_html, 'html.parser')
    for selector in [
        'script', 'style', 'link', 'meta', 'noscript', '.mw-editsection', '.navbox',
        '.vertical-navbox', '.metadata', '.ambox', '.sistersitebox', '.printfooter',
        '.mw-references-wrap', 'sup.reference', 'img', 'figure', '.gallery',
    ]:
        for tag in soup.select(selector):
            tag.decompose()
    for tag in soup.find_all(True):
        for attr in list(tag.attrs):
            if attr not in {'href', 'title', 'colspan', 'rowspan'}:
                del tag.attrs[attr]
    text = to_markdown(str(soup), heading_style='ATX', bullets='-')
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r'(?m)^\s*\[modifier(?: \| modifier le code)?\]\([^)]*\)\s*$', '', text)
    return text.strip()


def replace_import_block(note: str, block: str) -> str:
    wrapped = f'{START}\n{block.rstrip()}\n{END}'
    pattern = re.compile(re.escape(START) + r'.*?' + re.escape(END), re.S)
    if pattern.search(note):
        return pattern.sub(wrapped, note, count=1)
    insertion = '\n\n## Import Wikipédia\n\n' + wrapped + '\n'
    marker = '\n## Sources et attribution\n'
    if marker in note:
        return note.replace(marker, insertion + marker, 1)
    return note.rstrip() + insertion


def commons_info(session: requests.Session, filename: str) -> dict | None:
    title = filename if filename.startswith('File:') else 'File:' + filename
    data = api(session, 'commons.wikimedia.org', {
        'action': 'query',
        'prop': 'imageinfo',
        'iiprop': 'url|extmetadata|mime|size|timestamp',
        'titles': title,
    })
    pages = data.get('query', {}).get('pages', [])
    if not pages or pages[0].get('missing'):
        return None
    info = (pages[0].get('imageinfo') or [{}])[0]
    meta = info.get('extmetadata', {})

    def field(name: str) -> str:
        value = meta.get(name, {}).get('value', '')
        return BeautifulSoup(value, 'html.parser').get_text(' ', strip=True)

    return {
        'canonical_title': pages[0].get('title', title),
        'url': info.get('url'),
        'description_url': info.get('descriptionurl'),
        'mime': info.get('mime'),
        'size': info.get('size'),
        'timestamp': info.get('timestamp'),
        'artist': field('Artist'),
        'credit': field('Credit'),
        'license': field('LicenseShortName'),
        'license_url': field('LicenseUrl'),
        'usage_terms': field('UsageTerms'),
    }


def safe_filename(title: str) -> str:
    name = title.split(':', 1)[-1]
    name = re.sub(r'[<>:"/\\|?*]', '_', name).strip().rstrip('.')
    return name or 'media'


def download_media(session: requests.Session, file_titles: list[str], stem: str) -> list[dict]:
    results = []
    target_dir = MEDIA_DIR / stem
    target_dir.mkdir(parents=True, exist_ok=True)
    ATTR_DIR.mkdir(parents=True, exist_ok=True)
    seen = set()
    for title in file_titles:
        if not title or title.casefold() in seen:
            continue
        seen.add(title.casefold())
        metadata = commons_info(session, title)
        if not metadata or not metadata.get('url'):
            continue
        name = safe_filename(metadata['canonical_title'])
        target = target_dir / name
        response = session.get(metadata['url'], timeout=120)
        response.raise_for_status()
        if len(response.content) > 30_000_000:
            continue
        target.write_bytes(response.content)
        attr = [
            f'# Attribution — {name}', '',
            f'- Utilisé dans : [[{stem}]]',
            f'- Titre Wikimedia : {metadata["canonical_title"]}',
            f'- Page de description : {metadata.get("description_url") or "à vérifier"}',
            f'- Auteur : {metadata.get("artist") or "à vérifier"}',
            f'- Crédit : {metadata.get("credit") or "à vérifier"}',
            f'- Licence : {metadata.get("license") or "à vérifier"}',
            f'- URL de licence : {metadata.get("license_url") or "à vérifier"}',
            f'- Date du fichier : {metadata.get("timestamp") or "à vérifier"}',
            '- Modification locale : aucune modification du fichier ; copie locale uniquement.', '',
        ]
        (ATTR_DIR / f'{stem} - {name}.md').write_text('\n'.join(attr), encoding='utf-8')
        results.append({'file': str(target.relative_to(ROOT)), **metadata})
    return results


def article_block(label: str, page: dict, parsed: dict, article_md: str, retrieved: str) -> str:
    return '\n'.join([
        f'### {label}', '',
        f'- Titre résolu : **{page["title"]}**',
        f'- URL : {page["url"]}',
        f'- Révision : `{parsed.get("revid") or page.get("revid")}`',
        f'- Date de révision : `{page.get("revision_timestamp") or "inconnue"}`',
        f'- Date de récupération : `{retrieved}`',
        f'- Licence du texte : {TEXT_LICENSE}',
        '- Transformation : extraction du contenu encyclopédique, suppression des éléments de navigation et conversion HTML → Markdown.', '',
        '#### Résumé', '',
        page.get('summary') or '*Résumé indisponible.*', '',
        '#### Contenu importé', '',
        article_md or '*Contenu indisponible.*',
    ])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--images', choices=('none', 'lead', 'all'), default='lead')
    parser.add_argument('--delay', type=float, default=0.5)
    parser.add_argument('--limit', type=int, default=0)
    parser.add_argument('--contact', default=os.getenv('WIKIMEDIA_CONTACT', 'contact-non-renseigne'))
    args = parser.parse_args()

    if args.contact == 'contact-non-renseigne':
        print('Avertissement : renseigner --contact ou WIKIMEDIA_CONTACT améliore la conformité du User-Agent.', file=sys.stderr)

    session = make_session(args.contact)
    entries = json.loads(DATA.read_text(encoding='utf-8'))
    cache = json.loads(CACHE_FILE.read_text(encoding='utf-8')) if CACHE_FILE.exists() else {}
    journal = {'started_at': datetime.now(timezone.utc).isoformat(), 'updated': [], 'errors': []}
    count = 0

    for entry in entries:
        if args.limit and count >= args.limit:
            break
        stem = entry['file_stem']
        note_path = BIAS_DIR / f'{stem}.md'
        try:
            en = resolve_page(session, 'en', entry['name_en'])
            if not en:
                raise RuntimeError(f'page anglaise introuvable : {entry["name_en"]}')
            en_parsed = parse_article(session, 'en', en['title'])
            retrieved = datetime.now(timezone.utc).isoformat()
            blocks = [article_block('English', en, en_parsed, clean_markdown(en_parsed['html']), retrieved)]

            fr_title = french_sitelink(session, en.get('qid'))
            fr = resolve_page(session, 'fr', fr_title) if fr_title else None
            fr_parsed = None
            if fr:
                fr_parsed = parse_article(session, 'fr', fr['title'])
                blocks.insert(0, article_block('Français', fr, fr_parsed, clean_markdown(fr_parsed['html']), retrieved))
            else:
                blocks.insert(0, '### Français\n\nAucun sitelink `frwiki` n’est associé à l’élément Wikidata de la page anglaise au moment de la récupération.')

            media_titles: list[str] = []
            if args.images == 'lead':
                lead = (fr or en).get('lead_file')
                if lead:
                    media_titles = [lead]
            elif args.images == 'all':
                media_titles = list(dict.fromkeys((fr_parsed or {}).get('images', []) + en_parsed.get('images', [])))
            media = download_media(session, media_titles, stem) if media_titles else []

            block = '\n\n'.join(blocks)
            if media:
                block += '\n\n### Médias locaux\n\n' + '\n'.join(f'- `{m["file"]}`' for m in media)
            note = note_path.read_text(encoding='utf-8')
            note_path.write_text(replace_import_block(note, block), encoding='utf-8')

            revisions = {
                'en': {'title': en['title'], 'revid': en_parsed.get('revid') or en.get('revid'), 'timestamp': en.get('revision_timestamp')},
                'fr': ({'title': fr['title'], 'revid': fr_parsed.get('revid') or fr.get('revid'), 'timestamp': fr.get('revision_timestamp')} if fr else None),
                'retrieved_at': retrieved,
            }
            cache[stem] = revisions
            journal['updated'].append({'stem': stem, **revisions, 'media_count': len(media)})
            count += 1
            print(f'[{count}] {entry["name_fr"]}')
        except Exception as exc:  # continue rather than losing a long batch
            journal['errors'].append({'stem': stem, 'error': str(exc)})
            print(f'[ERREUR] {stem}: {exc}', file=sys.stderr)
        CACHE_FILE.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')
        LOG_FILE.write_text(json.dumps(journal, ensure_ascii=False, indent=2), encoding='utf-8')
        time.sleep(max(args.delay, 0.1))

    journal['finished_at'] = datetime.now(timezone.utc).isoformat()
    LOG_FILE.write_text(json.dumps(journal, ensure_ascii=False, indent=2), encoding='utf-8')
    return 0 if not journal['errors'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
