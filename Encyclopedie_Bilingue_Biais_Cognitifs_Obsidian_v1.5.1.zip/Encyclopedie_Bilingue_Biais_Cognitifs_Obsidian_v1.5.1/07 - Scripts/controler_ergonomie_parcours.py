from pathlib import Path
import json, sys

ROOT = Path(__file__).resolve().parents[1]
errors=[]
warnings=[]

# No empty Illustrations directory
ill=ROOT/'03 - Médias'/'Illustrations'
if ill.exists() and not any(ill.iterdir()):
    errors.append('Le dossier Illustrations existe mais il est vide.')

# Route notes
route=ROOT/'08 - Parcours pédagogique'
notes=sorted(route.glob('*.md')) if route.exists() else []
if len(notes)!=9:
    errors.append(f'Le parcours doit contenir 9 étapes, trouvé : {len(notes)}.')

# Canvas sizes and validity
for cp in (ROOT/'02 - Cartes mentales').glob('*.canvas'):
    try:
        data=json.loads(cp.read_text(encoding='utf-8'))
    except Exception as exc:
        errors.append(f'{cp.name}: JSON invalide: {exc}')
        continue
    for node in data.get('nodes',[]):
        if node.get('type')=='file':
            if node.get('width',0)<500 or node.get('height',0)<170:
                warnings.append(f'{cp.name}: carte trop petite {node.get("id")}.')
            target=ROOT/node.get('file','')
            if not target.exists():
                errors.append(f'{cp.name}: fichier absent {node.get("file")}.')

    # Detect actual rectangular overlaps between nodes.
    ns=data.get('nodes',[])
    for i,a in enumerate(ns):
        for b in ns[i+1:]:
            ax1,ay1=a.get('x',0),a.get('y',0)
            ax2,ay2=ax1+a.get('width',0),ay1+a.get('height',0)
            bx1,by1=b.get('x',0),b.get('y',0)
            bx2,by2=bx1+b.get('width',0),by1+b.get('height',0)
            if min(ax2,bx2)>max(ax1,bx1) and min(ay2,by2)>max(ay1,by1):
                errors.append(f'{cp.name}: chevauchement entre {a.get("id")} et {b.get("id")}.')

result={'etapes':len(notes),'cartes_canvas':len(list((ROOT/'02 - Cartes mentales').glob('*.canvas'))),'erreurs':errors,'avertissements':warnings}
out=ROOT/'05 - Données'/'controle_ergonomie_parcours_v13.json'
out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
