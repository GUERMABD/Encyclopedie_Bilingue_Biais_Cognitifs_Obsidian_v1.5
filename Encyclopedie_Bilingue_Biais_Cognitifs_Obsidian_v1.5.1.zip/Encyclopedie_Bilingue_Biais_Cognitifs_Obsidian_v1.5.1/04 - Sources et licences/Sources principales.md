# Sources principales

- Wikipédia anglais — *List of cognitive biases*, révision `1364507766`.
- Wikipédia français — *Biais cognitif*, révision `237491828`.
- Dimara et al. (2020), *A Task-Based Taxonomy of Cognitive Biases for Information Visualization*, DOI `10.1109/TVCG.2018.2872577`.
- Wikimedia Commons — *Cognitive bias codex en.svg*, 188 libellés, fichier daté du 6 juin 2018.
- Wikimedia Commons — version française du Cognitive Bias Codex, corrections françaises du 8 février 2024.
- Conditions d’utilisation Wikimedia Foundation, section relative à la réutilisation et à l’attribution.

Date de contrôle : 2026-08-01.
