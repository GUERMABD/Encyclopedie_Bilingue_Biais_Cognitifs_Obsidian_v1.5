# Licence et réutilisation

Les synthèses originales et analyses du vault sont distinctes des contenus importés.

Les textes importés depuis Wikipédia doivent conserver :

- le titre et l’URL de la page source ;
- le numéro et la date de révision ;
- la mention de la licence applicable ;
- l’indication des transformations réalisées, notamment la conversion en Markdown.

Les images et autres médias sont vérifiés individuellement : leur licence peut différer de celle du texte. Une fiche d’attribution séparée est conservée pour chaque fichier téléchargé.

Ne pas redistribuer un export contenant des imports Wikipédia ou Wikimedia sans conserver ces informations et les obligations de partage dans les mêmes conditions lorsque la licence l’exige.
