# Versions des sources contrôlées

| Source | Version contrôlée | Usage dans le vault |
|---|---:|---|
| Wikipédia anglais — List of cognitive biases | Révision `1364507766`, page touchée le 2026-08-01 à 20:09:11 UTC | Inventaire et classement par tâches / « flavors » |
| Wikipédia français — Biais cognitif | Révision `237491828`, page touchée le 2026-07-31 à 18:52:45 UTC | Terminologie et liste française générale |
| Dimara et al. | DOI `10.1109/TVCG.2018.2872577` | Source scientifique de la taxonomie par tâches ; 154 biais, sept catégories |
| Cognitive bias codex en.svg | Fichier daté du 2018-06-06 | 188 libellés historiques |
| Cognitive Bias Codex français | Révision avec corrections françaises du 2024-02-08 | Traductions et visualisation historique |

## Règle de mise à jour

Toute révision future doit enregistrer les nouveaux identifiants de révision avant de modifier l’inventaire. Les différences doivent être examinées ; le simple remplacement silencieux des données est interdit.
