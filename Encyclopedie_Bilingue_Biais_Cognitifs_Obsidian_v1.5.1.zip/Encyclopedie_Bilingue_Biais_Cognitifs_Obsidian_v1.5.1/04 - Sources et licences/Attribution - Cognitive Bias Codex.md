# Attribution — Cognitive Bias Codex

## Version anglaise

- Titre : Cognitive bias codex en.svg
- Conception : John Manoogian III
- Catégories et descriptions : Buster Benson
- Implémentation SVG : TilmannR
- Licence : CC BY-SA 4.0
- Source : https://commons.wikimedia.org/wiki/File:Cognitive_bias_codex_en.svg

## Version française

- Titre : The Cognitive Bias Codex (French) - John Manoogian III (jm3).svg
- Traduction française indiquée sur Wikimedia Commons : Albert Moukheiber et Mariam Chammat ; corrections ultérieures par les contributeurs Wikimedia
- Licence : CC BY-SA 4.0
- Source : https://commons.wikimedia.org/wiki/File:The_Cognitive_Bias_Codex_(French)_-_John_Manoogian_III_(jm3).svg
- Version consultée : corrections françaises du 8 février 2024

## Réutilisation

Toute redistribution ou adaptation doit conserver l’attribution, indiquer les modifications et respecter la licence CC BY-SA 4.0.

Date de récupération : 2026-08-01
