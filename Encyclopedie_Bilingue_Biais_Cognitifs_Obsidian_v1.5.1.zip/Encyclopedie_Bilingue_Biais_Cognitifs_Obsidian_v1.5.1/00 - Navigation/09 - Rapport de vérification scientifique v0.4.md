# Rapport de vérification scientifique v0.4

## Objet

Troisième passe de validation scientifique et terminologique. Le travail porte en priorité sur la mémoire, l’attention et plusieurs effets de décision disposant de références fondatrices ou de synthèses identifiables. Les fiches restent volontairement concises.

## Résultat quantitatif

- Fiches totales : **268**.
- Fiches auditées avant cette passe : **56**.
- Fiches nouvellement auditées : **61**.
- Fiches disposant désormais d’un audit scientifique initial : **117**.
- Fiches restant à auditer : **151**.

## Corrections majeures

1. **Effet Zeigarnik** : la supériorité générale du rappel des tâches interrompues n’est plus présentée comme établie ; distinction avec l’effet Ovsiankina.
2. **Effet Google** : reclassé comme adaptation de mémoire transactive, sans conclure à une détérioration générale de la mémoire.
3. **Règle pic-fin et négligence de la durée** : reformulées comme effets moyens dont le poids varie selon les expériences.
4. **Effets de position sérielle** : primauté, récence et position sérielle reliées sans les présenter comme quatre lois indépendantes.
5. **Faux souvenirs** : distinction entre contenu erroné, suggestion, désinformation et erreur de source.
6. **Biais attentionnel** : reclassé comme famille de mécanismes ; un score isolé n’est pas un diagnostic.
7. **Excès de confiance** : distinction entre surestimation, surplacement et surprécision.
8. **Biais du présent et rabais hyperbolique** : distinction entre tendance empirique et modèle d’actualisation.
9. **Désirabilité sociale** : reclassée comme biais de réponse et de mesure.
10. **Insensibilité à la taille de l’échantillon** : explicitée comme erreur d’intuition statistique.
11. **Références bibliographiques** : correction de cinq associations ou notices incomplètes entre DOI et métadonnées bibliographiques, notamment pour l’effet Zeigarnik, l’effet de modalité, l’effet inter-races, l’effet von Restorff et la méta-analyse pic-fin.
12. **Règle pic-fin et négligence de la durée** : prise en compte du corrigendum de 2024, dont les conclusions substantielles restent globalement inchangées.

## Fiches traitées

- Amnésie infantile
- Appariement des probabilités
- Biais additif
- Biais attentionnel
- Biais d'affaiblissement de l'affect
- Biais d'automatisation
- Biais d'excès de confiance
- Biais de soutien du choix
- Biais du présent
- Biais mnésique lié à l'humeur
- Confusion de la source
- Cryptomnésie
- Cécité à la répétition
- Distraction
- Désirabilité sociale
- Effet Barnum
- Effet Google
- Effet IKEA
- Effet Zeigarnik
- Effet d'espacement
- Effet d'espacement temporel
- Effet d'humour
- Effet d'influence persistante
- Effet de disposition
- Effet de dénomination
- Effet de désinformation
- Effet de génération d'information
- Effet de la modalité
- Effet de position dans une série
- Effet de position sérielle
- Effet de positivité
- Effet de primauté
- Effet de profondeur du traitement
- Effet de projecteur
- Effet de récence
- Effet de référence à soi
- Effet de supériorité de l'image
- Effet de verbatim
- Effet esthétique-utilisabilité
- Effet inter-races
- Effet pom-pom girl
- Effet test
- Effet von Restorff
- Effet « troisième personne »
- Erreur d'attribution de la source
- Extension des limites
- Faux souvenir
- Illusion de profondeur explicative
- Illusion de transparence
- Illusion monétaire
- Inhibition de la mémoire
- Insensibilité à la taille de l’échantillon
- Mot sur le bout de la langue
- Négligence de la durée
- Persistance mnésique
- Pic de réminiscence
- Rabais hyperbolique
- Règle pic-fin
- Rétrospective de la vie en rose
- Suggestibilité
- Échec du rappel sans indice

## Portée de l’audit

Le statut « initial critique avec références » signifie que la définition, la nature du concept, ses limites principales et au moins une référence identifiable ont été contrôlées. La concordance entre auteurs, titre, revue, année, pagination et DOI est vérifiée lorsque ces éléments sont disponibles. Il ne correspond pas à une revue systématique exhaustive de l’ensemble de la littérature.

## Contrôle bibliographique

- 136 occurrences de DOI contrôlées syntaxiquement dans les 117 fiches auditées ;
- 122 DOI distincts ;
- les DOI réutilisés correspondent à des références communes à plusieurs phénomènes proches ;
- aucune section de références vide et aucun texte provisoire dans une fiche marquée comme auditée ;
- les correspondances auteur–titre–revue–pagination–DOI des références corrigées ont été vérifiées auprès des notices des éditeurs ou de PubMed.

## Cohérence technique

Après modification, l’inventaire JSON, les deux CSV et les statistiques ont été régénérés depuis les mêmes données. Deux contrôles locaux sont fournis : `controler_integrite.py` et `controler_audit_scientifique.py`. Leur dernière exécution ne relève aucune erreur ni aucun avertissement.
