---
type: rapport-controle
version: 1.3.0
date: 2026-08-02
---

# Améliorations ergonomiques et parcours — v1.3

## Dossier Médias

Le dossier vide `03 - Médias/Illustrations` a été retiré. Le script de mise à jour le recrée automatiquement uniquement lorsqu’un média est réellement téléchargé.

## Cartes mentales

Les cartes générales ont été réorganisées :

- largeur et hauteur des fiches augmentées ;
- espaces plus importants entre les cartes ;
- catégories disposées en blocs séparés ;
- absence de chevauchement entre les zones principales.

## Parcours pédagogique

Un parcours linéaire en neuf étapes a été ajouté :

1. comprendre les biais ;
2. perception et attention ;
3. mémoire reconstructive ;
4. probabilités et jugement ;
5. décision et engagement ;
6. se juger soi-même ;
7. juger les autres ;
8. groupe, influence et information ;
9. débiaisement et esprit critique.

Chaque étape contient un objectif, un ordre de lecture, une mise en pratique et une idée à retenir.
