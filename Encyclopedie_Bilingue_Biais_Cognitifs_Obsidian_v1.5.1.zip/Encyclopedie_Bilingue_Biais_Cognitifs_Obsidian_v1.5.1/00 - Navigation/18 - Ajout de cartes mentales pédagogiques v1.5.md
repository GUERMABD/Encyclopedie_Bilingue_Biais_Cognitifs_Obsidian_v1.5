---
type: rapport
version: 1.5.0
date_verification: 2026-08-02
---

# Ajout de cartes mentales pédagogiques v1.5

## Objectif

Ajouter des cartes plus lisibles et plus ludiques, inspirées d’une présentation de type **grandes branches + sous-notes explicatives**, sans supprimer les cartes d’inventaire déjà présentes.

## Modifications réalisées

- ajout de **4 nouveaux fichiers `.canvas`** ;
- conservation des **3 cartes existantes** ;
- ajout d’une page de navigation dédiée ;
- mise à jour de la page d’accueil et du parcours pédagogique.

## Nouvelles cartes

1. Fondamentaux des biais cognitifs
2. 20 biais du quotidien
3. Comment repérer un biais ?
4. Débiaisement pratique

## Résultat attendu

- meilleure lisibilité ;
- accès plus pédagogique aux notions ;
- navigation plus agréable pour une découverte progressive ;
- meilleure réutilisation à l’oral, en révision ou en formation.
