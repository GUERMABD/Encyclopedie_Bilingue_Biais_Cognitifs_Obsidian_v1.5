# Rapport de vérification scientifique v0.5

## Objet

Quatrième passe de validation scientifique et terminologique, centrée sur les biais sociaux, les attributions, le jugement probabiliste et plusieurs effets de décision. Les fiches restent volontairement concises.

## Résultat quantitatif

- Concepts distincts : **267**.
- Fiches auditées avant cette passe : **117**.
- Fiches nouvellement auditées : **50**.
- Fiches disposant désormais d’un audit scientifique initial : **167**.
- Fiches restant à auditer : **100**.
- Doublon fusionné : **Effet Lac Wobegon → Supériorité illusoire**.

## Corrections majeures

1. **Effet Lac Wobegon** : supprimé comme fiche indépendante et conservé comme alias de la supériorité illusoire.
2. **Erreur ultime d’attribution** : le soutien au modèle complet est qualifié de limité et hétérogène.
3. **Effet boomerang** : suppression de la généralisation selon laquelle les corrections renforceraient fréquemment les croyances erronées.
4. **Compensation du risque** : distinction entre compensation absente, partielle et complète ; aucune annulation automatique des mesures de sécurité.
5. **Biais d’autorité** : distingué de l’obéissance et de l’usage rationnel d’une expertise pertinente.
6. **Illusion de fréquence** : classée comme étiquette populaire combinant attention, disponibilité et confirmation.
7. **Validation subjective** : reliée explicitement à l’effet Barnum et non comptée comme preuve indépendante.
8. **Justification du système** : présentée comme théorie et famille d’effets, non comme mécanisme individuel unique.
9. **Négligence de l’étendue et des probabilités** : limites de généralisation ajoutées.
10. **Biais de surperception sexuelle** : suppression de toute conclusion individuelle ou évolutionnaire automatique.

## Fiches traitées

- Biais d'attribution hostile
- Biais d'autorité
- Biais d'impact
- Biais d'information
- Biais de congruence
- Biais de croyance
- Biais de fausse unicité
- Biais de l'information partagée
- Biais de la somme nulle
- Biais de projection
- Biais de résultat
- Biais de similarité supposée
- Biais de surperception sexuelle
- Biais de véracité
- Biais des incitations extrinsèques
- Biais égocentrique
- Cascade de disponibilité
- Compensation du risque
- Conservatisme
- Cynisme naïf
- Décalage empathique
- Dévaluation réactive
- Effet boomerang
- Effet d'hypocrisie morale
- Effet de focus
- Effet de mode
- Effet dire, c'est croire
- Effet inférieur à la moyenne
- Effet moins-c'est-mieux
- Erreur d'attribution de groupe
- Erreur de la preuve anecdotique
- Erreur ultime d'attribution
- Essentialisme
- Fixité fonctionnelle
- Hypothèse d'attribution défensive
- Illusion d'objectivité
- Illusion de connaissance asymétrique
- Illusion de fréquence
- Illusion des séries
- Justification de l'effort
- Justification du système
- Malédiction de la connaissance
- Négligence de l'étendue
- Négligence des probabilités
- Perception sélective
- Polarisation de groupe
- Réactance
- Réalisme naïf
- Supériorité illusoire
- Validation subjective

## Portée de l’audit

Le statut « initial critique avec références » signifie que la définition, la nature du concept, ses limites principales et au moins une référence identifiable ont été contrôlées. Il ne correspond pas à une revue systématique exhaustive de l’ensemble de la littérature.
