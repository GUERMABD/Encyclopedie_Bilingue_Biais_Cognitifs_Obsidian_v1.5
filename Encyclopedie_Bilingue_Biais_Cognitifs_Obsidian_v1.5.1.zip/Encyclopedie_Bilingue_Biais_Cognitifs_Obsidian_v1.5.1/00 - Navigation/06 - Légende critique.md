# Légende critique

## Pourquoi une encyclopédie critique ?

Une liste de biais mélange souvent plusieurs objets : biais cognitif, heuristique, effet expérimental, erreur statistique, phénomène mnésique, sophisme ou comportement social. La présence d’un terme dans Wikipédia ou dans le Codex ne constitue donc pas, à elle seule, une preuve de robustesse scientifique.

## Questions à poser pour chaque fiche

1. Le phénomène a-t-il une définition opérationnelle stable ?
2. A-t-il été répliqué indépendamment ?
3. Quelle est la taille de l’effet et dans quelles conditions apparaît-il ?
4. Existe-t-il des explications alternatives : mesure, sélection, régression vers la moyenne ou incitation ?
5. Le comportement est-il réellement irrationnel compte tenu du contexte ?
6. La généralisation à d’autres cultures, domaines ou populations est-elle justifiée ?

## Niveaux de robustesse proposés

- **Établie** : phénomène répliqué et concept relativement stable.
- **Établie mais contextuelle** : effet réel, très dépendant de la tâche ou de la population.
- **À nuancer** : réalité partielle, mais formulation populaire trop large.
- **Débattue** : interprétation ou reproductibilité contestée.
- **À documenter** : inventoriée, mais audit scientifique non réalisé dans cette version.

## Principe important

Connaître le nom d’un biais ne suffit pas pour s’en protéger. Les procédures, les données externes, la contradiction organisée et la traçabilité des décisions sont généralement plus fiables que la seule introspection.

*Révision : 2026-08-01.*

## Nature du concept

Le champ `nature_scientifique` distingue notamment : biais de jugement, effet expérimental, préférence décisionnelle, croyance sociale, hypothèse attributionnelle et modèle descriptif. Cette distinction évite de qualifier automatiquement chaque entrée de « biais cognitif » au sens strict.

Le champ `robustesse` résume l’état de la vérification initiale sans remplacer les détails de la section « Analyse critique ».
