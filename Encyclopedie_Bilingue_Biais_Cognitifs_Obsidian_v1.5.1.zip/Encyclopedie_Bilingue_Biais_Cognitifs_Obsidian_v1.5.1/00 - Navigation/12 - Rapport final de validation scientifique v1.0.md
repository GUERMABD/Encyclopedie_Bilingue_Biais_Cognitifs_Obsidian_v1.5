# Rapport final de validation scientifique v1.0

## Résultat

- Concepts distincts : **265**.
- Fiches disposant d’un audit critique initial : **265**.
- Fiches restant à auditer : **0**.
- Fusions sémantiques cumulées : **8**.
- Dernière fusion : **Effet Peltzman → Compensation du risque**.

## Corrections transversales

1. Toutes les entrées disposent maintenant d’une définition bilingue, d’une nature scientifique, d’un niveau de robustesse, d’une limite critique et d’au moins une source ou d’un constat explicite d’absence de validation primaire.
2. Les sophismes logiques, principes méthodologiques, aphorismes et concepts cliniques ne sont plus présentés comme des biais cognitifs homogènes.
3. Le nombre magique 7 ± 2 est présenté comme un résultat historique dépendant du regroupement, et non comme une constante universelle de la mémoire de travail.
4. Motonormativité est signalée comme un concept récent ; syndrome de Travis comme une étiquette populaire sans construit expérimental stabilisé.
5. Stéréotypage, préjudice, biais stéréotypique et mémorisation stéréotypée sont distingués.
6. Négligence de l’extension est maintenue comme catégorie plus large que la négligence de l’étendue.

## Portée

Le statut « initial critique avec références » confirme un contrôle de la définition, de la nature du concept, de ses limites principales et des références indiquées. Il ne signifie pas qu’une revue systématique exhaustive ou une méta-analyse propre a été réalisée pour chaque entrée.
