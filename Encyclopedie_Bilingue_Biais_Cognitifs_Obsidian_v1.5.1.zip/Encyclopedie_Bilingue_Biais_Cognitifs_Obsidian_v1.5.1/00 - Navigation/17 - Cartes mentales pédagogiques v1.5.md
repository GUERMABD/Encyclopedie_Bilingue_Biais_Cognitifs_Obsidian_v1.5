---
type: navigation
version: 1.5.0
date_verification: 2026-08-02
---

# Cartes mentales pédagogiques — version 1.5

Cette version ajoute **quatre nouvelles cartes mentales** plus lisibles, plus synthétiques et plus pédagogiques.

Elles ne remplacent pas les cartes existantes : elles servent de **portes d’entrée visuelles**.

## Nouvelles cartes

- [[02 - Cartes mentales/Carte mentale - Fondamentaux des biais cognitifs.canvas|Les fondamentaux des biais cognitifs]]
- [[02 - Cartes mentales/Carte mentale - 20 biais du quotidien.canvas|20 biais du quotidien]]
- [[02 - Cartes mentales/Carte mentale - Comment repérer un biais.canvas|Comment repérer un biais ?]]
- [[02 - Cartes mentales/Carte mentale - Débiaisement pratique.canvas|Débiaisement pratique]]

## Comment les utiliser

1. Commencer par **Les fondamentaux** pour avoir une vue d’ensemble.
2. Utiliser **20 biais du quotidien** pour relier les concepts à des situations concrètes.
3. Ouvrir **Comment repérer un biais ?** lorsqu’une situation réelle te pose question.
4. Terminer par **Débiaisement pratique** pour transformer la compréhension en réflexes utiles.

## Compléments utiles

- [[15 - Parcours pédagogique|Parcours pédagogique linéaire]]
- [[02 - Index alphabétique|Index alphabétique]]
- [[03 - Classification actuelle 2026|Classification actuelle 2026]]
- [[04 - Codex historique|Codex historique]]
