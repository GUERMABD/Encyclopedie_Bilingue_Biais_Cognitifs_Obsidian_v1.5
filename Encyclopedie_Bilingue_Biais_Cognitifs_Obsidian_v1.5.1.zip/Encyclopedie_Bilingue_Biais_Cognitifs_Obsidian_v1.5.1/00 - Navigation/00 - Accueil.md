---
type: accueil
version: 1.3.0
date_verification: 2026-08-02
---

# Encyclopédie bilingue et critique des biais cognitifs

![[Cognitive Bias Codex - FR.svg]]

## Commencer ici

- **[[15 - Parcours pédagogique|Suivre le parcours pédagogique linéaire]]**
- **[[17 - Cartes mentales pédagogiques v1.5|Ouvrir les nouvelles cartes mentales pédagogiques]]**
- [[02 - Index alphabétique|Rechercher un concept précis]]
- [[01 - Méthodologie, mise à jour et limites|Comprendre la méthode et les limites]]
- [[06 - Légende critique|Lire les niveaux de robustesse]]

## Explorer la base

- [[03 - Classification actuelle 2026|Classement Wikipédia anglais 2026]]
- [[04 - Codex historique]]
- [[05 - Écart FR-EN]]
- [[02 - Cartes mentales/Parcours pédagogique - Découverte progressive.canvas|Parcours pédagogique — carte]]
- [[02 - Cartes mentales/Carte mentale - Fondamentaux des biais cognitifs.canvas|Carte mentale — fondamentaux]]
- [[02 - Cartes mentales/Carte mentale - 20 biais du quotidien.canvas|Carte mentale — 20 biais du quotidien]]
- [[02 - Cartes mentales/Carte mentale - Comment repérer un biais.canvas|Carte mentale — comment repérer un biais ?]]
- [[02 - Cartes mentales/Carte mentale - Débiaisement pratique.canvas|Carte mentale — débiaisement pratique]]
- [[02 - Cartes mentales/Vue générale - Classification actuelle.canvas|Classification actuelle — carte]]
- [[02 - Cartes mentales/Vue générale - Codex.canvas|Codex historique — carte]]

## État de cette édition

- **265 concepts distincts** après fusion de huit doublons sémantiques vérifiés ;
- **243 entrées** transcrites depuis la liste Wikipédia anglaise, révision `1364507766` ;
- **188 libellés bruts** dans le Codex anglais, correspondant à **176 concepts distincts** après rapprochement des synonymes ;
- **22 concepts** présents dans le Codex mais pas dans la liste anglaise contrôlée ;
- **265 fiches** disposent d’un audit scientifique initial critique et de références contrôlées ;
- les **265 fiches** et les **7 concepts associés** disposent maintenant d’une illustration pratique explicitée ;
- **Aucune fiche** ne reste explicitement marquée **audit scientifique non réalisé**.

## Principe documentaire

La présence dans Wikipédia ou dans le Codex est une donnée d’inventaire, pas une preuve scientifique. Cette édition sépare donc le recensement, la traduction, le classement éditorial et la validation scientifique.

## Mise à jour locale

Le script de mise à jour préserve les synthèses critiques et remplace seulement un bloc d’import délimité. Il résout la page française par Wikidata, enregistre les révisions et traite les licences des médias séparément.

## Rapports de contrôle et évolutions

- [[07 - Rapport de contrôle v0.2]]
- [[08 - Rapport de vérification scientifique v0.3]]
- [[09 - Rapport de vérification scientifique v0.4]]
- [[10 - Rapport de vérification scientifique v0.5]]
- [[11 - Rapport de vérification scientifique v0.6]]
- [[12 - Rapport final de validation scientifique v1.0]]
- [[13 - Rapport d’enrichissement pratique v1.1]]
- [[14 - Correctif Windows UTF-8 et liens v1.2]]
- [[16 - Améliorations ergonomiques et parcours v1.3]]

- [[17 - Cartes mentales pédagogiques v1.5]]
- [[18 - Ajout de cartes mentales pédagogiques v1.5]]
