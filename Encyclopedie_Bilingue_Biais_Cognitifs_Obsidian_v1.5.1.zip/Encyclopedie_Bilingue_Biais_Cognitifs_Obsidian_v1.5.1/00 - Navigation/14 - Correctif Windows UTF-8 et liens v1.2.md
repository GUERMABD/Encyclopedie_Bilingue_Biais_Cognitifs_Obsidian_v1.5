---
type: rapport-controle
version: 1.2.0
date_verification: 2026-08-02
---

# Correctif Windows UTF-8 et liens — v1.2

## Problème corrigé

L’archive v1.1 contenait des noms de fichiers accentués sans indicateur UTF-8 dans le répertoire ZIP. Certains extracteurs Windows les interprétaient alors avec une ancienne page de codes, ce qui produisait des noms accentués illisibles ou déformés.

Les liens Obsidian pointaient vers les noms français corrects. Après une extraction avec des noms altérés, ces liens ne pouvaient donc plus retrouver leurs cibles.

## Corrections appliquées

- reconstruction complète du ZIP avec le drapeau Unicode UTF-8 sur chaque nom non ASCII ;
- normalisation Unicode NFC des noms de fichiers et des contenus textuels ;
- vérification de tous les fichiers texte en UTF-8 ;
- remplacement des deux inclusions du Codex par un lien basé sur son nom de fichier unique ;
- contrôle des liens Wikilink, des inclusions de médias et des chemins Canvas ;
- ajout du script `controler_encodage_et_liens.py`.

## Installation correcte

Supprimer ou renommer l’ancien dossier extrait, puis décompresser la v1.2 dans un dossier neuf. Ne pas extraire la nouvelle archive par-dessus l’ancienne : Windows ne renommerait pas forcément les anciens fichiers corrompus.
