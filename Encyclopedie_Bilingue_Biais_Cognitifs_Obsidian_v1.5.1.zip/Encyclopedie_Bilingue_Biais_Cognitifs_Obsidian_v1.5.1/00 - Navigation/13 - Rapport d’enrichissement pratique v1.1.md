# Rapport d’enrichissement pratique v1.1

Date : 2026-08-02

## Objectif

Rendre les fiches utilisables dans la pratique sans alourdir inutilement les définitions scientifiques.

## Travail réalisé

- contrôle des 265 fiches de biais et effets ;
- ajout de l’exemple manquant dans la fiche [[Effet d'indiçage partiel]] ;
- conservation des 264 exemples déjà présents ;
- ajout, dans chaque fiche, d’une phrase **« Ce que cela illustre »** reliant explicitement la situation au mécanisme décrit dans la fiche ;
- ajout d’un exemple concret aux sept concepts associés : débiaisement, biais statistique, distorsion cognitive, métacognition, heuristique, rationalité limitée et sophisme ;
- mise en place d’un contrôle automatique de couverture et de contenu minimal des exemples.

## Règle d’interprétation

Les situations non accompagnées d’une source historique sont des **exemples pédagogiques fictifs**. Elles servent à comprendre le mécanisme ; elles ne constituent ni une preuve scientifique supplémentaire ni un diagnostic applicable automatiquement à une personne réelle.

## Résultat

- 265 fiches de biais sur 265 avec exemple ;
- 7 concepts associés sur 7 avec exemple ;
- 272 notes illustrées sur 272 ;
- chaque illustration contient une explication explicite de son lien avec le concept.
