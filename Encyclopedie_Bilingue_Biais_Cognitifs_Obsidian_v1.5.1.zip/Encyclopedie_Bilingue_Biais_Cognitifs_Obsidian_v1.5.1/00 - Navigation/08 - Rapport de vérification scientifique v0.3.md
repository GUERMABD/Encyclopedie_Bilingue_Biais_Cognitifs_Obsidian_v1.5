# Rapport de vérification scientifique v0.3

## Objet

Poursuite du contrôle scientifique et terminologique de l’encyclopédie, sans rallonger les fiches par principe. Cette édition corrige les erreurs certaines, réduit les formulations trop affirmatives et distingue les biais cognitifs des théories, lois, effets, construits et biais méthodologiques.

## Résultat quantitatif

- Fiches totales : **268**.
- Fiches disposant désormais d’un audit scientifique initial critique : **56**.
- Fiches avec des références contrôlées et un classement scientifique explicite : **56**.
- Fiches restant à auditer : **212**.

## Corrections de fond — première passe

1. **Effet acteur-observateur** : la forme générale classique n’est pas soutenue par la méta-analyse de 173 études ; la fiche est désormais classée comme débattue.
2. **Erreur de la main chaude** : l’analyse historique était affectée par un biais statistique de sélection des séries. La fiche distingue croyance exagérée et persistance réelle de performance.
3. **Comptabilité mentale** : reclassée comme modèle descriptif regroupant plusieurs effets, et non comme biais unique.
4. **Pensée de groupe** : présentée comme cadre théorique utile mais imparfaitement validé, et non comme mécanisme automatique.
5. **Risque zéro** : la portée de la preuve initiale est limitée à des tâches précises ; la généralisation a été réduite.
6. **Biais d’optimisme** : ajout de la critique méthodologique des mesures comparatives.
7. **Victime identifiable** : ajout de la méta-analyse montrant un effet moyen plus faible que ne le suggèrent certaines présentations populaires.
8. **Doublons résiduels** : `Biais intragroupe` a été fusionné avec `Favoritisme intragroupe`, et `Indiçage partiel` avec `Effet d’indiçage partiel`.
9. **Référence bibliographique** : le DOI de Barbey et Sloman (2007) a été corrigé afin de correspondre au titre cité.

## Corrections de nature scientifique — seconde passe

Quatorze entrées supplémentaires ont été contrôlées. Les corrections principales sont les suivantes :

- **Effet placebo** : effet clinique et contextuel, non biais cognitif ; portée générale et magnitude précisées.
- **Dissonance cognitive** : théorie motivationnelle et famille d’effets, non biais unique.
- **Phénomène de l’imposteur** : appellation scientifique privilégiée ; absence de statut diagnostique rappelée. « Syndrome de l’imposteur » reste un alias courant.
- **Effet Pygmalion** : effet interpersonnel contextuel, généralement faible à modéré, et non mécanisme automatique.
- **Effet d’attente de l’expérimentateur** : menace méthodologique distincte d’un biais ordinaire du participant.
- **Biais de sélection** : biais méthodologique et d’inférence causale.
- **Paradoxe de Berkson** : artefact statistique lié à la sélection sur un collisionneur.
- **Biais systématique** : concept générique de métrologie et de statistique ; nom anglais harmonisé en `Systematic error`.
- **Loi de Weber-Fechner** : modèle psychophysique historique, non biais ; distinction entre les lois de Weber et de Fechner ajoutée.
- **Disparité de conscience des plantes** : ancien terme `cécité aux plantes` conservé comme alias ; portée éducative et terminologie précisées.
- **Différences liées au sexe dans la mémoire des témoins** : thème de recherche aux résultats mixtes, et non biais cognitif.
- **Association implicite** : construit mesuré indirectement ; un score isolé ne constitue pas un diagnostic individuel.
- **Stéréotype implicite** : construit large, non effet unique.
- **Biais implicite** : catégorie parapluie ; les termes implicite, inconscient, automatique et incontrôlé ne sont pas interchangeables.

## Fiches traitées dans la première passe

- Effet de dotation
- Effet de halo
- Biais d’autocomplaisance
- Biais d’optimisme
- Effet de faux consensus
- Croyance en un monde juste
- Effet acteur-observateur
- Erreur de conjonction
- Oubli de la fréquence de base
- Erreur du parieur
- Erreur de la main chaude
- Corrélation illusoire
- Illusion de contrôle
- Effet de dominance asymétrique
- Effet de compromis
- Effet de simple exposition
- Pensée de groupe
- Favoritisme intragroupe
- Biais d’homogénéité de l’exogroupe
- Effet de la victime identifiable
- Biais d’omission
- Biais d’action
- Effet de défaut
- Biais du risque zéro
- Effet d’ambiguïté
- Comptabilité mentale
- Effet d’indiçage partiel

## Harmonisation des quinze premières fiches auditées

Les quinze fiches vérifiées avant la version 0.3 ont été remises au même format que les audits récents : champs `nature_scientifique` et `robustesse`, conclusion critique, références contrôlées et distinction entre biais, heuristique, effet ou erreur méthodologique.

- **Ancrage** : effet de jugement établi, mais d’ampleur contextuelle.
- **Aversion à la perte** : asymétrie moyenne documentée, non universelle.
- **Biais de confirmation** : famille de processus, et non mécanisme unique.
- **Biais de l’angle mort** : effet métacognitif documenté, sensible à sa mesure.
- **Biais de négativité** : concept parapluie regroupant plusieurs asymétries.
- **Biais de planification** : distingué de l’incertitude normale et du mensonge stratégique.
- **Biais du statu quo** : préférence pour l’existant parfois rationnelle selon les coûts de transition.
- **Biais du survivant** : reclassé principalement comme erreur de sélection.
- **Biais rétrospectif** : effet de mémoire et de jugement robuste.
- **Effet Dunning-Kruger** : présentation populaire corrigée ; résultats statistiques et empiriques contradictoires intégrés.
- **Effet de cadrage** : famille d’effets, à préciser selon le paradigme.
- **Effet de vérité illusoire** : effet de répétition robuste mais non automatique.
- **Erreur fondamentale d’attribution** : appellation conservée, universalité explicitement limitée.
- **Escalade d’engagement** : distinguée d’une poursuite rationnelle fondée sur de nouvelles informations.
- **Heuristique de disponibilité** : reclassée comme heuristique pouvant être utile ou biaisante selon l’environnement.

## Limite

Le statut « audit scientifique initial » signifie que la définition, la nature du concept, une référence fondatrice et les principales limites ont été contrôlées. Il ne signifie pas qu’une revue systématique exhaustive de toute la littérature a été réalisée.

## Cohérence des données

Les deux CSV, l’inventaire JSON, les index Markdown et les cartes Canvas ont été resynchronisés après les renommages. Le contrôle automatisé final porte sur **268 fiches**. Il vérifie également la présence des champs critiques et des références pour chaque fiche auditée.
