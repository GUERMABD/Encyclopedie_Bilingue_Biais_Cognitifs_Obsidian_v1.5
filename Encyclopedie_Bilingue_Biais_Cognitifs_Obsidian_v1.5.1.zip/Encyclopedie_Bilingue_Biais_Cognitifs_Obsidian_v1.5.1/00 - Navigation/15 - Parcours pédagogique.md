---
type: navigation
version: 1.3.0
date_verification: 2026-08-02
---

# Parcours pédagogique — découvrir les biais progressivement

Ce parcours propose une lecture **linéaire**, du fonctionnement général de la cognition vers les décisions individuelles, les jugements sociaux et les méthodes de débiaisement.

Il ne remplace pas l’[[02 - Index alphabétique|index alphabétique]] : il donne un ordre de découverte à une personne qui ne sait pas par où commencer.

## Parcours principal

- [ ] [[01 - Comprendre les biais sans les caricaturer|Étape 1 — Comprendre les biais sans les caricaturer]]
- [ ] [[02 - Perception et attention|Étape 2 — Perception et attention]]
- [ ] [[03 - Mémoire reconstructive|Étape 3 — Mémoire reconstructive]]
- [ ] [[04 - Probabilités et jugement|Étape 4 — Probabilités et jugement]]
- [ ] [[05 - Décision et engagement|Étape 5 — Décision et engagement]]
- [ ] [[06 - Se juger soi-même|Étape 6 — Se juger soi-même]]
- [ ] [[07 - Juger les autres|Étape 7 — Juger les autres]]
- [ ] [[08 - Groupe, influence et information|Étape 8 — Groupe, influence et information]]
- [ ] [[09 - Débiaisement et esprit critique|Étape 9 — Débiaisement et esprit critique]]

## Comment l’utiliser

1. Lire les fiches proposées dans l’ordre indiqué.
2. Faire la petite mise en pratique de l’étape.
3. Revenir ici et cocher l’étape terminée.
4. Utiliser les liens de la fiche pour approfondir uniquement les concepts qui t’intéressent.

## Vue visuelle

- [[02 - Cartes mentales/Parcours pédagogique - Découverte progressive.canvas|Ouvrir le parcours sous forme de carte]]
- [[17 - Cartes mentales pédagogiques v1.5|Voir aussi les nouvelles cartes mentales pédagogiques]]

## Après le parcours

- [[03 - Classification actuelle 2026|Explorer la classification complète]]
- [[04 - Codex historique|Comparer avec le Codex historique]]
- [[06 - Légende critique|Interpréter les niveaux de robustesse]]
- [[02 - Index alphabétique|Consulter un concept précis]]
