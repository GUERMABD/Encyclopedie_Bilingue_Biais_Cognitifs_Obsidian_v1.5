# Rapport de vérification scientifique v0.6

## Objet

Avant-dernier lot de validation scientifique et terminologique. Ce lot traite principalement des biais causaux, des effets de décision récents, des biais méthodologiques et de plusieurs entrées qui relèvent en réalité de la logique, de la philosophie ou de la gestion. Les fiches restent volontairement concises.

## Résultat quantitatif

- Concepts distincts : **266**.
- Fiches auditées avant cette passe : **167**.
- Fiches nouvellement auditées : **50**.
- Fiches disposant désormais d’un audit scientifique initial : **217**.
- Fiches restant à auditer : **49**.
- Doublon fusionné : **Biais de cohérence avec soi → Biais de cohérence**.

## Corrections majeures

1. **Cohérence avec soi** : fusion avec le biais de cohérence, les deux expressions désignant la reconstruction du passé à partir des attitudes présentes.
2. **Appel à la nouveauté** et **argument tiré d’un sophisme** : reclassés comme sophismes informels, non comme effets psychologiques autonomes.
3. **Chance morale** : reclassée comme problème normatif de philosophie morale.
4. **Effet abri à vélo** : présenté comme loi de trivialité et aphorisme organisationnel à validation expérimentale limitée.
5. **Aversion au retour en arrière** : signalée comme effet introduit en 2025, soutenu par quatre études mais encore sans large réplication indépendante.
6. **Détection d’agent** : le modèle d’un dispositif universellement hypersensible est qualifié d’hypothèse aux résultats mixtes.
7. **Biais intéroceptif** : séparation entre exactitude, sensibilité déclarée, critère de réponse et influence d’un état corporel.
8. **Contexte, domaine, prévention et quantification** : portée limitée au champ dans lequel ces notions ont été introduites.
9. **Confabulation** : distinguée d’un mensonge et des erreurs ordinaires de mémoire.
10. **Biais de source commune** : reclassé comme biais méthodologique de mesure.

## Corrections bibliographiques de cohérence

Le contrôle croisé titre–auteurs–revue–pagination–DOI a rectifié les notices relatives à l’attribution forme–fonction, au biais de quantification, au rappel hédonique, au biais de normalité, au biais intéroceptif, à la sélection de valeur et à la cryptomnésie sociale.

## Fiches traitées

- A priori erronés
- Anthropomorphisme
- Apophénie
- Appel à la nouveauté
- Argument tiré d'un sophisme
- Attente exagérée
- Aversion au retour en arrière
- Aversion à l'appréhension
- Biais d'attribution des traits
- Biais d'attribution forme-fonction
- Biais d'incarnation
- Biais d'intentionnalité
- Biais de cohérence
- Biais de comparaison sociale
- Biais de courtoisie
- Biais de distinction
- Biais de détection d'agent
- Biais de genre
- Biais de la portion
- Biais de normalité
- Biais de négligence du contexte
- Biais de négligence du domaine
- Biais de pessimisme
- Biais de placement
- Biais de poursuite du plan
- Biais de proportionnalité
- Biais de prévention
- Biais de quantification
- Biais de rappel hédonique
- Biais de retenue
- Biais de saillance
- Biais de source commune
- Biais de sélection de valeur
- Biais du gain de temps
- Biais intéroceptif
- Biais pro-innovation
- Biais puritain
- Biais régressif
- Biais stéréotypique
- Biais téléologique
- Chance morale
- Changement de choix non adaptatif
- Confabulation
- Cryptomnésie sociale
- Déclinisme
- Effet Benjamin Franklin
- Effet abri à vélo
- Effet au-suivant
- Effet d'ordre sur le bulletin
- Effet de bizarrerie

## Portée de l’audit

Le statut « initial critique avec références » signifie que la définition, la nature du concept, ses limites principales et au moins une référence identifiable ont été contrôlées. Il ne correspond pas à une revue systématique exhaustive de l’ensemble de la littérature.
