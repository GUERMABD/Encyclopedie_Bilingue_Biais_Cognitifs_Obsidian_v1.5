# Classement employé par la liste Wikipédia anglaise — contrôle 2026

> [!important] Portée
> Cette organisation décrit le classement éditorial observé dans la liste anglaise contrôlée. Elle ne constitue pas une taxonomie scientifique universellement validée.

## Estimation

### Association

- [[Biais du gain de temps]] — *Time-saving bias*
- [[Décalage empathique]] — *Hot-cold empathy gap*
- [[Effet de la victime identifiable]] — *Identifiable victim effect*
- [[Effet de sous-additivité]] — *Subadditivity effect*
- [[Effet esthétique-utilisabilité]] — *Aesthetic–usability effect*
- [[Erreur de conjonction]] — *Conjunction fallacy*
- [[Heuristique de disponibilité]] — *Availability heuristic*
- [[Substitution d'attribut]] — *Attribute substitution*
- [[Syndrome de Travis]] — *Travis syndrome*
- [[Tachypsychie]] — *Tachypsychia*

### Baseline

- [[Ancrage]] — *Anchoring bias*
- [[Biais de la portion]] — *Unit bias*
- [[Biais intéroceptif]] — *Interoceptive bias*
- [[Biais régressif]] — *Regressive bias*
- [[Biais systématique]] — *Systematic error*
- [[Effet de sous-additivité]] — *Subadditivity effect*
- [[Effet difficile-facile]] — *Hard–easy effect*
- [[Effet Dunning-Kruger]] — *Dunning–Kruger effect*
- [[Erreur de la main chaude]] — *Hot-hand fallacy*
- [[Erreur du parieur]] — *Gambler's fallacy*
- [[Insensibilité à la taille de l’échantillon]] — *Insensitivity to sample size*
- [[Loi de Weber-Fechner]] — *Weber–Fechner law*
- [[Oubli de la fréquence de base]] — *Base rate fallacy*

### Inertia

- [[Conservatisme]] — *Conservatism bias*

### Outcome

- [[Attente exagérée]] — *Exaggerated expectation*
- [[Biais d'impact]] — *Impact bias*
- [[Biais de planification]] — *Planning fallacy*
- [[Biais de rappel hédonique]] — *Hedonic recall bias*
- [[Biais de retenue]] — *Restraint bias*
- [[Biais de résultat]] — *Outcome bias*
- [[Biais de surperception sexuelle]] — *Sexual overperception bias*
- [[Illusion de la validité]] — *Illusion of validity*

### Self-perspective

- [[Biais d'homogénéité de l'exogroupe]] — *Outgroup homogeneity bias*
- [[Biais d'optimisme]] — *Optimism bias*
- [[Biais de pessimisme]] — *Pessimism bias*
- [[Biais des incitations extrinsèques]] — *Extrinsic incentives bias*
- [[Cynisme naïf]] — *Naïve cynicism*
- [[Effet de faux consensus]] — *False consensus effect*
- [[Effet de projecteur]] — *Spotlight effect*
- [[Effet inférieur à la moyenne]] — *Worse-than-average effect*
- [[Illusion de transparence]] — *Illusion of transparency*
- [[Malédiction de la connaissance]] — *Curse of knowledge*

## Decision

### Association

- [[Aversion à l'appréhension]] — *Dread aversion*
- [[Aversion à la perte]] — *Loss aversion*
- [[Biais d'automatisation]] — *Automation bias*
- [[Biais d'autorité]] — *Authority bias*
- [[Biais de prévention]] — *Prevention bias*
- [[Biais du risque zéro]] — *Zero-risk bias*
- [[Changement de choix non adaptatif]] — *Non-adaptive choice switching*
- [[Compensation du risque]] — *Risk compensation*
- [[Effet d'ambiguïté]] — *Ambiguity effect*
- [[Effet de cadrage]] — *Framing effect*
- [[Effet de défaut]] — *Default effect*
- [[Effet de pseudo-certitude]] — *Pseudocertainty effect*
- [[Négligence des probabilités]] — *Neglect of probability*
- [[Rabais hyperbolique]] — *Hyperbolic discounting*
- [[Érosion de la compassion]] — *Compassion fade*

### Baseline

- [[Biais additif]] — *Additive bias*
- [[Biais d'action]] — *Action bias*
- [[Biais de distinction]] — *Distinction bias*
- [[Biais de normalité]] — *Normalcy bias*
- [[Biais de projection]] — *Projection bias*
- [[Effet d'ordre sur le bulletin]] — *Ballot order effect*
- [[Effet de compromis]] — *Compromise effect*
- [[Effet de disposition]] — *Disposition effect*
- [[Effet de dominance asymétrique]] — *Decoy effect*
- [[Effet de dénomination]] — *Denomination effect*
- [[Effet fantôme]] — *Phantom effect*
- [[Effet moins-c'est-mieux]] — *Less-is-better effect*
- [[Effet pom-pom girl]] — *Cheerleader effect*
- [[Illusion monétaire]] — *Money illusion*
- [[Négligence de l'étendue]] — *Scope neglect*

### Inertia

- [[Aversion au retour en arrière]] — *Doubling-back aversion*
- [[Biais de l'information partagée]] — *Shared information bias*
- [[Biais de poursuite du plan]] — *Plan continuation bias*
- [[Biais du statu quo]] — *Status quo bias*
- [[Effet de dotation]] — *Endowment effect*
- [[Effet de la route familière]] — *Well travelled road effect*
- [[Effet de simple exposition]] — *Mere exposure effect*
- [[Escalade d'engagement]] — *Escalation of commitment*
- [[Fixité fonctionnelle]] — *Functional fixedness*
- [[Réflexe de Semmelweis]] — *Semmelweis reflex*

### Outcome

- [[Biais du présent]] — *Present bias*
- [[Réactance]] — *Reactance*

### Self-perspective

- [[Biais de comparaison sociale]] — *Social comparison bias*
- [[Dévaluation réactive]] — *Reactive devaluation*
- [[Effet IKEA]] — *IKEA effect*
- [[Justification de l'effort]] — *Effort justification*
- [[Loi de l'instrument]] — *Law of the instrument*
- [[Pas inventé ici]] — *Not invented here*

## Hypothesis assessment

### Association

- [[A priori erronés]] — *False priors*
- [[Appariement des probabilités]] — *Probability matching*
- [[Biais de détection d'agent]] — *Agent detection bias*
- [[Biais de quantification]] — *Quantification bias*
- [[Biais de saillance]] — *Salience bias*
- [[Biais de source commune]] — *Common source bias*
- [[Biais de sélection]] — *Selection bias*
- [[Biais de véracité]] — *Truth bias*
- [[Cascade de disponibilité]] — *Availability cascade*
- [[Dissonance cognitive]] — *Cognitive dissonance*
- [[Effet de sous-additivité]] — *Subadditivity effect*
- [[Effet de vérité illusoire]] — *Illusory truth effect*
- [[Effet dire, c'est croire]] — *Saying is believing effect*
- [[Effet ça rime donc c'est bon|Effet « ça rime donc c’est bon »]] — *Rhyme as reason effect*
- [[Heuristique de fluidité]] — *Fluency heuristic*
- [[Illusion de profondeur explicative]] — *Illusion of explanatory depth*
- [[Pensée de groupe]] — *Groupthink*
- [[Polarisation de groupe]] — *Groupshift*

### Baseline

- [[Effet de sous-additivité]] — *Subadditivity effect*

### Outcome

- [[Biais d'excès de confiance]] — *Overconfidence effect*
- [[Biais d'information]] — *Information bias*
- [[Biais de confirmation]] — *Confirmation bias*
- [[Biais de congruence]] — *Congruence bias*
- [[Biais de croyance]] — *Belief bias*
- [[Biais de genre]] — *Gender bias*
- [[Biais de sélection de valeur]] — *Value selection bias*
- [[Biais du survivant]] — *Survivorship bias*
- [[Biais implicite]] — *Implicit bias*
- [[Corrélation illusoire]] — *Illusory correlation*
- [[Effet Barnum]] — *Barnum effect*
- [[Effet d'attente de l'expérimentateur]] — *Experimenter expectancy effect*
- [[Illusion des séries]] — *Clustering illusion*
- [[Négligence de l'extension]] — *Extension neglect*
- [[Paradoxe de Berkson]] — *Berkson's paradox*
- [[Paréidolie]] — *Pareidolia*
- [[Validation subjective]] — *Subjective validation*

### Self-perspective

- [[Effet d'attente de l'expérimentateur]] — *Experimenter expectancy effect*

## Causal attribution

### Outcome

- [[Apophénie]] — *Apophenia*
- [[Biais d'attribution forme-fonction]] — *Form-function attribution bias*
- [[Biais d'attribution hostile]] — *Hostile attribution bias*
- [[Biais d'incarnation]] — *Embodiment bias*
- [[Biais d'intentionnalité]] — *Intentionality bias*
- [[Biais de négligence du contexte]] — *Context neglect bias*
- [[Biais de négligence du domaine]] — *Domain neglect bias*
- [[Biais de proportionnalité]] — *Proportionality bias*
- [[Biais de similarité supposée]] — *Assumed similarity bias*
- [[Biais pro-innovation]] — *Pro-innovation bias*
- [[Biais puritain]] — *Puritanical bias*
- [[Biais téléologique]] — *Teleological bias*
- [[Corrélation illusoire]] — *Illusory correlation*
- [[Croyance en un monde juste]] — *Just–world hypothesis*
- [[Disparité de conscience des plantes]] — *Plant awareness disparity*
- [[Effet d'attente de l'expérimentateur]] — *Experimenter expectancy effect*
- [[Erreur d'attribution de groupe]] — *Group attribution error*
- [[Illusion de contrôle]] — *Illusion of control*
- [[Illusion de la dinde]] — *Turkey illusion*
- [[Justification du système]] — *System justification*
- [[Motonormativité]] — *Motonormativity*
- [[Sophisme G. I. Joe]] — *G. I. Joe fallacy*
- [[Substitution de l'indicateur à l'objectif]] — *Surrogation*

### Self-perspective

- [[Biais d'autocomplaisance]] — *Self-serving bias*
- [[Biais de fausse unicité]] — *False uniqueness bias*
- [[Biais égocentrique]] — *Egocentric bias*
- [[Effet acteur-observateur]] — *Actor-observer bias*
- [[Effet d'attente de l'expérimentateur]] — *Experimenter expectancy effect*
- [[Effet de l'autruche]] — *Ostrich effect*
- [[Effet Pygmalion]] — *Pygmalion effect*
- [[Erreur fondamentale d'attribution]] — *Fundamental attribution error*
- [[Erreur ultime d'attribution]] — *Ultimate attribution error*
- [[Favoritisme envers l'exogroupe]] — *Outgroup favoritism*
- [[Favoritisme intragroupe]] — *In-group favoritism*
- [[Hypothèse d'attribution défensive]] — *Defensive attribution hypothesis*
- [[Illusion d'objectivité]] — *Objectivity illusion*
- [[Perception sélective]] — *Selective perception*

## Recall

### Association

- [[Amnésie infantile]] — *Childhood amnesia*
- [[Association implicite]] — *Implicit association*
- [[Biais d'affaiblissement de l'affect]] — *Fading affect bias*
- [[Biais de cohérence]] — *Consistency bias*
- [[Biais de négativité]] — *Negativity bias*
- [[Biais mnésique lié à l'humeur]] — *Mood-congruent memory bias*
- [[Confusion de la source]] — *Source confusion*
- [[Cryptomnésie]] — *Cryptomnesia*
- [[Cryptomnésie sociale]] — *Social cryptomnesia*
- [[Cécité à la répétition]] — *Repetition blindness*
- [[Effet au-suivant]] — *Next-in-line effect*
- [[Effet d'espacement]] — *Spacing effect*
- [[Effet d'espacement temporel]] — *Lag effect*
- [[Effet d'humour]] — *Humor effect*
- [[Effet d'indiçage partiel]] — *Part-list cueing effect*
- [[Effet de contraste]] — *Contrast effect*
- [[Effet de difficulté de traitement]] — *Processing difficulty effect*
- [[Effet de désinformation]] — *Misinformation effect*
- [[Effet de la modalité]] — *Modality effect*
- [[Effet de positivité]] — *Positivity effect*
- [[Effet de profondeur du traitement]] — *Levels-of-processing effect*
- [[Effet de supériorité de l'image]] — *Picture superiority effect*
- [[Effet de télescopage]] — *Telescoping effect*
- [[Effet de verbatim]] — *Verbatim effect*
- [[Effet du contexte]] — *Context effect*
- [[Effet du suffixe]] — *Suffix effect*
- [[Effet Google]] — *Google effect*
- [[Effet Perky]] — *Perky effect*
- [[Effet test]] — *Testing effect*
- [[Effet Zeigarnik]] — *Zeigarnik effect*
- [[Extension des limites]] — *Boundary extension*
- [[Faux souvenir]] — *False memory*
- [[Inhibition de la mémoire]] — *Memory inhibition*
- [[Mot sur le bout de la langue]] — *Tip of the tongue*
- [[Nivellement et affinement]] — *Leveling and sharpening*
- [[Négligence de la durée]] — *Duration neglect*
- [[Persistance mnésique]] — *Persistence*
- [[Pic de réminiscence]] — *Reminiscence bump*
- [[Règle pic-fin]] — *Peak–end rule*
- [[Suggestibilité]] — *Suggestibility*
- [[Échec du rappel sans indice]] — *Cue-dependent forgetting*

### Baseline

- [[Biais de négativité]] — *Negativity bias*
- [[Effet de bizarrerie]] — *Bizarreness effect*
- [[Effet de la longueur de la liste]] — *List-length effect*
- [[Effet de position sérielle]] — *Serial position effect*
- [[Effet de primauté]] — *Primacy effect*
- [[Effet de récence]] — *Recency effect*
- [[Effet von Restorff]] — *Von Restorff effect*
- [[Illusion de fréquence]] — *Frequency illusion*

### Inertia

- [[Biais attentionnel]] — *Attentional bias*
- [[Biais stéréotypique]] — *Stereotype bias*
- [[Effet d'influence persistante]] — *Continued influence effect*

### Outcome

- [[Biais de soutien du choix]] — *Choice-supportive bias*
- [[Biais rétrospectif]] — *Hindsight bias*
- [[Déclinisme]] — *Declinism*
- [[Illusion de récence]] — *Recency illusion*
- [[Rappel euphorique]] — *Euphoric recall*
- [[Rétrospective de la vie en rose]] — *Rosy retrospection*

### Self-perspective

- [[Biais de placement]] — *Placement bias*
- [[Différences liées au sexe dans la mémoire des témoins]] — *Sex differences in eyewitness memory*
- [[Effet de génération d'information]] — *Generation effect*
- [[Effet de référence à soi]] — *Self-relevance effect*
- [[Effet inter-races]] — *Cross-race effect*

## Opinion reporting

### Association

- [[Biais de négativité]] — *Negativity bias*
- [[Effet d'hypocrisie morale]] — *Moral credential effect*
- [[Effet de halo]] — *Halo effect*

### Baseline

- [[Biais de négativité]] — *Negativity bias*

### Inertia

- [[Biais d'omission]] — *Omission bias*
- [[Effet boomerang]] — *Backfire effect*
- [[Illusion de la fin de l'histoire]] — *End-of-history illusion*

### Outcome

- [[Biais de courtoisie]] — *Courtesy bias*
- [[Chance morale]] — *Moral luck*
- [[Désirabilité sociale]] — *Social desirability bias*
- [[Effet de mode]] — *Bandwagon effect*
- [[Effet « les femmes sont merveilleuses »]] — *Women are wonderful effect*
- [[Hypothèse de l'effort mal interprété]] — *Misinterpreted-effort hypothesis*
- [[Illusion d'apprentissage]] — *Illusion of learning*
- [[Stéréotypage]] — *Stereotyping*

### Self-perspective

- [[Anthropomorphisme]] — *Anthropomorphism*
- [[Biais d'attribution des traits]] — *Trait ascription bias*
- [[Biais de l'angle mort]] — *Bias blind spot*
- [[Biais de la somme nulle]] — *Zero-sum bias*
- [[Effet Benjamin Franklin]] — *Ben Franklin effect*
- [[Effet troisième personne|Effet « troisième personne »]] — *Third-person effect*
- [[Illusion de connaissance asymétrique]] — *Illusion of asymmetric insight*
- [[Pensée anthropocentrique]] — *Anthropocentric thinking*
- [[Phénomène de l'imposteur]] — *Impostor phenomenon*
- [[Réalisme naïf]] — *Naïve realism*
- [[Supériorité illusoire]] — *Illusory superiority*
