# Méthodologie, mise à jour et limites

## Sources structurantes contrôlées

1. Wikipédia anglais, « List of cognitive biases », révision `1364507766`, contrôlée le 2026-08-01.
2. Wikipédia français, « Biais cognitif », révision `237491828`, contrôlée le 2026-08-01.
3. Dimara et al., *A Task-Based Taxonomy of Cognitive Biases for Information Visualization*, DOI `10.1109/TVCG.2018.2872577`.
4. Cognitive Bias Codex anglais : 188 libellés, fichier daté du 6 juin 2018.
5. Cognitive Bias Codex français : traduction d’Albert Moukheiber et Mariam Chammat ; version comportant des corrections françaises du 8 février 2024.

## Architecture retenue

Le Codex est conservé comme visualisation historique. La navigation principale reproduit séparément le classement employé par Wikipédia anglais : six tâches et cinq sous-catégories appelées « flavors ». Le terme **mécanisme** a été retiré de ce niveau, car ces regroupements ne démontrent pas à eux seuls une cause psychologique commune.

La publication de Dimara et al. décrit pour sa part 154 biais répartis en sept grandes catégories. Le classement Wikipédia actuel s’en inspire, mais il ne doit pas être présenté comme une reproduction exacte de cette taxonomie ni comme une classification universellement admise.

## Niveaux de contrôle

- **Inventaire contrôlé** : présence, intitulé, synonymes, lien et origine de l’entrée.
- **Traduction contrôlée** : terme français attesté ou traduction clairement signalée.
- **Audit scientifique initial** : définition relue et au moins une publication scientifique de départ.
- **Audit scientifique non réalisé** : aucune conclusion de robustesse n’est formulée.

## Import Wikipédia

Le script local :

- résout d’abord la page anglaise et son identifiant Wikidata ;
- récupère le lien français par le sitelink `frwiki`, sans inventer une URL à partir d’une traduction ;
- conserve le titre, l’URL, le numéro et la date de révision ;
- remplace uniquement le bloc `WIKIPEDIA_IMPORT`, sans effacer la fiche critique ;
- télécharge l’image principale seulement en mode `lead` ;
- consigne séparément l’auteur, la source et la licence de chaque média.

## Limites

Cette édition vérifie l’intégrité documentaire et fournit un premier contrôle scientifique de quinze fiches fondamentales. Elle ne prétend pas constituer une revue systématique des 270 concepts. Les fiches non auditées sont volontairement signalées comme telles.

## Licence et attribution

Les textes importés de Wikipédia restent soumis à leur licence applicable. Les transformations — notamment la conversion HTML vers Markdown — doivent être indiquées. Les médias doivent être vérifiés individuellement, car leur licence peut différer de celle du texte.
