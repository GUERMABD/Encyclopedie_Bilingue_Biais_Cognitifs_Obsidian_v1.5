# Rapport de contrôle v0.2

## Périmètre

Contrôle de cohérence interne, des sources structurantes, des liens, des propriétés YAML, des cartes Canvas, des scripts de mise à jour, des attributions et des quinze fiches critiques existantes.

## Erreurs corrigées

- 1 lien interne cassé dans la page d’accueil ;
- 20 listes d’alias contenant une valeur vide ;
- 2 incohérences entre titre et nom de fichier ;
- 3 doublons sémantiques fusionnés : illusion de fréquence / Baader–Meinhof, croyance en un monde juste, homogénéité de l’exogroupe ;
- plusieurs fautes françaises manifestes : *status quo*, *pessimisme*, *insensibilité*, etc. ;
- URLs françaises supposées supprimées lorsqu’elles n’étaient pas contrôlées ;
- terme « mécanismes » remplacé par « sous-catégories / flavors » pour le classement Wikipédia ;
- confusion corrigée entre le classement Wikipédia et la taxonomie originale de Dimara ;
- script de mise à jour rendu non destructif ;
- mode image principale corrigé afin de ne plus télécharger d’abord toutes les images ;
- résolution FR fondée sur Wikidata plutôt que sur une traduction devinée ;
- attribution enrichie avec révision, date, licence et transformations ;
- quinze fiches critiques munies d’une référence scientifique de départ.

## Résultat

- Concepts distincts : **270**.
- Fiches Markdown de biais attendues : **270**.
- Entrées de la liste Wikipédia anglaise : **243**.
- Concepts distincts reliés au Codex : **178**.
- Audit scientifique initial : **15 fiches**.
- Audit scientifique restant : **255 fiches**, explicitement signalées comme non auditées.

## Limite assumée

Le contrôle garantit la cohérence et la traçabilité de cette édition. Il ne transforme pas l’ensemble de l’inventaire en corpus scientifiquement validé : une telle affirmation exigerait une revue de littérature concept par concept.
