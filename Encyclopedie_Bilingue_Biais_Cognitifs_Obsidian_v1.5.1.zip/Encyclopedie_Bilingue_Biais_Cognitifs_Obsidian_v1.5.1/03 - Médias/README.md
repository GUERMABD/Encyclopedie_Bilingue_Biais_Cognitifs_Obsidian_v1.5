# Médias

Les deux versions du **Cognitive Bias Codex** sont stockées localement dans le dossier `Codex`.

Le dossier `Illustrations` n’est créé que lorsqu’une image est réellement téléchargée par le script de mise à jour. Il n’est donc pas livré vide.

Pour chaque média téléchargé, le script doit conserver :

- le titre ;
- l’auteur ;
- l’URL source ;
- la licence ;
- la date de récupération ;
- les éventuelles modifications.

Ne pas supposer que tous les fichiers Wikimedia utilisent la même licence.
