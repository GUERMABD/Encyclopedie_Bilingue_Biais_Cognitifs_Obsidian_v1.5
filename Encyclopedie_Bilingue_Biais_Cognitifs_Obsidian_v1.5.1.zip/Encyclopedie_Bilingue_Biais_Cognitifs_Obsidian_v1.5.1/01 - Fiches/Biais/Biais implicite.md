---
type: categorie-parapluie
nom_fr: Biais implicite
nom_en: Implicit bias
statut_fr: terme français attesté; aucune page française individuelle équivalente validée dans cette édition
traduction: terme français attesté; ancien nom anglais conservé comme alias
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases:
- Unconscious bias
nature_scientifique: catégorie générale d’influences ou associations non explicitement rapportées
robustesse: catégorie utile mais hétérogène; dépend des mesures et des domaines
---
# Biais implicite

> **English:** Implicit bias

## Définition — français

Terme générique désignant des associations, attitudes ou influences sur le jugement qui ne sont pas entièrement accessibles au rapport conscient ou contrôlées intentionnellement.

## Definition — English

An umbrella term for associations, attitudes, or influences on judgment that are not fully available to conscious report or intentionally controlled.

## Exemple

Des critères sociaux peuvent influencer un jugement rapide même lorsque la personne n’énonce pas explicitement la préférence correspondante.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Apprentissage associatif, catégorisation, contexte, habitudes et contrôle cognitif interagissent ; aucun mécanisme unique ne couvre tous les cas.

## Mécanisme probable

Apprentissage associatif, catégorisation, contexte, habitudes et contrôle cognitif interagissent ; aucun mécanisme unique ne couvre tous les cas.

## Analyse critique

« Biais implicite » est une catégorie parapluie, pas un biais singulier. Les termes implicite, inconscient, automatique et incontrôlé ne sont pas interchangeables. Une mesure comme l’IAT ne démontre ni une intention ni un comportement discriminatoire individuel certain ; sa validité dépend du construit et du critère étudiés.

**Conclusion de l’audit :** catégorie pertinente, à définir et mesurer au cas par cas.

## Comment le limiter ou l’étudier correctement ?

Nommer le construit précis, séparer mesure, mécanisme et conséquence, et éviter les inférences individuelles excessives à partir d’un seul test.

## Classement

- Nature scientifique : catégorie générale d’influences ou associations non explicitement rapportées
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : terme français attesté; aucune page française individuelle équivalente validée dans cette édition

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Implicit_stereotype
- Français : aucune page individuelle équivalente validée dans cette édition ; résolution complémentaire prévue via Wikidata.

## Références scientifiques contrôlées

- Greenwald, A. G., & Banaji, M. R. (1995). Implicit social cognition: Attitudes, self-esteem, and stereotypes. *Psychological Review*, 102(1), 4–27. https://doi.org/10.1037/0033-295X.102.1.4
- Greenwald, A. G., Poehlman, T. A., Uhlmann, E. L., & Banaji, M. R. (2009). Understanding and using the Implicit Association Test: III. Meta-analysis of predictive validity. *Journal of Personality and Social Psychology*, 97(1), 17–41. https://doi.org/10.1037/a0015575

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
