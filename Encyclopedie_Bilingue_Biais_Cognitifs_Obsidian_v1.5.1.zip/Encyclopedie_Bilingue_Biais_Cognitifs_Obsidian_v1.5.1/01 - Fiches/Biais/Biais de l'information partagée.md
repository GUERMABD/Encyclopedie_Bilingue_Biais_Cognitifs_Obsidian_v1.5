---
type: biais-cognitif
nom_fr: Biais de l'information partagée
nom_en: Shared information bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais d’échantillonnage de l’information en discussion de groupe
robustesse: bien documenté dans les tâches à profil caché; amplitude dépendante des règles de discussion et des incitations
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Inertia
codex: []
aliases: []
---
# Biais de l'information partagée

> **English:** Shared information bias

## Définition — français

En groupe, les informations connues de plusieurs membres tendent à être davantage discutées que les informations uniques détenues par une seule personne.

## Definition — English

In groups, information shared by several members tends to receive more discussion than unique information held by one member.

## Exemple

Un comité répète les avantages déjà connus de tous et néglige un risque crucial connu d’un seul expert.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Répétition, validation sociale et probabilité plus élevée qu’une information commune soit introduite.

## Mécanisme probable

Répétition, validation sociale et probabilité plus élevée qu’une information commune soit introduite.

## Analyse critique

L’effet est surtout établi dans des tâches où la bonne décision exige de mettre en commun des indices dispersés. Il ne signifie pas que tout groupe ignore toujours l’expertise individuelle.

**Conclusion de l’audit :** bien documenté dans les tâches à profil caché; amplitude dépendante des règles de discussion et des incitations.

## Comment le limiter ?

Faire un tour de table des informations uniques avant le débat et attribuer explicitement des domaines d’expertise.

## Classement

- Nature scientifique : biais d’échantillonnage de l’information en discussion de groupe
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Shared_information_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Stasser, G., & Titus, W. (1985). Pooling of unshared information in group decision making: Biased information sampling during discussion. *Journal of Personality and Social Psychology*, 48(6), 1467–1478. https://doi.org/10.1037/0022-3514.48.6.1467

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
