---
type: biais-cognitif
nom_fr: Biais de similarité supposée
nom_en: Assumed similarity bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de perception interpersonnelle et problème psychométrique
robustesse: effet historique documenté; mesure sensible aux distributions de réponses et aux méthodes de score
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
---
# Biais de similarité supposée

> **English:** Assumed similarity bias

## Définition — français

Tendance à supposer qu’autrui partage davantage ses propres traits, attitudes ou préférences qu’il ne le fait réellement.

## Definition — English

The tendency to assume that others share one’s traits, attitudes, or preferences more than they actually do.

## Exemple

Une personne estime que ses collègues apprécient les mêmes méthodes de travail sans les avoir interrogés.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Projection de soi et usage de sa propre réponse comme point d’ancrage.

## Mécanisme probable

Projection de soi et usage de sa propre réponse comme point d’ancrage.

## Analyse critique

Les anciens indices de « similarité supposée » confondaient parfois précision, projection et styles de réponse. Le concept doit être mesuré avec soin.

**Conclusion de l’audit :** effet historique documenté; mesure sensible aux distributions de réponses et aux méthodes de score.

## Comment le limiter ?

Demander les préférences directement et comparer les prédictions à des réponses réelles.

## Classement

- Nature scientifique : biais de perception interpersonnelle et problème psychométrique
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Assumed_similarity_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Cronbach, L. J. (1955). Processes affecting scores on “understanding of others” and “assumed similarity”. *Psychological Bulletin*, 52(3), 177–193. https://doi.org/10.1037/h0044919

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
