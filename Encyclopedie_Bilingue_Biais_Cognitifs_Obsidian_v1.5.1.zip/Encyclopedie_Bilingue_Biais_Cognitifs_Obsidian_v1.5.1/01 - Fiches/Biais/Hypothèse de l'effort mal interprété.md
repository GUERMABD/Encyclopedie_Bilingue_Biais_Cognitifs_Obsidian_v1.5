---
type: hypothese-metacognitive
nom_fr: Hypothèse de l'effort mal interprété
nom_en: Misinterpreted-effort hypothesis
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: hypothèse selon laquelle l’effort ressenti est interprété comme signe d’un mauvais apprentissage
robustesse: soutien expérimental initial, mais pouvoir explicatif incomplet et effets comportementaux non systématiques
---
# Hypothèse de l'effort mal interprété

> **English:** Misinterpreted-effort hypothesis

## Définition — français

Hypothèse selon laquelle les apprenants interprètent l’effort ou la difficulté comme la preuve qu’une méthode fonctionne mal.

## Definition — English

The hypothesis that learners interpret effort or difficulty as evidence that a learning method is ineffective.

## Exemple

L’entrelacement paraît moins efficace que la répétition en bloc parce qu’il rend la pratique plus difficile.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Jugement métacognitif fondé sur la fluidité immédiate plutôt que sur la rétention future.

## Mécanisme probable

Jugement métacognitif fondé sur la fluidité immédiate plutôt que sur la rétention future.

## Analyse critique

L’effort n’est pas toujours bénéfique et sa réinterprétation ne suffit pas toujours à modifier les choix d’étude.

**Conclusion de l’audit :** soutien expérimental initial, mais pouvoir explicatif incomplet et effets comportementaux non systématiques.

## Comment le limiter ?

Comparer les méthodes avec un test différé et expliquer la différence entre performance pendant l’étude et apprentissage durable.

## Classement

- Nature scientifique : hypothèse selon laquelle l’effort ressenti est interprété comme signe d’un mauvais apprentissage
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Misinterpreted-effort_hypothesis
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kirk-Johnson, A., Galla, B. M., & Fraundorf, S. H. (2019). Perceiving effort as poor learning: The misinterpreted-effort hypothesis of how experienced effort and perceived learning relate to study strategy choice. *Cognitive Psychology*, 115, 101237. https://doi.org/10.1016/j.cogpsych.2019.101237

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
