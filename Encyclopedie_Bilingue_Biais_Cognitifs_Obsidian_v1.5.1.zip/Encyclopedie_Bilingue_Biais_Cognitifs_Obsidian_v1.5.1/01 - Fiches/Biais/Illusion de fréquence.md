---
type: biais-cognitif
nom_fr: Illusion de fréquence
nom_en: Frequency illusion
statut_fr: article français contrôlé le 2026-08-01
traduction: terme français attesté
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: étiquette populaire combinant attention sélective et confirmation
robustesse: mécanismes sous-jacents bien documentés; statut de phénomène scientifique autonome faible
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Baseline
codex:
- Trop d'informations
aliases:
- Baader–Meinhof phenomenon
- Baader–Meinhof Phenomenon
url_fr_verifiee: https://fr.wikipedia.org/wiki/Illusion_de_fr%C3%A9quence
---
# Illusion de fréquence

> **English:** Frequency illusion

## Définition — français

Impression qu’un terme ou un objet apparaît soudain partout après qu’on vient de le découvrir ou de le remarquer.

## Definition — English

The impression that a newly noticed term or object has suddenly become much more frequent.

## Exemple

Après avoir appris le nom d’un modèle de voiture, on croit en voir partout pendant quelques jours.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Saillance récente, disponibilité et mémorisation préférentielle des occurrences concordantes.

## Mécanisme probable

Saillance récente, disponibilité et mémorisation préférentielle des occurrences concordantes.

## Analyse critique

L’« illusion de fréquence » ou phénomène Baader–Meinhof est surtout un nom populaire; elle ne possède pas nécessairement un mécanisme unique distinct. Une hausse réelle de fréquence reste possible.

**Conclusion de l’audit :** mécanismes sous-jacents bien documentés; statut de phénomène scientifique autonome faible.

## Comment le limiter ?

Compter les occurrences avant et après, utiliser une période de référence et rechercher les absences autant que les présences.

## Classement

- Nature scientifique : étiquette populaire combinant attention sélective et confirmation
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Trop d'informations
- Statut français : article français contrôlé le 2026-08-01

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Frequency_illusion
- Français : https://fr.wikipedia.org/wiki/Illusion_de_fr%C3%A9quence

## Références scientifiques contrôlées

- Nickerson, R. S. (1998). Confirmation bias: A ubiquitous phenomenon in many guises. *Review of General Psychology*, 2(2), 175–220. https://doi.org/10.1037/1089-2680.2.2.175
- Tversky, A., & Kahneman, D. (1973). Availability: A heuristic for judging frequency and probability. *Cognitive Psychology*, 5(2), 207–232. https://doi.org/10.1016/0010-0285(73)90033-9

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
