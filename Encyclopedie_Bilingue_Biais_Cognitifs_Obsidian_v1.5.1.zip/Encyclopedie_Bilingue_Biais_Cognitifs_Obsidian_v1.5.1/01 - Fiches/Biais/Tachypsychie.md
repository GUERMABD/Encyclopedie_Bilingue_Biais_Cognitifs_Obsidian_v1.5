---
type: phenomene-temporel
nom_fr: Tachypsychie
nom_en: Tachypsychia
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: altération subjective de la vitesse du temps et des pensées sous forte activation
robustesse: distorsions temporelles sous menace documentées, mais terme hétérogène et non diagnostic autonome
---
# Tachypsychie

> **English:** Tachypsychia

## Définition — français

Sensation que le temps, les événements ou les pensées accélèrent ou ralentissent fortement lors d’une situation intense.

## Definition — English

A feeling that time, events, or thoughts greatly speed up or slow down during an intense situation.

## Exemple

Après une chute, une personne rapporte que la scène semblait se dérouler au ralenti.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Activation émotionnelle, densité de l’encodage et reconstruction rétrospective.

## Mécanisme probable

Activation émotionnelle, densité de l’encodage et reconstruction rétrospective.

## Analyse critique

Une étude de chute libre n’a pas trouvé d’augmentation de la résolution temporelle, malgré une durée rétrospectivement surestimée. Le ressenti ne signifie donc pas que la perception fonctionne réellement plus vite.

**Conclusion de l’audit :** distorsions temporelles sous menace documentées, mais terme hétérogène et non diagnostic autonome.

## Comment le limiter ?

Distinguer expérience pendant l’événement, souvenir ultérieur et performance mesurée; consulter un professionnel en cas de symptômes persistants.

## Classement

- Nature scientifique : altération subjective de la vitesse du temps et des pensées sous forte activation
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Association
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Tachypsychia
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Stetson, C., Fiesta, M. P., & Eagleman, D. M. (2007). Does time really slow down during a frightening event? *PLOS ONE*, 2(12), e1295. https://doi.org/10.1371/journal.pone.0001295

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
