---
type: biais-cognitif
nom_fr: Distraction
nom_en: Absent–mindedness
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: défaillance attentionnelle d’encodage ou de récupération
robustesse: catégorie descriptive établie; pas un biais unique
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Limites de la mémoire
aliases: []
---
# Distraction

> **English:** Absent–mindedness

## Définition — français

Oubli lié à une attention insuffisante au moment de l’encodage ou de l’action.

## Definition — English

Forgetting caused by insufficient attention during encoding or action.

## Exemple

Poser ses clés sans y prêter attention puis ne plus savoir où elles se trouvent.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Ressources attentionnelles partagées et liaison incomplète entre l’action et son contexte.

## Mécanisme probable

Ressources attentionnelles partagées et liaison incomplète entre l’action et son contexte.

## Analyse critique

La distraction est une catégorie de défaillance mnésique, non une loi unique. Elle peut provenir de multiples causes, dont la charge cognitive, les interruptions ou la fatigue.

**Conclusion de l’audit :** catégorie descriptive établie; pas un biais unique.

## Comment le limiter ?

Réduire les interruptions et attribuer des emplacements fixes aux objets et actions récurrents.

## Classement

- Nature scientifique : défaillance attentionnelle d’encodage ou de récupération
- Tâche(s) du classement Wikipédia : aucune
- Sous-catégorie(s) (« flavors ») : aucune
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Absent-mindedness
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Schacter, D. L. (1999). The seven sins of memory: Insights from psychology and cognitive neuroscience. *American Psychologist*, 54(3), 182–203. https://doi.org/10.1037/0003-066X.54.3.182

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
