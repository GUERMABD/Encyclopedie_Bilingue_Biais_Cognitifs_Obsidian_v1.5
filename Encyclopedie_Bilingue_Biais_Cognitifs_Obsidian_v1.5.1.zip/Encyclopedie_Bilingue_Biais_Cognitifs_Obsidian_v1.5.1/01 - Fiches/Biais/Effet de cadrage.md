---
type: famille-effets-de-cadrage
nom_fr: Effet de cadrage
nom_en: Framing effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: famille d’effets où des formulations différentes modifient le jugement ou le choix
robustesse: effets largement reproduits, mais dépendants du type de cadrage et de l’équivalence réelle des formulations
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex:
- Trop d'informations
aliases: []
---
# Effet de cadrage

> **English:** Framing effect

## Définition — français

Variation du jugement ou du choix selon la manière dont une information équivalente est présentée.

## Definition — English

A change in judgment or choice caused by how equivalent information is presented.

## Exemple

Un traitement paraît plus acceptable présenté comme ayant 90 % de survie que 10 % de mortalité.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Référence, saillance et valence positive ou négative de la formulation.

## Mécanisme probable

Référence, saillance et valence positive ou négative de la formulation.

## Analyse critique

Le cadrage désigne plusieurs effets plutôt qu’un mécanisme unique. Les choix peuvent changer lorsque des résultats équivalents sont exprimés en gains ou en pertes, mais l’ampleur dépend de la compréhension, de l’expertise, du domaine et de l’équivalence réelle des formulations.

**Conclusion de l’audit :** famille d’effets établie, à préciser selon le paradigme utilisé.

## Comment le limiter ?

Présenter simultanément les formulations en gain et en perte, avec les valeurs absolues.

## Classement

- Nature scientifique : famille d’effets où des formulations différentes modifient le jugement ou le choix
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Framing_effect_(psychology)
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tversky, A., & Kahneman, D. (1981). The framing of decisions and the psychology of choice. *Science*, 211(4481), 453–458. https://doi.org/10.1126/science.7455683

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
