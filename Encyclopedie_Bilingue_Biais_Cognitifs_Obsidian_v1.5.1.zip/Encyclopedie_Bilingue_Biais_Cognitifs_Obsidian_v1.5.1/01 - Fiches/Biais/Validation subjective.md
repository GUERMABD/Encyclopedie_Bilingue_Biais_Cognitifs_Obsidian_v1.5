---
type: biais-cognitif
nom_fr: Validation subjective
nom_en: Subjective validation
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: processus d’acceptation personnelle de descriptions générales
robustesse: documenté notamment par l’effet Barnum; recouvrement important avec confirmation et mémoire sélective
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex:
- Trop d'informations
aliases: []
---
# Validation subjective

> **English:** Subjective validation

## Définition — français

Tendance à juger une description vague ou générale comme personnellement précise lorsqu’elle semble nous concerner.

## Definition — English

The tendency to judge a vague or general description as personally accurate when it appears to apply to oneself.

## Exemple

Une description de personnalité composée d’énoncés très généraux paraît décrire exactement la personne qui la reçoit.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Recherche de correspondances, oubli des discordances et caractère flatteur ou flexible des énoncés.

## Mécanisme probable

Recherche de correspondances, oubli des discordances et caractère flatteur ou flexible des énoncés.

## Analyse critique

La validation subjective est un mécanisme large et recoupe l’effet Barnum; elle ne doit pas être comptée comme une preuve indépendante de validité d’un test.

**Conclusion de l’audit :** documenté notamment par l’effet Barnum; recouvrement important avec confirmation et mémoire sélective.

## Comment le limiter ?

Tester la description en aveugle, comparer plusieurs profils et mesurer la capacité discriminante.

## Classement

- Nature scientifique : processus d’acceptation personnelle de descriptions générales
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Subjective_validation
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Forer, B. R. (1949). The fallacy of personal validation: A classroom demonstration of gullibility. *Journal of Abnormal and Social Psychology*, 44(1), 118–123. https://doi.org/10.1037/h0059240

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
