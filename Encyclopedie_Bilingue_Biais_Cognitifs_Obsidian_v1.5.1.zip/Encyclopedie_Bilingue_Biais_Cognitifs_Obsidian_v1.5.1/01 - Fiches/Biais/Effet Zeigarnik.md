---
type: biais-cognitif
nom_fr: Effet Zeigarnik
nom_en: Zeigarnik effect
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: hypothèse sur la mémoire des tâches interrompues
robustesse: effet de rappel global fragile et dépendant des conditions
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Effet Zeigarnik

> **English:** Zeigarnik effect

## Définition — français

Hypothèse selon laquelle une tâche interrompue resterait plus accessible en mémoire qu’une tâche achevée.

## Definition — English

The hypothesis that interrupted tasks remain more accessible in memory than completed tasks.

## Exemple

Après avoir interrompu la rédaction d’un message important, une personne y repense plusieurs fois pendant une autre activité, jusqu’à pouvoir le terminer.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Maintien d’un but actif et tension liée à l’inachèvement.

## Mécanisme probable

Maintien d’un but actif et tension liée à l’inachèvement.

## Analyse critique

La méta-analyse récente ne soutient pas un avantage de rappel simple et universel. L’effet doit être distingué de l’effet Ovsiankina, qui concerne la tendance à reprendre une tâche interrompue.

**Conclusion de l’audit :** effet de rappel global fragile et dépendant des conditions.

## Comment le limiter ?

Utiliser une liste d’actions explicite plutôt que compter sur une supposée supériorité automatique des tâches inachevées.

## Classement

- Nature scientifique : hypothèse sur la mémoire des tâches interrompues
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Zeigarnik_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Ghibellini, R., & Meier, B. (2025). Interruption, recall and resumption: A meta-analysis of the Zeigarnik and Ovsiankina effects. *Humanities and Social Sciences Communications*, 12, article 962. https://doi.org/10.1057/s41599-025-05000-w

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
