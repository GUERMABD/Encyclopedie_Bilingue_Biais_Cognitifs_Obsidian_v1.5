---
type: biais-cognitif
nom_fr: Fixité fonctionnelle
nom_en: Functional fixedness
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet classique de résolution de problème
robustesse: robuste dans des tâches bien définies; fortement sensible à l’expérience et à la présentation
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Inertia
codex:
- Manque de sens
aliases: []
---
# Fixité fonctionnelle

> **English:** Functional fixedness

## Définition — français

Difficulté à envisager un objet ou un élément autrement que selon son usage habituel.

## Definition — English

Difficulty seeing an object or component as serving a function other than its conventional use.

## Exemple

Une boîte contenant des punaises n’est pas immédiatement envisagée comme support pour une bougie.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Activation dominante de la fonction familière et limitation de la recherche d’alternatives.

## Mécanisme probable

Activation dominante de la fonction familière et limitation de la recherche d’alternatives.

## Analyse critique

Ce n’est pas un trait permanent. L’expertise peut renforcer certaines routines mais aussi fournir davantage de fonctions possibles.

**Conclusion de l’audit :** robuste dans des tâches bien définies; fortement sensible à l’expérience et à la présentation.

## Comment le limiter ?

Décrire les propriétés physiques sans nommer l’objet et générer plusieurs usages avant de choisir.

## Classement

- Nature scientifique : effet classique de résolution de problème
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Functional_fixedness
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Duncker, K. (1945). On problem-solving. *Psychological Monographs*, 58(5), i–113. https://doi.org/10.1037/h0093599

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
