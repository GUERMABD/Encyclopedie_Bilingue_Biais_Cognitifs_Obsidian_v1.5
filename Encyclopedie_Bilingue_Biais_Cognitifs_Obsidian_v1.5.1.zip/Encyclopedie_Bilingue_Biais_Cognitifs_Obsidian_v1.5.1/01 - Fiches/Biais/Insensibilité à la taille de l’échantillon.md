---
type: biais-cognitif
nom_fr: Insensibilité à la taille de l’échantillon
nom_en: Insensitivity to sample size
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: erreur de jugement statistique
robustesse: classique et bien documentée; niveau dépendant des connaissances et du format
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Baseline
codex:
- Manque de sens
aliases: []
---
# Insensibilité à la taille de l’échantillon

> **English:** Insensitivity to sample size

## Définition — français

Sous-estimation de l’effet de la taille d’un échantillon sur la variabilité et la fiabilité d’un résultat.

## Definition — English

Underestimating how sample size affects variability and reliability.

## Exemple

Un taux extrême observé dans un petit établissement est interprété comme aussi stable que le même taux dans une très grande population.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Représentativité intuitive et négligence de la variance d’échantillonnage.

## Mécanisme probable

Représentativité intuitive et négligence de la variance d’échantillonnage.

## Analyse critique

Les petits échantillons ne sont pas inutiles, mais ils produisent davantage de fluctuations. L’erreur dépend de la question et du plan d’étude.

**Conclusion de l’audit :** classique et bien documentée; niveau dépendant des connaissances et du format.

## Comment le limiter ?

Afficher les effectifs, intervalles d’incertitude et simulations de variabilité.

## Classement

- Nature scientifique : erreur de jugement statistique
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Manque de sens
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Insensitivity_to_sample_size
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tversky, A., & Kahneman, D. (1971). Belief in the law of small numbers. *Psychological Bulletin*, 76(2), 105–110. https://doi.org/10.1037/h0031322

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
