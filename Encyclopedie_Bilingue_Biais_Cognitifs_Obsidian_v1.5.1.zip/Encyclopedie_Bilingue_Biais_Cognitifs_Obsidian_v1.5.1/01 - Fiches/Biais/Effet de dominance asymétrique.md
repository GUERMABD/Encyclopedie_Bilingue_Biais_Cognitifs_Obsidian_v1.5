---
type: biais-cognitif
nom_fr: Effet de dominance asymétrique
nom_en: Decoy effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: effet de contexte dans le choix
robustesse: établie mais hétérogène selon les tâches
---
# Effet de dominance asymétrique

> **English:** Decoy effect

## Définition — français

Modification des préférences provoquée par l’ajout d’une option dominée par une option cible mais non par une autre option concurrente.

## Definition — English

A shift in choice caused by adding an option that is dominated by a target option but not by another competitor.

## Exemple

L’ajout d’un abonnement clairement inférieur à l’offre premium rend cette dernière plus attractive face à l’offre de base.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : L’option leurre fournit une comparaison locale facile et une raison supplémentaire de choisir l’option qui la domine.

## Mécanisme probable

L’option leurre fournit une comparaison locale facile et une raison supplémentaire de choisir l’option qui la domine.

## Analyse critique

L’effet viole la régularité dans certains dispositifs, mais sa taille varie avec les attributs, la présentation, l’expérience et la population. Il ne se produit pas dans tout choix à trois options.

**Conclusion de l’audit :** établie mais hétérogène selon les tâches.

## Comment le limiter ?

Comparer chaque option à des critères fixes, retirer mentalement les options dominées et vérifier si la préférence subsiste dans plusieurs présentations.

## Classement

- Nature scientifique : effet de contexte dans le choix
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Decoy_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Huber, J., Payne, J. W., & Puto, C. (1982). Adding Asymmetrically Dominated Alternatives: Violations of Regularity and the Similarity Hypothesis. *Journal of Consumer Research*, 9(1), 90–98. https://doi.org/10.1086/208899

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
