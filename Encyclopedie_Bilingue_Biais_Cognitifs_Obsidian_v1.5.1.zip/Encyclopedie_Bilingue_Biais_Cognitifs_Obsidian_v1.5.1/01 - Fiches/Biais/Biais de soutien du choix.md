---
type: biais-cognitif
nom_fr: Biais de soutien du choix
nom_en: Choice-supportive bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: distorsion mnésique post-décisionnelle
robustesse: documenté en laboratoire; amplitude dépendante du délai et de l’importance du choix
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Outcome
codex:
- Trop d'informations
aliases:
- Post–purchase rationalization
- Choice–supportive bias
---
# Biais de soutien du choix

> **English:** Choice-supportive bias

## Définition — français

Tendance à se rappeler plus favorablement l’option choisie et moins favorablement les options rejetées.

## Definition — English

The tendency to remember a chosen option more favorably and rejected options less favorably.

## Exemple

Après un achat, une personne attribue à son choix des qualités qui appartenaient en réalité à l’alternative rejetée.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Surveillance de la source et cohérence post-décisionnelle.

## Mécanisme probable

Surveillance de la source et cohérence post-décisionnelle.

## Analyse critique

La préférence présente peut modifier le souvenir des caractéristiques passées. L’effet n’implique pas que toute satisfaction après choix soit irrationnelle.

**Conclusion de l’audit :** documenté en laboratoire; amplitude dépendante du délai et de l’importance du choix.

## Comment le limiter ?

Conserver avant la décision les critères, informations et évaluations des options.

## Classement

- Nature scientifique : distorsion mnésique post-décisionnelle
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Choice-supportive_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Mather, M., Shafir, E., & Johnson, M. K. (2000). Misremembrance of options past: Source monitoring and choice. *Psychological Science*, 11(2), 132–138. https://doi.org/10.1111/1467-9280.00228

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
