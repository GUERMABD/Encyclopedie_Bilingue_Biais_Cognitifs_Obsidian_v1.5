---
type: biais-cognitif
nom_fr: Biais égocentrique
nom_en: Egocentric bias
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de mémoire et d’attribution centré sur sa propre contribution
robustesse: bien documenté; amplitude modulée par visibilité, rôles et relations
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Biais égocentrique

> **English:** Egocentric bias

## Définition — français

Tendance à surestimer sa contribution relative à une activité commune, notamment parce que ses propres actions sont plus accessibles en mémoire.

## Definition — English

The tendency to overestimate one’s relative contribution to a joint activity, partly because one’s own actions are more accessible in memory.

## Exemple

Deux partenaires estiment chacun avoir effectué plus de la moitié des tâches domestiques.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Disponibilité asymétrique des efforts personnels et codage différent des contributions.

## Mécanisme probable

Disponibilité asymétrique des efforts personnels et codage différent des contributions.

## Analyse critique

Des rôles réellement asymétriques peuvent produire des estimations différentes sans biais. La somme des auto-évaluations et des traces objectives aide au diagnostic.

**Conclusion de l’audit :** bien documenté; amplitude modulée par visibilité, rôles et relations.

## Comment le limiter ?

Définir les tâches, tenir un relevé partagé et comparer les contributions sur une période commune.

## Classement

- Nature scientifique : biais de mémoire et d’attribution centré sur sa propre contribution
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Egocentric_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Ross, M., & Sicoly, F. (1979). Egocentric biases in availability and attribution. *Journal of Personality and Social Psychology*, 37(3), 322–336. https://doi.org/10.1037/0022-3514.37.3.322

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
