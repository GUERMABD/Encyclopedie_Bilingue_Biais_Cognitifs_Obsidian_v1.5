---
type: biais-cognitif
nom_fr: Extension des limites
nom_en: Boundary extension
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: distorsion reconstructive de mémoire visuelle
robustesse: effet classique documenté, avec dépendance aux scènes et protocoles
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Extension des limites

> **English:** Boundary extension

## Définition — français

Souvenir d’une scène comme couvrant un champ légèrement plus large que celui réellement présenté.

## Definition — English

Remembering a scene as showing a slightly wider view than was actually presented.

## Exemple

Une photographie rapprochée est rappelée comme si davantage d’arrière-plan avait été visible.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Anticipation de la continuité spatiale au-delà du cadre.

## Mécanisme probable

Anticipation de la continuité spatiale au-delà du cadre.

## Analyse critique

L’effet ne se produit pas de manière identique pour toutes les images et peut être influencé par la comparaison et le délai.

**Conclusion de l’audit :** effet classique documenté, avec dépendance aux scènes et protocoles.

## Comment le limiter ?

Comparer au document original avant d’affirmer ce qui se trouvait hors du cadre.

## Classement

- Nature scientifique : distorsion reconstructive de mémoire visuelle
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Boundary_extension
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Intraub, H., & Richardson, M. (1989). Wide-angle memories of close-up scenes. *Journal of Experimental Psychology: Learning, Memory, and Cognition*, 15(2), 179–187. https://doi.org/10.1037/0278-7393.15.2.179

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
