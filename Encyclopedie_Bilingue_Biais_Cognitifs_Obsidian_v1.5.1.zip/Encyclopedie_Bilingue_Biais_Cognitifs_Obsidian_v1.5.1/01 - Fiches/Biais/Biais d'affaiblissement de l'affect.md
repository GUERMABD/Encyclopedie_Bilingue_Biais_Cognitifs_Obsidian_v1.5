---
type: biais-cognitif
nom_fr: Biais d'affaiblissement de l'affect
nom_en: Fading affect bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: asymétrie affective de la mémoire autobiographique
robustesse: effet moyen documenté, avec variations individuelles et culturelles
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Biais d'affaiblissement de l'affect

> **English:** Fading affect bias

## Définition — français

Tendance moyenne de l’intensité émotionnelle négative à diminuer plus vite que l’intensité positive associée aux souvenirs.

## Definition — English

The average tendency for negative affect linked to memories to fade faster than positive affect.

## Exemple

Une expérience déplaisante paraît moins émotionnellement vive plusieurs mois plus tard, tandis que son versant positif reste plus accessible.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Reconstruction autobiographique, régulation émotionnelle et maintien d’une image de soi cohérente.

## Mécanisme probable

Reconstruction autobiographique, régulation émotionnelle et maintien d’une image de soi cohérente.

## Analyse critique

L’effet porte sur l’affect associé au souvenir, non sur l’exactitude factuelle. Il n’apparaît pas uniformément, notamment dans certains troubles ou contextes culturels.

**Conclusion de l’audit :** effet moyen documenté, avec variations individuelles et culturelles.

## Comment le limiter ?

Noter séparément les faits, l’intensité ressentie et la date de l’évaluation.

## Classement

- Nature scientifique : asymétrie affective de la mémoire autobiographique
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Fading_affect_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Walker, W. R., & Skowronski, J. J. (2009). The fading affect bias: But what the hell is it for? *Applied Cognitive Psychology*, 23(8), 1122–1136. https://doi.org/10.1002/acp.1614

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
