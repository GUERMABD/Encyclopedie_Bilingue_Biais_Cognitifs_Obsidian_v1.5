---
type: biais-cognitif
nom_fr: Réalisme naïf
nom_en: Naïve realism
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: cadre théorique sur la perception de l’objectivité et du désaccord
robustesse: bien soutenu par plusieurs paradigmes sociaux; concept large plutôt qu’effet unique
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Trop d'informations
aliases: []
---
# Réalisme naïf

> **English:** Naïve realism

## Définition — français

Tendance à croire que l’on voit la réalité telle qu’elle est et que les personnes raisonnables disposant des mêmes faits devraient parvenir à la même conclusion.

## Definition — English

The tendency to believe that one sees reality as it is and that reasonable people with the same facts should reach the same conclusion.

## Exemple

Un désaccord est attribué à l’ignorance ou au parti pris de l’autre plutôt qu’à une construction différente de la situation.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Confusion entre expérience subjective immédiate et absence d’interprétation.

## Mécanisme probable

Confusion entre expérience subjective immédiate et absence d’interprétation.

## Analyse critique

Le réalisme naïf est une famille de propositions, non une preuve que toutes les perceptions se valent. Les faits peuvent réellement départager certaines positions.

**Conclusion de l’audit :** bien soutenu par plusieurs paradigmes sociaux; concept large plutôt qu’effet unique.

## Comment le limiter ?

Distinguer observations, catégories et inférences; demander comment une autre personne construit la même situation.

## Classement

- Nature scientifique : cadre théorique sur la perception de l’objectivité et du désaccord
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Naïve_realism_(psychology)
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Robinson, R. J., Keltner, D., Ward, A., & Ross, L. (1995). Actual versus assumed differences in construal: “Naive realism” in intergroup perception and conflict. *Journal of Personality and Social Psychology*, 68(3), 404–417. https://doi.org/10.1037/0022-3514.68.3.404

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
