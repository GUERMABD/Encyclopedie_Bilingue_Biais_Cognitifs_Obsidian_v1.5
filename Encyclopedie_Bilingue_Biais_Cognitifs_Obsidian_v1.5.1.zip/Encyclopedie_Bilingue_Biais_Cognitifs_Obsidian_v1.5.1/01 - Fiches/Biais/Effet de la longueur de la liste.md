---
type: effet-mnesique
nom_fr: Effet de la longueur de la liste
nom_en: List-length effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Baseline
codex:
- Limites de la mémoire
aliases:
- List–length effect
nature_scientifique: effet de la quantité d’items étudiés sur le rappel ou la reconnaissance
robustesse: effet dépendant de la procédure; robuste dans certaines tâches de rappel mais contesté ou réduit dans certains plans de reconnaissance
---
# Effet de la longueur de la liste

> **English:** List-length effect

## Définition — français

Variation des performances de mémoire lorsque le nombre d’éléments étudiés augmente.

## Definition — English

A change in memory performance as the number of studied items increases.

## Exemple

Une liste plus longue produit souvent davantage d’interférences et une proportion de rappel plus faible.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Interférence, temps d’étude par item, contexte de récupération et critère de décision.

## Mécanisme probable

Interférence, temps d’étude par item, contexte de récupération et critère de décision.

## Analyse critique

Il n’existe pas un effet unique valable pour toutes les tâches. Les plans proactifs et rétroactifs peuvent conduire à des résultats différents.

**Conclusion de l’audit :** effet dépendant de la procédure; robuste dans certaines tâches de rappel mais contesté ou réduit dans certains plans de reconnaissance.

## Comment le limiter ?

Comparer des listes avec temps d’exposition et procédure de test équivalents.

## Classement

- Nature scientifique : effet de la quantité d’items étudiés sur le rappel ou la reconnaissance
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Recall_(memory)#Serial_recall
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Dennis, S., Lee, M. D., & Kinnell, A. (2008). Bayesian analysis of recognition memory: The case of the list-length effect. *Journal of Memory and Language*, 59(3), 361–376. https://doi.org/10.1016/j.jml.2008.06.007
- Ensor, T. M., Surprenant, A. M., & Neath, I. (2020). The list-length effect occurs in cued recall with the retroactive design but not the proactive design. *Canadian Journal of Experimental Psychology*, 74(1), 12–24. https://doi.org/10.1037/cep0000187

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
