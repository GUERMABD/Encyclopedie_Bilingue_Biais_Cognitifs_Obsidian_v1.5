---
type: biais-cognitif
nom_fr: Biais de négligence du domaine
nom_en: Domain neglect bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: erreur de résolution interdisciplinaire
robustesse: concept récent et principalement discuté dans l’enseignement de l’apprentissage automatique
---
# Biais de négligence du domaine

> **English:** Domain neglect bias

## Définition — français

Tendance à traiter un problème interdisciplinaire en négligeant les connaissances du domaine d’application.

## Definition — English

The tendency to solve an interdisciplinary problem while neglecting relevant knowledge from the application domain.

## Exemple

Un modèle médical est optimisé statistiquement sans vérifier que ses variables correspondent au processus clinique réel.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Priorité donnée aux méthodes familières et sous-estimation du savoir contextuel.

## Mécanisme probable

Priorité donnée aux méthodes familières et sous-estimation du savoir contextuel.

## Analyse critique

La base publiée est encore étroite et souvent pédagogique. L’expression ne désigne pas une loi cognitive générale indépendante de l’expertise et des structures d’équipe.

**Conclusion de l’audit :** concept récent et principalement discuté dans l’enseignement de l’apprentissage automatique.

## Comment le limiter ?

Associer un spécialiste du domaine, documenter les hypothèses et valider les résultats sur les décisions réelles.

## Classement

- Nature scientifique : erreur de résolution interdisciplinaire
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Domain_neglect_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Mike, K., & Hazzan, O. (2023). What is domain knowledge and why is it important in machine learning education? *IEEE Transactions on Education*, 66(2). https://doi.org/10.1109/TE.2022.3218013

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
