---
type: biais-cognitif
nom_fr: Effet de bizarrerie
nom_en: Bizarreness effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Baseline
codex:
- Trop d'informations
aliases: []
nature_scientifique: effet de distinctivité en mémoire
robustesse: effet conditionnel bien documenté; avantage absent lorsque tout le matériel est bizarre ou mal intégré
---
# Effet de bizarrerie

> **English:** Bizarreness effect

## Définition — français

Meilleur rappel d’éléments bizarres lorsqu’ils se distinguent d’un ensemble principalement ordinaire.

## Definition — English

Better memory for bizarre items when they stand out within mostly ordinary material.

## Exemple

Dans une liste de phrases usuelles, une image mentale inhabituelle est mieux rappelée.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Distinctivité, encodage élaboré et contraste avec le contexte.

## Mécanisme probable

Distinctivité, encodage élaboré et contraste avec le contexte.

## Analyse critique

La bizarrerie seule ne garantit pas un meilleur apprentissage. L’effet dépend d’un plan mixte, du temps d’encodage et de la cohérence de l’image.

**Conclusion de l’audit :** effet conditionnel bien documenté; avantage absent lorsque tout le matériel est bizarre ou mal intégré.

## Comment le limiter ?

Utiliser quelques images distinctives reliées au contenu, sans rendre chaque élément également étrange.

## Classement

- Nature scientifique : effet de distinctivité en mémoire
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Bizarreness_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- McDaniel, M. A., & Einstein, G. O. (1986). Bizarre imagery as an effective memory aid: The importance of distinctiveness. *Journal of Experimental Psychology: Learning, Memory, and Cognition*, 12(1), 54–65. https://doi.org/10.1037/0278-7393.12.1.54

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
