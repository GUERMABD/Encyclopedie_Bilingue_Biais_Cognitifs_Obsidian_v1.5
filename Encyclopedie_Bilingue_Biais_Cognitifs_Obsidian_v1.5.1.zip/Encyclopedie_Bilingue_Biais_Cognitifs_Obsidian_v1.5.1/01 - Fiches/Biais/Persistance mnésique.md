---
type: biais-cognitif
nom_fr: Persistance mnésique
nom_en: Persistence
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: intrusion durable de souvenirs indésirables
robustesse: catégorie descriptive établie; causes et formes multiples
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Persistance mnésique

> **English:** Persistence

## Définition — français

Maintien ou retour involontaire de souvenirs difficiles à écarter.

## Definition — English

The persistent or involuntary return of memories that are difficult to dismiss.

## Exemple

Un événement fortement émotionnel revient à l’esprit malgré la volonté de penser à autre chose.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Saillance émotionnelle, répétition et indices de rappel.

## Mécanisme probable

Saillance émotionnelle, répétition et indices de rappel.

## Analyse critique

La persistance est une catégorie de dysfonctionnement mnésique, pas un biais unique. Elle va du souvenir banalement intrusif aux symptômes cliniques qui exigent une évaluation spécialisée.

**Conclusion de l’audit :** catégorie descriptive établie; causes et formes multiples.

## Comment le limiter ?

Réduire les déclencheurs évitables et chercher une aide professionnelle si les intrusions sont invalidantes.

## Classement

- Nature scientifique : intrusion durable de souvenirs indésirables
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Persistence
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Schacter, D. L. (1999). The seven sins of memory: Insights from psychology and cognitive neuroscience. *American Psychologist*, 54(3), 182–203. https://doi.org/10.1037/0003-066X.54.3.182

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
