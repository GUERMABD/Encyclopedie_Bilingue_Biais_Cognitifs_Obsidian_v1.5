---
type: biais-cognitif
nom_fr: Effet de la victime identifiable
nom_en: Identifiable victim effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Association
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: effet de présentation sur l’aide et le risque
robustesse: effet moyen faible et fortement modéré
---
# Effet de la victime identifiable

> **English:** Identifiable victim effect

## Définition — français

Tendance moyenne à aider davantage une victime identifiable qu’une victime anonyme ou décrite uniquement par des statistiques.

## Definition — English

The average tendency to provide more help to an identifiable victim than to an anonymous or purely statistical victim.

## Exemple

Un appel présentant une personne déjà sélectionnée reçoit davantage de dons qu’un appel indiquant qu’une personne sera choisie plus tard dans la même population.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : L’identification peut accroître l’attention, l’émotion et le sentiment de responsabilité envers une personne précise.

## Mécanisme probable

L’identification peut accroître l’attention, l’émotion et le sentiment de responsabilité envers une personne précise.

## Analyse critique

Les expériences initiales montrent un effet, mais la méta-analyse disponible conclut à un effet moyen relativement faible et sensible au type d’identification et à la comparaison utilisée.

**Conclusion de l’audit :** effet moyen faible et fortement modéré.

## Comment le limiter ?

Combiner récits individuels et statistiques, définir le budget d’aide avant l’exposition aux cas et comparer le bénéfice total attendu.

## Classement

- Nature scientifique : effet de présentation sur l’aide et le risque
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Identifiable_victim_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Small, D. A., & Loewenstein, G. (2003). Helping a Victim or Helping the Victim: Altruism and Identifiability. *Journal of Risk and Uncertainty*, 26(1), 5–16. https://doi.org/10.1023/A:1022299422219
- Lee, S., & Feeley, T. H. (2016). The identifiable victim effect: a meta-analytic review. *Social Influence*, 11(3), 199–215. https://doi.org/10.1080/15534510.2016.1216891

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
