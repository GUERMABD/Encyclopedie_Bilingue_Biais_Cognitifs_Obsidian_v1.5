---
type: biais-cognitif
nom_fr: Biais du risque zéro
nom_en: Zero-risk bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex:
- Nécessité d'agir rapidement
aliases:
- Zero–risk bias
nature_scientifique: préférence dans la réduction des risques
robustesse: à nuancer ; base empirique initiale étroite
---
# Biais du risque zéro

> **English:** Zero-risk bias

## Définition — français

Préférence pour éliminer complètement un risque plutôt que pour obtenir une réduction globale plus importante répartie sur plusieurs risques.

## Definition — English

A preference for completely eliminating one risk rather than achieving a larger overall reduction distributed across risks.

## Exemple

Choisir de supprimer quatre cas attendus sur un site au lieu d’en éviter six au total sur deux sites, parce que le premier risque devient nul.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : La disparition complète d’un risque est plus simple à représenter et procure un sentiment de clôture que les réductions partielles.

## Mécanisme probable

La disparition complète d’un risque est plus simple à représenter et procure un sentiment de clôture que les réductions partielles.

## Analyse critique

Le terme provient notamment d’un ensemble de scénarios de politique des déchets dangereux. Il ne doit pas être présenté comme une loi très générale sans préciser le domaine et la mesure utilisée.

**Conclusion de l’audit :** à nuancer ; base empirique initiale étroite.

## Comment le limiter ?

Comparer les nombres absolus de dommages évités, afficher le coût d’opportunité et évaluer toutes les options sur le même horizon.

## Classement

- Nature scientifique : préférence dans la réduction des risques
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Zero-risk_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Baron, J., Gowda, R., & Kunreuther, H. (1993). Attitudes Toward Managing Hazardous Waste: What Should Be Cleaned Up and Who Should Pay for It? *Risk Analysis*, 13(2), 183–192. https://doi.org/10.1111/j.1539-6924.1993.tb01068.x

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
