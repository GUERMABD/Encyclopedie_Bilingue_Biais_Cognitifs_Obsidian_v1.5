---
type: biais-cognitif
nom_fr: Biais d'autorité
nom_en: Authority bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: étiquette large pour l’influence indue d’une autorité perçue
robustesse: influence de l’autorité bien établie; absence d’un effet unitaire et universel nommé ainsi
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex:
- Manque de sens
aliases: []
---
# Biais d'autorité

> **English:** Authority bias

## Définition — français

Tendance à accorder un poids excessif à une affirmation ou une instruction en raison du statut de sa source.

## Definition — English

The tendency to give excessive weight to a claim or instruction because of the source’s status.

## Exemple

Une recommandation est suivie hors du domaine de compétence de l’expert uniquement à cause de son titre.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Confiance, hiérarchie, transfert de responsabilité et coût de la contestation.

## Mécanisme probable

Confiance, hiérarchie, transfert de responsabilité et coût de la contestation.

## Analyse critique

Suivre une expertise pertinente est souvent rationnel. Les expériences d’obéissance ne prouvent pas à elles seules un biais cognitif universel; le contexte institutionnel est central.

**Conclusion de l’audit :** influence de l’autorité bien établie; absence d’un effet unitaire et universel nommé ainsi.

## Comment le limiter ?

Vérifier le domaine de compétence, les preuves, les conflits d’intérêts et la possibilité d’un second avis.

## Classement

- Nature scientifique : étiquette large pour l’influence indue d’une autorité perçue
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Authority_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Milgram, S. (1963). Behavioral study of obedience. *Journal of Abnormal and Social Psychology*, 67(4), 371–378. https://doi.org/10.1037/h0040525

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
