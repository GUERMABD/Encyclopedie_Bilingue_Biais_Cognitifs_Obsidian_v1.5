---
type: biais-cognitif
nom_fr: Inhibition de la mémoire
nom_en: Memory inhibition
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: réduction de l’accessibilité de souvenirs concurrents
robustesse: effet de récupération induisant l’oubli documenté; mécanisme exact discuté
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Inhibition de la mémoire

> **English:** Memory inhibition

## Définition — français

Diminution du rappel de certaines informations après la récupération répétée d’informations concurrentes.

## Definition — English

Reduced recall of some information after repeated retrieval of competing information.

## Exemple

Répéter certains exemples d’une catégorie rend plus difficile le rappel d’autres exemples associés.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Compétition à la récupération et possible inhibition des concurrents.

## Mécanisme probable

Compétition à la récupération et possible inhibition des concurrents.

## Analyse critique

L’effet ne signifie pas qu’un souvenir est effacé. Les débats portent sur la part de l’inhibition, de l’interférence et des stratégies de test.

**Conclusion de l’audit :** effet de récupération induisant l’oubli documenté; mécanisme exact discuté.

## Comment le limiter ?

Varier les indices et réviser aussi les éléments concurrents.

## Classement

- Nature scientifique : réduction de l’accessibilité de souvenirs concurrents
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Memory_inhibition
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Anderson, M. C., Bjork, R. A., & Bjork, E. L. (1994). Remembering can cause forgetting: Retrieval dynamics in long-term memory. *Journal of Experimental Psychology: Learning, Memory, and Cognition*, 20(5), 1063–1087. https://doi.org/10.1037/0278-7393.20.5.1063

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
