---
type: biais-cognitif
nom_fr: Effet de focus
nom_en: Focusing effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de focalisation dans l’évaluation et la prévision
robustesse: bien documenté dans certains jugements de bien-être; dépendant de la saillance et du contexte comparatif
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Trop d'informations
aliases: []
---
# Effet de focus

> **English:** Focusing effect

## Définition — français

Tendance à donner trop de poids au facteur momentanément mis en avant lorsqu’on évalue une situation globale.

## Definition — English

The tendency to give excessive weight to the factor currently made salient when evaluating an overall situation.

## Exemple

Lorsqu’on demande d’abord le climat, les personnes surestiment son importance pour le bonheur général.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Saillance du facteur focal et négligence des nombreuses autres composantes de l’expérience.

## Mécanisme probable

Saillance du facteur focal et négligence des nombreuses autres composantes de l’expérience.

## Analyse critique

Le facteur focal peut réellement être important. Le biais concerne son poids exagéré relatif aux autres déterminants.

**Conclusion de l’audit :** bien documenté dans certains jugements de bien-être; dépendant de la saillance et du contexte comparatif.

## Comment le limiter ?

Lister les autres facteurs avant l’évaluation et examiner leur contribution sur une période représentative.

## Classement

- Nature scientifique : biais de focalisation dans l’évaluation et la prévision
- Tâche(s) du classement Wikipédia : aucune
- Sous-catégorie(s) (« flavors ») : aucune
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Anchoring_(cognitive_bias)
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Schkade, D. A., & Kahneman, D. (1998). Does living in California make people happy? A focusing illusion in judgments of life satisfaction. *Psychological Science*, 9(5), 340–346. https://doi.org/10.1111/1467-9280.00066

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
