---
type: biais-cognitif
nom_fr: Effet de position sérielle
nom_en: Serial position effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: profil de rappel dépendant de la position dans une liste
robustesse: effet expérimental classique et robuste
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Baseline
codex:
- Limites de la mémoire
aliases:
- Serial–position effect
---
# Effet de position sérielle

> **English:** Serial position effect

## Définition — français

Variation du rappel selon la position d’un élément, avec avantages fréquents pour le début et la fin d’une liste.

## Definition — English

Variation in recall by an item’s position, often favoring the beginning and end of a list.

## Exemple

Les premiers et les derniers mots d’une liste sont mieux rappelés que ceux du milieu.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Répétition et encodage distincts pour le début; disponibilité récente pour la fin.

## Mécanisme probable

Répétition et encodage distincts pour le début; disponibilité récente pour la fin.

## Analyse critique

La forme de la courbe dépend du mode de rappel, du délai, du rythme et des distracteurs.

**Conclusion de l’audit :** effet expérimental classique et robuste.

## Comment le limiter ?

Répartir les informations importantes et éviter de placer tous les éléments critiques au milieu.

## Classement

- Nature scientifique : profil de rappel dépendant de la position dans une liste
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Serial-position_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Murdock, B. B. (1962). The serial position effect of free recall. *Journal of Experimental Psychology*, 64(5), 482–488. https://doi.org/10.1037/h0045106

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
