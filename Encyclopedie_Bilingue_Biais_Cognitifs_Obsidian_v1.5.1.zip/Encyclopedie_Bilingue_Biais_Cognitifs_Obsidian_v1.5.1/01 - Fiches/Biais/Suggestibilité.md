---
type: biais-cognitif
nom_fr: Suggestibilité
nom_en: Suggestibility
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: vulnérabilité de la mémoire aux informations postérieures
robustesse: bien établie; amplitude très dépendante de la procédure
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Suggestibilité

> **English:** Suggestibility

## Définition — français

Modification du souvenir sous l’influence de questions, récits ou informations fournis après l’événement.

## Definition — English

The alteration of memory by questions, narratives, or information supplied after an event.

## Exemple

Une question présupposant un objet absent augmente la probabilité qu’il soit ensuite rapporté.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Intégration de l’information nouvelle et erreur de source.

## Mécanisme probable

Intégration de l’information nouvelle et erreur de source.

## Analyse critique

La suggestibilité n’implique pas que toute information postérieure modifie chaque souvenir. Les formulations, délais et différences individuelles comptent.

**Conclusion de l’audit :** bien établie; amplitude très dépendante de la procédure.

## Comment le limiter ?

Recueillir d’abord un récit libre et utiliser des questions neutres non répétitives.

## Classement

- Nature scientifique : vulnérabilité de la mémoire aux informations postérieures
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Suggestibility
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Schacter, D. L. (1999). The seven sins of memory: Insights from psychology and cognitive neuroscience. *American Psychologist*, 54(3), 182–203. https://doi.org/10.1037/0003-066X.54.3.182
- Loftus, E. F., Miller, D. G., & Burns, H. J. (1978). Semantic integration of verbal information into a visual memory. *Journal of Experimental Psychology: Human Learning and Memory*, 4(1), 19–31. https://doi.org/10.1037/0278-7393.4.1.19

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
