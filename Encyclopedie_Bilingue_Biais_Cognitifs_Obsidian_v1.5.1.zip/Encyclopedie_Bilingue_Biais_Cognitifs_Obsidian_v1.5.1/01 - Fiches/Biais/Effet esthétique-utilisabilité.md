---
type: biais-cognitif
nom_fr: Effet esthétique-utilisabilité
nom_en: Aesthetic–usability effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: influence de l’esthétique sur l’utilisabilité perçue
robustesse: association et effet expérimental documentés; ne garantit pas l’utilisabilité réelle
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Effet esthétique-utilisabilité

> **English:** Aesthetic–usability effect

## Définition — français

Tendance à percevoir une interface esthétiquement agréable comme plus facile à utiliser.

## Definition — English

The tendency to perceive an aesthetically pleasing interface as easier to use.

## Exemple

Deux interfaces fonctionnellement proches reçoivent des notes d’utilisabilité différentes en raison de leur apparence.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Halo esthétique et affect positif initial.

## Mécanisme probable

Halo esthétique et affect positif initial.

## Analyse critique

Une belle interface peut réellement faciliter l’engagement, mais l’impression d’utilisabilité ne remplace pas une mesure des erreurs, du temps et de la réussite.

**Conclusion de l’audit :** association et effet expérimental documentés; ne garantit pas l’utilisabilité réelle.

## Comment le limiter ?

Tester séparément esthétique, performance objective, accessibilité et satisfaction.

## Classement

- Nature scientifique : influence de l’esthétique sur l’utilisabilité perçue
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Aesthetic%E2%80%93usability_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tractinsky, N., Katz, A. S., & Ikar, D. (2000). What is beautiful is usable. *Interacting with Computers*, 13(2), 127–145. https://doi.org/10.1016/S0953-5438(00)00031-X

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
