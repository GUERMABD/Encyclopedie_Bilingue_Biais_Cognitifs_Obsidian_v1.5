---
type: biais-cognitif
nom_fr: Appel à la nouveauté
nom_en: Appeal to novelty
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: sophisme informel
robustesse: catégorie argumentative reconnue; pas un biais cognitif expérimental autonome
---
# Appel à la nouveauté

> **English:** Appeal to novelty

## Définition — français

Affirmer qu’une idée, méthode ou technologie est meilleure principalement parce qu’elle est nouvelle.

## Definition — English

Claiming that an idea, method, or technology is better mainly because it is new.

## Exemple

Un logiciel récent est déclaré supérieur sans comparaison de fiabilité, de coût ou de fonction.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Association implicite entre nouveauté, progrès et supériorité.

## Mécanisme probable

Association implicite entre nouveauté, progrès et supériorité.

## Analyse critique

Une innovation peut réellement être meilleure; le sophisme réside dans l’absence de raison supplémentaire. Cette entrée relève de l’analyse argumentative plus que de la psychologie expérimentale.

**Conclusion de l’audit :** catégorie argumentative reconnue; pas un biais cognitif expérimental autonome.

## Comment le limiter ?

Comparer les performances, limites et coûts avec l’alternative existante selon des critères définis avant le choix.

## Classement

- Nature scientifique : sophisme informel
- Tâche(s) du classement Wikipédia : aucune
- Sous-catégorie(s) (« flavors ») : aucune
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Appeal_to_novelty
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tindale, C. W. (2007). *Fallacies and Argument Appraisal*. Cambridge University Press. https://doi.org/10.1017/CBO9780511806544

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
