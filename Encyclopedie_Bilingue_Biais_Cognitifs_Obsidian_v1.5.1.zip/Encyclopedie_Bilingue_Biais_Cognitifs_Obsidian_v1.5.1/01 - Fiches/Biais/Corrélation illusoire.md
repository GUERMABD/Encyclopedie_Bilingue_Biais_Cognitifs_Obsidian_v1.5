---
type: biais-cognitif
nom_fr: Corrélation illusoire
nom_en: Illusory correlation
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
nature_scientifique: biais de perception des associations
robustesse: établie dans certains paradigmes
---
# Corrélation illusoire

> **English:** Illusory correlation

## Définition — français

Perception ou surestimation d’une relation entre deux catégories d’événements lorsque cette relation est absente ou plus faible que supposé.

## Definition — English

The perception or overestimation of an association between two categories of events when the association is absent or weaker than believed.

## Exemple

Associer davantage un groupe minoritaire à un comportement rare parce que les deux éléments sont distinctifs et donc mieux mémorisés.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : La cooccurrence de deux événements rares attire l’attention et devient plus accessible en mémoire.

## Mécanisme probable

La cooccurrence de deux événements rares attire l’attention et devient plus accessible en mémoire.

## Analyse critique

Le paradigme classique explique une voie possible de formation des stéréotypes, mais ne suffit pas à expliquer toutes les associations sociales ni tous les stéréotypes.

**Conclusion de l’audit :** établie dans certains paradigmes.

## Comment le limiter ?

Construire un tableau de contingence complet et comparer les quatre cases plutôt que de compter seulement les cooccurrences marquantes.

## Classement

- Nature scientifique : biais de perception des associations
- Tâche(s) du classement Wikipédia : Hypothesis assessment; Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Illusory_correlation
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Hamilton, D. L., & Gifford, R. K. (1976). Illusory correlation in interpersonal perception: A cognitive basis of stereotypic judgments. *Journal of Experimental Social Psychology*, 12(4), 392–407. https://doi.org/10.1016/S0022-1031(76)80006-6

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
