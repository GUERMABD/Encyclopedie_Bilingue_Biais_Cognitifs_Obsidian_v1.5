---
type: biais-cognitif
nom_fr: Effet IKEA
nom_en: IKEA effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: valorisation accrue d’un produit auquel on a contribué
robustesse: effet moyen soutenu; dépendant notamment de la réussite de la construction
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Effet IKEA

> **English:** IKEA effect

## Définition — français

Tendance à valoriser davantage un objet ou résultat auquel on a personnellement travaillé.

## Definition — English

The tendency to value an object or outcome more after personally contributing labor to it.

## Exemple

Une personne demande un prix plus élevé pour un meuble qu’elle a assemblé.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Effort, sentiment de compétence et appropriation psychologique.

## Mécanisme probable

Effort, sentiment de compétence et appropriation psychologique.

## Analyse critique

L’effet n’est pas garanti lorsque la tâche échoue ou produit un résultat insatisfaisant. Il doit être distingué de la seule possession.

**Conclusion de l’audit :** effet moyen soutenu; dépendant notamment de la réussite de la construction.

## Comment le limiter ?

Faire évaluer le résultat par des critères externes avant de considérer l’effort investi.

## Classement

- Nature scientifique : valorisation accrue d’un produit auquel on a contribué
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/IKEA_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Norton, M. I., Mochon, D., & Ariely, D. (2012). The IKEA effect: When labor leads to love. *Journal of Consumer Psychology*, 22(3), 453–460. https://doi.org/10.1016/j.jcps.2011.08.002

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
