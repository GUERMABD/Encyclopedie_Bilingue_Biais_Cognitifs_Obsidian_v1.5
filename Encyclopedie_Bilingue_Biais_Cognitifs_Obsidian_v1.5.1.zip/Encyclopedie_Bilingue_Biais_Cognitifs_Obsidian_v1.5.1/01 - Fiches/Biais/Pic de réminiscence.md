---
type: biais-cognitif
nom_fr: Pic de réminiscence
nom_en: Reminiscence bump
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: distribution temporelle de la mémoire autobiographique
robustesse: phénomène bien documenté; âge exact et explications variables
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Pic de réminiscence

> **English:** Reminiscence bump

## Définition — français

Surreprésentation, chez les adultes plus âgés, de souvenirs autobiographiques datant approximativement de l’adolescence et du début de l’âge adulte.

## Definition — English

The overrepresentation, in older adults, of autobiographical memories from adolescence and early adulthood.

## Exemple

Une personne âgée rapporte de nombreux souvenirs de ses années de formation par rapport à des périodes plus proches.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Formation de l’identité, nouveauté des événements et scripts culturels de vie.

## Mécanisme probable

Formation de l’identité, nouveauté des événements et scripts culturels de vie.

## Analyse critique

Le pic varie selon la méthode, la culture et les événements personnels. Il ne signifie pas que cette période est objectivement mieux mémorisée dans tous ses détails.

**Conclusion de l’audit :** phénomène bien documenté; âge exact et explications variables.

## Comment le limiter ?

Dater les souvenirs avec des repères externes et distinguer fréquence de rappel et exactitude.

## Classement

- Nature scientifique : distribution temporelle de la mémoire autobiographique
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Reminiscence_bump
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Munawar, K., Kuhn, S. K., & Haque, S. (2018). Understanding the reminiscence bump: A systematic review. *PLOS ONE*, 13(12), e0208595. https://doi.org/10.1371/journal.pone.0208595

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
