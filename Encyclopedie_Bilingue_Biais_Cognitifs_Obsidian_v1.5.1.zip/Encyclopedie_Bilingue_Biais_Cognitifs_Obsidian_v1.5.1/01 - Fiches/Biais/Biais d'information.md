---
type: biais-cognitif
nom_fr: Biais d'information
nom_en: Information bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: préférence pour une information sans valeur instrumentale
robustesse: effet établi dans certaines tâches diagnostiques; frontière avec curiosité et réduction rationnelle d’incertitude
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Biais d'information

> **English:** Information bias

## Définition — français

Tendance à rechercher une information même lorsqu’elle ne peut pas modifier la décision ou améliorer son résultat.

## Definition — English

The tendency to seek information even when it cannot change the decision or improve the outcome.

## Exemple

Avant de choisir entre deux traitements identiques, une personne demande un test dont le résultat ne changerait aucune option.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Valeur subjective de certitude, curiosité et illusion qu’une information doit être utile.

## Mécanisme probable

Valeur subjective de certitude, curiosité et illusion qu’une information doit être utile.

## Analyse critique

L’information peut avoir une valeur future, émotionnelle ou de coordination. Le biais suppose que cette valeur soit réellement absente ou inférieure à son coût.

**Conclusion de l’audit :** effet établi dans certaines tâches diagnostiques; frontière avec curiosité et réduction rationnelle d’incertitude.

## Comment le limiter ?

Écrire avant la recherche : « quelle décision changera selon chaque résultat ? »; renoncer si aucune branche ne change.

## Classement

- Nature scientifique : préférence pour une information sans valeur instrumentale
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Information_bias_(psychology)
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Baron, J., Beattie, J., & Hershey, J. C. (1988). Heuristics and biases in diagnostic reasoning: II. Congruence, information, and certainty. *Organizational Behavior and Human Decision Processes*, 42(1), 88–110. https://doi.org/10.1016/0749-5978(88)90021-0

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
