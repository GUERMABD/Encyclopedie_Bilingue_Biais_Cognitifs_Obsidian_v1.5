---
type: biais-cognitif
nom_fr: Cryptomnésie
nom_en: Cryptomnesia
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: erreur de mémoire de la source pouvant conduire au plagiat involontaire
robustesse: phénomène expérimental documenté; fréquence réelle difficile à estimer
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Cryptomnésie

> **English:** Cryptomnesia

## Définition — français

Réapparition d’une idée mémorisée qui est vécue à tort comme nouvelle ou personnelle.

## Definition — English

The reappearance of a remembered idea that is mistakenly experienced as new or self-generated.

## Exemple

Un auteur réutilise dans son texte une formulation entendue plusieurs mois auparavant et croit sincèrement qu’il vient de la créer.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Familiarité sans récupération de la source.

## Mécanisme probable

Familiarité sans récupération de la source.

## Analyse critique

La cryptomnésie n’établit pas l’absence d’intention dans un cas concret; elle décrit un mécanisme possible. Elle doit être distinguée de la copie délibérée.

**Conclusion de l’audit :** phénomène expérimental documenté; fréquence réelle difficile à estimer.

## Comment le limiter ?

Tenir un journal des sources et effectuer une recherche d’antériorité avant publication.

## Classement

- Nature scientifique : erreur de mémoire de la source pouvant conduire au plagiat involontaire
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Cryptomnesia
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Brown, A. S., & Murphy, D. R. (1989). Cryptomnesia: Delineating inadvertent plagiarism. *Journal of Experimental Psychology: Learning, Memory, and Cognition*, 15(3), 432–442. https://doi.org/10.1037/0278-7393.15.3.432

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
