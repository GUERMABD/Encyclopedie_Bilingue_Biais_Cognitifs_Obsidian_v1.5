---
type: famille-metacognitive
nom_fr: Illusion d'apprentissage
nom_en: Illusion of learning
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: famille de surestimations de l’apprentissage fondées sur familiarité ou performance immédiate
robustesse: mauvaise calibration largement documentée, mais l’expression ne désigne pas un paradigme unique
---
# Illusion d'apprentissage

> **English:** Illusion of learning

## Définition — français

Impression d’avoir appris durablement alors que la capacité à récupérer ou transférer l’information reste faible.

## Definition — English

The impression of durable learning despite weak later retrieval or transfer.

## Exemple

Relire plusieurs fois un chapitre le rend familier, mais l’étudiant échoue à l’expliquer sans le texte.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Familiarité, fluidité et confusion entre accessibilité présente et rétention future.

## Mécanisme probable

Familiarité, fluidité et confusion entre accessibilité présente et rétention future.

## Analyse critique

Cette entrée est une catégorie générale. Elle recouvre plusieurs illusions métacognitives et ne doit pas remplacer leur identification précise.

**Conclusion de l’audit :** mauvaise calibration largement documentée, mais l’expression ne désigne pas un paradigme unique.

## Comment le limiter ?

Se tester sans support, espacer la récupération et mesurer la performance après un délai.

## Classement

- Nature scientifique : famille de surestimations de l’apprentissage fondées sur familiarité ou performance immédiate
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Illusion_of_learning
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Bjork, R. A., Dunlosky, J., & Kornell, N. (2013). Self-regulated learning: Beliefs, techniques, and illusions. *Annual Review of Psychology*, 64, 417–444. https://doi.org/10.1146/annurev-psych-113011-143823
- Karpicke, J. D., & Roediger, H. L. (2008). The critical importance of retrieval for learning. *Science*, 319(5865), 966–968. https://doi.org/10.1126/science.1152408

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
