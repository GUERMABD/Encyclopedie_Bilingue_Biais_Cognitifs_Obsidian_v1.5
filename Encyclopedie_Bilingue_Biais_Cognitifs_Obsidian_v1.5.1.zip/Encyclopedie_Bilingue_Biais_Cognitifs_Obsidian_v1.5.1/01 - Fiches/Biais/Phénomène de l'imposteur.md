---
type: construit-psychologique
nom_fr: Phénomène de l'imposteur
nom_en: Impostor phenomenon
statut_fr: article français contrôlé le 2026-08-01; appellation scientifique privilégiée dans la fiche
traduction: terme français attesté; « syndrome » conservé comme alias courant
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Self-perspective
codex: []
aliases:
- Syndrome de l'imposteur
- Impostor syndrome
- Imposter phenomenon
nature_scientifique: expérience subjective et construit psychologique
robustesse: construit documenté, définition et mesures encore hétérogènes
url_fr_verifiee: https://fr.wikipedia.org/wiki/Syndrome_de_l%27imposteur
---
# Phénomène de l'imposteur

> **English:** Impostor phenomenon

## Définition — français

Expérience persistante de doute quant à sa compétence et de difficulté à internaliser ses réussites, accompagnée de la crainte d’être démasqué comme illégitime malgré des éléments objectifs favorables.

## Definition — English

A persistent experience of self-doubt and difficulty internalizing achievement, accompanied by fear of being exposed as illegitimate despite objective evidence of competence.

## Exemple

Une personne attribue systématiquement ses réussites à la chance ou à une erreur d’évaluation et s’attend à être bientôt démasquée.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attributions externes des réussites, standards élevés, peur de l’échec et auto-évaluation négative peuvent entretenir le phénomène.

## Mécanisme probable

Attributions externes des réussites, standards élevés, peur de l’échec et auto-évaluation négative peuvent entretenir le phénomène.

## Analyse critique

Le terme scientifique d’origine est « impostor phenomenon ». Il ne s’agit ni d’un diagnostic reconnu ni d’un syndrome clinique défini par des critères médicaux. Les prévalences varient fortement selon les échelles, les seuils et les populations ; le phénomène ne doit pas être utilisé pour pathologiser un doute ponctuel.

**Conclusion de l’audit :** construit utile, non diagnostique et encore imparfaitement standardisé.

## Comment le limiter ou l’étudier correctement ?

Évaluer la durée, le retentissement et les facteurs de contexte plutôt que d’appliquer une étiquette à tout manque de confiance.

## Classement

- Nature scientifique : expérience subjective et construit psychologique
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : absent
- Statut français : article français contrôlé le 2026-08-01; appellation scientifique privilégiée dans la fiche

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Impostor_syndrome
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Syndrome_de_l%27imposteur

## Références scientifiques contrôlées

- Clance, P. R., & Imes, S. A. (1978). The imposter phenomenon in high achieving women: Dynamics and therapeutic intervention. *Psychotherapy: Theory, Research & Practice*, 15(3), 241–247. https://doi.org/10.1037/h0086006
- Mak, K. K. L., Kleitman, S., & Abbott, M. J. (2019). Impostor phenomenon measurement scales: A systematic review. *Frontiers in Psychology*, 10, 671. https://doi.org/10.3389/fpsyg.2019.00671

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
