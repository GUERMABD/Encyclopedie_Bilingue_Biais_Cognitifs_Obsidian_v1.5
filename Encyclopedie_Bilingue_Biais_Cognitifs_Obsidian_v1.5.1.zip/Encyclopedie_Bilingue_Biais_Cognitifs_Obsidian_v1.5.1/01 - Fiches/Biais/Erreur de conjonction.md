---
type: biais-cognitif
nom_fr: Erreur de conjonction
nom_en: Conjunction fallacy
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Association
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: erreur de raisonnement probabiliste
robustesse: établie dans des tâches définies, sensible à la formulation
---
# Erreur de conjonction

> **English:** Conjunction fallacy

## Définition — français

Jugement selon lequel la combinaison de deux événements est plus probable que l’un de ces événements pris seul.

## Definition — English

The judgment that a conjunction of two events is more probable than one of its component events alone.

## Exemple

Après une description très représentative, juger plus probable qu’une personne soit banquière et militante plutôt que simplement banquière.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : La représentativité du scénario peut remplacer l’évaluation des ensembles probabilistes.

## Mécanisme probable

La représentativité du scénario peut remplacer l’évaluation des ensembles probabilistes.

## Analyse critique

La violation formelle est claire lorsque les propositions sont comprises de manière identique. La fréquence de l’erreur diminue avec certaines formulations en fréquences naturelles, et des débats existent sur l’interprétation pragmatique des énoncés.

**Conclusion de l’audit :** établie dans des tâches définies, sensible à la formulation.

## Comment le limiter ?

Écrire explicitement les ensembles : tous les cas A et, à l’intérieur, les cas A et B. Employer des effectifs plutôt que des probabilités abstraites.

## Classement

- Nature scientifique : erreur de raisonnement probabiliste
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Conjunction_fallacy
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tversky, A., & Kahneman, D. (1983). Extensional versus intuitive reasoning: The conjunction fallacy in probability judgment. *Psychological Review*, 90(4), 293–315. https://doi.org/10.1037/0033-295X.90.4.293

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
