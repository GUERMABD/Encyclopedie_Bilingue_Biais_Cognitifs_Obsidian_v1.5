---
type: biais-cognitif
nom_fr: Biais de placement
nom_en: Placement bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Self-perspective
codex: []
aliases: []
nature_scientifique: biais d’auto-positionnement relatif
robustesse: bien documenté; direction dépend fortement de la difficulté et de l’information sur autrui
---
# Biais de placement

> **English:** Placement bias

## Définition — français

Erreur systématique dans l’estimation de son rang ou de sa performance relative par rapport aux autres.

## Definition — English

A systematic error in estimating one’s rank or relative performance compared with others.

## Exemple

Dans une tâche facile, beaucoup se placent au-dessus de la moyenne; dans une tâche difficile, ils peuvent se placer en dessous.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Information plus précise sur sa propre performance que sur celle des autres et jugement égocentrique de la difficulté.

## Mécanisme probable

Information plus précise sur sa propre performance que sur celle des autres et jugement égocentrique de la difficulté.

## Analyse critique

Le biais de placement n’équivaut pas à la surestimation absolue. Une même personne peut surestimer son score tout en sous-estimant son rang.

**Conclusion de l’audit :** bien documenté; direction dépend fortement de la difficulté et de l’information sur autrui.

## Comment le limiter ?

Séparer score absolu et rang relatif, puis fournir la distribution réelle des performances comparables.

## Classement

- Nature scientifique : biais d’auto-positionnement relatif
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Placement_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Moore, D. A., & Cain, D. M. (2007). Overconfidence and underconfidence: When and why people underestimate (and overestimate) the competition. *Organizational Behavior and Human Decision Processes*, 103(2), 197–213. https://doi.org/10.1016/j.obhdp.2006.09.002

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
