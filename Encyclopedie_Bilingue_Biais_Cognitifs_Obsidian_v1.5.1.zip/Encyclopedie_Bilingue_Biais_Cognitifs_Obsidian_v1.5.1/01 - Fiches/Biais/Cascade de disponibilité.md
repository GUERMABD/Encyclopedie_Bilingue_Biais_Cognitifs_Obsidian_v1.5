---
type: biais-cognitif
nom_fr: Cascade de disponibilité
nom_en: Availability cascade
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: processus collectif de diffusion et d’amplification des croyances
robustesse: concept théorique influent avec observations compatibles; causalité difficile à isoler
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Cascade de disponibilité

> **English:** Availability cascade

## Définition — français

Processus par lequel la répétition publique d’une idée augmente sa disponibilité mentale, sa crédibilité apparente et sa diffusion sociale.

## Definition — English

A social process in which public repetition increases an idea’s mental availability, apparent plausibility, and further spread.

## Exemple

Un risque rare devient prioritaire après une succession de récits médiatisés et de réactions politiques qui se renforcent mutuellement.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Disponibilité, imitation informationnelle, réputation et boucle de rétroaction médiatique.

## Mécanisme probable

Disponibilité, imitation informationnelle, réputation et boucle de rétroaction médiatique.

## Analyse critique

Ce n’est pas un biais individuel simple ni une explication automatique de toute panique collective. Plusieurs mécanismes institutionnels et informationnels peuvent produire le même résultat.

**Conclusion de l’audit :** concept théorique influent avec observations compatibles; causalité difficile à isoler.

## Comment le limiter ?

Comparer la fréquence perçue aux données de base et cartographier les sources indépendantes plutôt que le volume de répétition.

## Classement

- Nature scientifique : processus collectif de diffusion et d’amplification des croyances
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Availability_cascade
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kuran, T., & Sunstein, C. R. (1999). Availability cascades and risk regulation. *Stanford Law Review*, 51(4), 683–768. https://doi.org/10.2307/1229439

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
