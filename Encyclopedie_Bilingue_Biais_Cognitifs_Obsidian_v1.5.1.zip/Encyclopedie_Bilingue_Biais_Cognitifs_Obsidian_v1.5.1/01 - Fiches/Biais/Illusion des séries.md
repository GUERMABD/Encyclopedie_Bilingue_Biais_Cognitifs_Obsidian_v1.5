---
type: biais-cognitif
nom_fr: Illusion des séries
nom_en: Clustering illusion
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: erreur de perception de régularités dans des séquences aléatoires
robustesse: classique et bien documentée; dépendante des attentes sur ce que doit être le hasard
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
---
# Illusion des séries

> **English:** Clustering illusion

## Définition — français

Tendance à juger anormaux ou significatifs des regroupements qui peuvent apparaître naturellement dans une suite aléatoire.

## Definition — English

The tendency to treat clusters that naturally occur in random sequences as abnormal or meaningful.

## Exemple

Plusieurs événements semblables survenant à la suite sont interprétés comme la preuve d’une cause cachée.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Mauvaise intuition de la variabilité aléatoire et attente d’une alternance trop régulière.

## Mécanisme probable

Mauvaise intuition de la variabilité aléatoire et attente d’une alternance trop régulière.

## Analyse critique

Un regroupement n’est pas automatiquement aléatoire : la conclusion doit dépendre d’un modèle de référence et d’un test approprié. Ce concept doit aussi être distingué du débat corrigé sur la « main chaude ».

**Conclusion de l’audit :** classique et bien documentée; dépendante des attentes sur ce que doit être le hasard.

## Comment le limiter ?

Définir à l’avance le motif recherché et comparer sa fréquence à une simulation ou à une distribution nulle.

## Classement

- Nature scientifique : erreur de perception de régularités dans des séquences aléatoires
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Clustering_illusion
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Falk, R., & Konold, C. (1997). Making sense of randomness: Implicit encoding as a basis for judgment. *Psychological Review*, 104(2), 301–318. https://doi.org/10.1037/0033-295X.104.2.301

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
