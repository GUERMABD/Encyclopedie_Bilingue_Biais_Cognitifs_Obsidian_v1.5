---
type: biais-cognitif
nom_fr: Effet d'ordre sur le bulletin
nom_en: Ballot order effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex: []
aliases: []
nature_scientifique: effet de position dans les choix électoraux
robustesse: documenté dans plusieurs élections naturelles et expériences; amplitude hétérogène selon règles, information et type de scrutin
---
# Effet d'ordre sur le bulletin

> **English:** Ballot order effect

## Définition — français

Influence de la position d’un candidat ou parti sur le bulletin sur sa part de voix, souvent au bénéfice des premières positions.

## Definition — English

The influence of a candidate’s or party’s ballot position on vote share, often benefiting earlier positions.

## Exemple

À qualité égale, le candidat placé en tête d’une longue liste reçoit légèrement plus de voix.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Primauté, fatigue de recherche, saillance et stratégies de campagne liées à la position.

## Mécanisme probable

Primauté, fatigue de recherche, saillance et stratégies de campagne liées à la position.

## Analyse critique

L’effet moyen n’est pas identique dans tous les scrutins. Les campagnes peuvent aussi réagir à la position, ce qui complique l’attribution directe au seul électeur.

**Conclusion de l’audit :** documenté dans plusieurs élections naturelles et expériences; amplitude hétérogène selon règles, information et type de scrutin.

## Comment le limiter ?

Randomiser ou faire tourner l’ordre des noms et publier la procédure de placement.

## Classement

- Nature scientifique : effet de position dans les choix électoraux
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Ballot_order_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- King, A., & Leigh, A. (2009). Are ballot order effects heterogeneous? *Social Science Quarterly*, 90(1), 71–87. https://doi.org/10.1111/j.1540-6237.2009.00603.x
- Gulzar, S., Robinson, T. S., & Ruiz, N. A. (2022). How campaigns respond to ballot position: A new mechanism for order effects. *The Journal of Politics*, 84(2). https://doi.org/10.1086/715594

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
