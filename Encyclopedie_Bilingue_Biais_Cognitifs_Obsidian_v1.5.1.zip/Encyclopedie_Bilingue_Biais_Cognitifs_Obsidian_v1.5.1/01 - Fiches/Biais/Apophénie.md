---
type: biais-cognitif
nom_fr: Apophénie
nom_en: Apophenia
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: tendance à percevoir des motifs ou liens illusoires
robustesse: phénomènes apparentés bien documentés; terme clinique et populaire plus large que chaque paradigme
---
# Apophénie

> **English:** Apophenia

## Définition — français

Tendance à percevoir une structure, une connexion ou une signification dans des données sans relation suffisante.

## Definition — English

The tendency to perceive structure, connection, or meaning in data that do not sufficiently support it.

## Exemple

Après trois coïncidences sans lien, une personne construit un récit unique et les interprète comme les étapes coordonnées d’un plan caché.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Recherche de régularités, saillance des coïncidences et besoin de contrôle ou d’explication.

## Mécanisme probable

Recherche de régularités, saillance des coïncidences et besoin de contrôle ou d’explication.

## Analyse critique

Détecter des motifs est une fonction utile. L’erreur ne peut être conclue qu’après comparaison avec une hypothèse nulle, les taux attendus et les possibilités de sélection a posteriori.

**Conclusion de l’audit :** phénomènes apparentés bien documentés; terme clinique et populaire plus large que chaque paradigme.

## Comment le limiter ?

Prédéfinir le motif recherché, comparer aux fréquences de hasard et vérifier sur de nouvelles données.

## Classement

- Nature scientifique : tendance à percevoir des motifs ou liens illusoires
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Apophenia
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Whitson, J. A., & Galinsky, A. D. (2008). Lacking control increases illusory pattern perception. *Science*, 322(5898), 115–117. https://doi.org/10.1126/science.1159845

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
