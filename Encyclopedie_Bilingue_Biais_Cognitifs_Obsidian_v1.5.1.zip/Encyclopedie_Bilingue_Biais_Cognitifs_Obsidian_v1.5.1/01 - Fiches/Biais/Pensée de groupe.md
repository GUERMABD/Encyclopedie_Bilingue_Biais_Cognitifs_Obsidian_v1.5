---
type: biais-cognitif
nom_fr: Pensée de groupe
nom_en: Groupthink
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: modèle de défaillance de la décision collective
robustesse: débattue comme théorie unifiée
---
# Pensée de groupe

> **English:** Groupthink

## Définition — français

Modèle selon lequel certaines dynamiques de groupe peuvent réduire l’examen critique des alternatives et favoriser une décision prématurément consensuelle.

## Definition — English

A model in which some group dynamics reduce critical examination of alternatives and promote prematurely consensual decisions.

## Exemple

Une équipe minimise les signaux d’échec d’un projet parce que les objections sont perçues comme une menace pour l’unité du groupe.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Pression à la conformité, leadership directif, isolement informationnel et absence de procédure contradictoire peuvent se combiner.

## Mécanisme probable

Pression à la conformité, leadership directif, isolement informationnel et absence de procédure contradictoire peuvent se combiner.

## Analyse critique

La pensée de groupe n’est pas un biais unique et automatique. La revue de la littérature reconnaît sa valeur heuristique mais souligne une base empirique limitée et des prédictions qui ne sont pas toutes confirmées.

**Conclusion de l’audit :** débattue comme théorie unifiée.

## Comment le limiter ?

Nommer un contradicteur, recueillir les avis avant la discussion, solliciter des experts externes et organiser une seconde réunion après un délai.

## Classement

- Nature scientifique : modèle de défaillance de la décision collective
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : absent du Codex historique
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Groupthink
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Esser, J. K. (1998). Alive and Well after 25 Years: A Review of Groupthink Research. *Organizational Behavior and Human Decision Processes*, 73(2–3), 116–141. https://doi.org/10.1006/obhd.1998.2758

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
