---
type: effet-decision
nom_fr: Effet fantôme
nom_en: Phantom effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex: []
aliases: []
nature_scientifique: effet d’une option attractive mais indisponible sur les préférences entre options disponibles
robustesse: documenté expérimentalement, mais dépendant de la crédibilité, de la proximité et de la structure du choix
---
# Effet fantôme

> **English:** Phantom effect

## Définition — français

Modification du choix par la présence ou l’évocation d’une option qui ne peut finalement pas être sélectionnée.

## Definition — English

A change in choice caused by an attractive option that is mentioned but ultimately unavailable.

## Exemple

Un produit épuisé rend un produit disponible plus attrayant parce qu’il partage certaines caractéristiques avec lui.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Restructuration des comparaisons, ancrage et transfert d’attributs.

## Mécanisme probable

Restructuration des comparaisons, ancrage et transfert d’attributs.

## Analyse critique

L’effet n’est pas automatique et se distingue de l’effet leurre, dont l’option reste disponible mais dominée.

**Conclusion de l’audit :** documenté expérimentalement, mais dépendant de la crédibilité, de la proximité et de la structure du choix.

## Comment le limiter ?

Retirer les options indisponibles avant la comparaison finale et réévaluer les critères.

## Classement

- Nature scientifique : effet d’une option attractive mais indisponible sur les préférences entre options disponibles
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Phantom_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Pratkanis, A. R., & Farquhar, P. H. (1992). A brief history of research on phantom alternatives. *Basic and Applied Social Psychology*, 13(1), 103–122. https://doi.org/10.1207/s15324834basp1301_9

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
