---
type: biais-cognitif
nom_fr: Règle pic-fin
nom_en: Peak–end rule
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: heuristique d’évaluation rétrospective
robustesse: effet méta-analytique robuste; importance relative variable selon les critères de comparaison
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Règle pic-fin

> **English:** Peak–end rule

## Définition — français

Tendance à évaluer une expérience en donnant un poids important à son moment le plus intense et à sa fin.

## Definition — English

The tendency to evaluate an experience by giving substantial weight to its most intense moment and its ending.

## Exemple

Une prestation est jugée surtout d’après son meilleur moment et sa conclusion plutôt que d’après toute sa durée.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Compression rétrospective en moments saillants.

## Mécanisme probable

Compression rétrospective en moments saillants.

## Analyse critique

La méta-analyse corrigée soutient fortement l’influence du pic et de la fin. Leur moyenne prédit toutefois l’évaluation globale à un niveau comparable à la moyenne de l’ensemble de l’expérience; il ne s’agit donc pas d’une règle exclusive.

**Conclusion de l’audit :** effet méta-analytique robuste; importance relative variable selon les critères de comparaison.

## Comment le limiter ?

Évaluer l’expérience avec des mesures répétées et des critères définis avant sa fin.

## Classement

- Nature scientifique : heuristique d’évaluation rétrospective
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Peak–end_rule
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Alaybek, B., Dalal, R. S., Fyffe, S., Aitken, J. A., Zhou, Y., Qu, X., Roman, A., & Baines, J. I. (2022). All’s well that ends (and peaks) well? A meta-analysis of the peak-end rule and duration neglect. *Organizational Behavior and Human Decision Processes*, 170, 104149. https://doi.org/10.1016/j.obhdp.2022.104149
- Alaybek, B., Dalal, R. S., Fyffe, S., Aitken, J. A., Zhou, Y., Qu, X., Roman, A., & Baines, J. I. (2024). Corrigendum to “All’s well that ends (and peaks) well? A meta-analysis of the peak-end rule and duration neglect”. *Organizational Behavior and Human Decision Processes*, 180, 104278. https://doi.org/10.1016/j.obhdp.2023.104278

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
