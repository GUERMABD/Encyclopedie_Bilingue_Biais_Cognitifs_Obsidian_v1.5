---
type: biais-cognitif
nom_fr: Effet de mode
nom_en: Bandwagon effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: famille d’effets d’influence sociale et informationnelle
robustesse: documentée dans plusieurs domaines; ampleur très dépendante du contexte et du signal social
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
---
# Effet de mode

> **English:** Bandwagon effect

## Définition — français

Tendance à adopter une opinion ou un comportement parce qu’il paraît populaire ou en progression.

## Definition — English

The tendency to adopt an opinion or behavior because it appears popular or increasingly common.

## Exemple

Un produit est choisi principalement parce qu’il est présenté comme le plus vendu.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Preuve sociale, coordination, imitation informationnelle et désir d’appartenance.

## Mécanisme probable

Preuve sociale, coordination, imitation informationnelle et désir d’appartenance.

## Analyse critique

La popularité peut contenir une information réelle sur la qualité. Le biais apparaît lorsque le signal social reçoit plus de poids que sa valeur informative justifiée.

**Conclusion de l’audit :** documentée dans plusieurs domaines; ampleur très dépendante du contexte et du signal social.

## Comment le limiter ?

Masquer temporairement les compteurs de popularité et évaluer les critères propres avant de consulter les choix des autres.

## Classement

- Nature scientifique : famille d’effets d’influence sociale et informationnelle
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Bandwagon_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Nadeau, R., Cloutier, E., & Guay, J.-H. (1993). New evidence about the existence of a bandwagon effect in the opinion formation process. *International Political Science Review*, 14(2), 203–213. https://doi.org/10.1177/019251219301400204

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
