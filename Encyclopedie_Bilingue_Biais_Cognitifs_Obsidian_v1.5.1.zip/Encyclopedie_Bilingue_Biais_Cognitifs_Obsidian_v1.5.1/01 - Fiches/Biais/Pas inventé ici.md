---
type: biais-organisationnel
nom_fr: Pas inventé ici
nom_en: Not invented here
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases: []
nature_scientifique: attitude négative envers des connaissances ou solutions provenant de l’extérieur
robustesse: phénomène organisationnel mesurable et documenté; expression dépendante des frontières, de l’identité et de la qualité perçue
---
# Pas inventé ici

> **English:** Not invented here

## Définition — français

Tendance à rejeter ou sous-utiliser une idée parce qu’elle a été créée hors de son équipe ou organisation.

## Definition — English

The tendency to reject or underuse an idea because it originated outside one’s team or organization.

## Exemple

Un service redéveloppe un outil déjà disponible parce qu’il vient d’une autre division.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Identité de groupe, coûts d’intégration, contrôle et dévalorisation de la source externe.

## Mécanisme probable

Identité de groupe, coûts d’intégration, contrôle et dévalorisation de la source externe.

## Analyse critique

Le refus peut être justifié par des problèmes de compatibilité ou de qualité; il faut démontrer que l’origine, et non la valeur, motive le rejet.

**Conclusion de l’audit :** phénomène organisationnel mesurable et documenté; expression dépendante des frontières, de l’identité et de la qualité perçue.

## Comment le limiter ?

Évaluer les solutions anonymement selon les mêmes critères et documenter les coûts réels d’intégration.

## Classement

- Nature scientifique : attitude négative envers des connaissances ou solutions provenant de l’extérieur
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Not_invented_here
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Katz, R., & Allen, T. J. (1982). Investigating the Not Invented Here syndrome. *R&D Management*, 12(1), 7–20. https://doi.org/10.1111/j.1467-9310.1982.tb00478.x
- Antons, D., Declerck, M., Diener, K., Koch, I., & Piller, F. T. (2017). Assessing the not-invented-here syndrome. *Journal of Organizational Behavior*, 38, 1227–1245. https://doi.org/10.1002/job.2199

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
