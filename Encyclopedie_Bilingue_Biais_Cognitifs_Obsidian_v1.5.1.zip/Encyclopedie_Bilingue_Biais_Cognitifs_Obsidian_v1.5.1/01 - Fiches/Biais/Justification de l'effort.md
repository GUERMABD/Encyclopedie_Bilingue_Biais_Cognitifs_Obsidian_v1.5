---
type: biais-cognitif
nom_fr: Justification de l'effort
nom_en: Effort justification
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet de dissonance cognitive
robustesse: classique mais sensible au contexte, à l’engagement et aux alternatives explicatives
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Justification de l'effort

> **English:** Effort justification

## Définition — français

Tendance à valoriser davantage un résultat ou un groupe après avoir consenti un effort coûteux pour l’obtenir ou l’intégrer.

## Definition — English

The tendency to value an outcome or group more after investing costly effort to obtain or join it.

## Exemple

Une initiation pénible conduit certains membres à évaluer plus favorablement un groupe médiocre.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Réduction de la dissonance entre effort important et récompense décevante.

## Mécanisme probable

Réduction de la dissonance entre effort important et récompense décevante.

## Analyse critique

L’effort peut aussi augmenter réellement la compétence, l’attachement ou la rareté. Il faut distinguer ces bénéfices de la rationalisation du coût passé.

**Conclusion de l’audit :** classique mais sensible au contexte, à l’engagement et aux alternatives explicatives.

## Comment le limiter ?

Évaluer la qualité présente indépendamment de l’effort déjà engagé et comparer avec des alternatives.

## Classement

- Nature scientifique : effet de dissonance cognitive
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Effort_justification
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Aronson, E., & Mills, J. (1959). The effect of severity of initiation on liking for a group. *Journal of Abnormal and Social Psychology*, 59(2), 177–181. https://doi.org/10.1037/h0047195

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
