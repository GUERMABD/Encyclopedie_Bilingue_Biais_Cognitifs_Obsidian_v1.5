---
type: biais-cognitif
nom_fr: Biais de fausse unicité
nom_en: False uniqueness bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais d’estimation de la prévalence de ses qualités ou comportements désirables
robustesse: preuves mixtes; dépendance importante au domaine et à la formulation
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex: []
aliases: []
---
# Biais de fausse unicité

> **English:** False uniqueness bias

## Définition — français

Tendance à sous-estimer combien d’autres personnes partagent une qualité ou un comportement personnel jugé désirable.

## Definition — English

The tendency to underestimate how many others share one’s desirable qualities or behaviors.

## Exemple

Une personne qui adopte un comportement de santé se croit beaucoup plus rare qu’elle ne l’est réellement.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Valorisation de soi et faible accès aux comportements privés d’autrui.

## Mécanisme probable

Valorisation de soi et faible accès aux comportements privés d’autrui.

## Analyse critique

La littérature ne retrouve pas un effet général uniforme; certaines études ont observé peu de fausse unicité. Il faut éviter d’en faire une loi symétrique du faux consensus.

**Conclusion de l’audit :** preuves mixtes; dépendance importante au domaine et à la formulation.

## Comment le limiter ?

Comparer l’estimation subjective à des données de prévalence définies pour la même population et la même période.

## Classement

- Nature scientifique : biais d’estimation de la prévalence de ses qualités ou comportements désirables
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/False_uniqueness_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Suls, J., Wan, C. K., & Sanders, G. S. (1988). False consensus and false uniqueness in estimating the prevalence of health-protective behaviors. *Journal of Applied Social Psychology*, 18(1), 66–79. https://doi.org/10.1111/j.1559-1816.1988.tb00006.x
- Marks, G. (1987). In search of the false-uniqueness phenomenon: Fear and estimates of social consensus. *Journal of Personality and Social Psychology*, 52(1), 211–217. https://doi.org/10.1037/0022-3514.52.1.211

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
