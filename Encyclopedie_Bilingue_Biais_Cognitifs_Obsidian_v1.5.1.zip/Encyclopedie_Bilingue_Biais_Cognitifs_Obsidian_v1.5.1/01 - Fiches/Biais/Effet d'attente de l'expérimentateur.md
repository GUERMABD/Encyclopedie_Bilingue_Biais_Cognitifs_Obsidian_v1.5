---
type: biais-methodologique
nom_fr: Effet d'attente de l'expérimentateur
nom_en: Experimenter expectancy effect
statut_fr: article français contrôlé le 2026-08-01
traduction: appellation française harmonisée; anciennes formes conservées comme alias
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
- Self-perspective
codex:
- Trop d'informations
aliases:
- Experimenter's bias
- Expectation bias
- Observer–expectancy effect
- Observer effect
- Attente de l'expérimentateur
- Effet expérimentateur
- Observer-expectancy effect
nature_scientifique: effet méthodologique et interpersonnel
robustesse: menace documentée, ampleur dépendante des tâches et contrôles
url_fr_verifiee: https://fr.wikipedia.org/wiki/Effet_exp%C3%A9rimentateur
---
# Effet d'attente de l'expérimentateur

> **English:** Experimenter expectancy effect

## Définition — français

Modification involontaire des procédures, interactions, observations ou codages d’une étude dans le sens des attentes de l’expérimentateur.

## Definition — English

An unintended alteration of procedures, interactions, observations, or coding in the direction of the experimenter's expectations.

## Exemple

Un expérimentateur connaissant la condition assignée donne inconsciemment des indices différents ou interprète plus favorablement les réponses attendues.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Indices interpersonnels, conduite différenciée, décisions de codage et interprétation peuvent relier l’attente au résultat.

## Mécanisme probable

Indices interpersonnels, conduite différenciée, décisions de codage et interprétation peuvent relier l’attente au résultat.

## Analyse critique

Il s’agit d’une menace méthodologique, non d’un biais cognitif ordinaire du participant. Le terme recouvre plusieurs voies possibles et ne prouve pas qu’un résultat particulier est artificiel ; son importance doit être testée par aveuglement, standardisation et fiabilité inter-évaluateurs.

**Conclusion de l’audit :** menace méthodologique réelle, à démontrer dans chaque protocole.

## Comment le limiter ou l’étudier correctement ?

Employer l’aveuglement, des consignes standardisées, des critères préétablis, l’automatisation du codage et des évaluateurs indépendants.

## Classement

- Nature scientifique : effet méthodologique et interpersonnel
- Tâche(s) du classement Wikipédia : Hypothesis assessment, Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome, Self-perspective
- Codex : Trop d'informations
- Statut français : article français contrôlé le 2026-08-01

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Observer-expectancy_effect
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Effet_exp%C3%A9rimentateur

## Références scientifiques contrôlées

- Rosenthal, R. (1969). Task variations in studies of experimenter expectancy effects. *Perceptual and Motor Skills*, 29(1), 9–20. https://doi.org/10.2466/pms.1969.29.1.9

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
