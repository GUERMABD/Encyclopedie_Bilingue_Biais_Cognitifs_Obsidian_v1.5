---
type: biais-cognitif
nom_fr: Dévaluation réactive
nom_en: Reactive devaluation
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet de source dans l’évaluation de propositions conflictuelles
robustesse: documenté mais dépendant de l’identité, du conflit et de la connaissance de la source
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases: []
---
# Dévaluation réactive

> **English:** Reactive devaluation

## Définition — français

Tendance à juger moins favorablement une proposition identique lorsqu’elle est attribuée à un adversaire.

## Definition — English

The tendency to evaluate the same proposal less favorably when it is attributed to an adversary.

## Exemple

Un plan de compromis est rejeté après révélation qu’il vient du camp opposé, alors qu’il était accepté sans étiquette.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Méfiance envers les intentions, identité de groupe et inférence d’un coût caché.

## Mécanisme probable

Méfiance envers les intentions, identité de groupe et inférence d’un coût caché.

## Analyse critique

Dévaluer une proposition adverse peut parfois refléter une information pertinente sur la fiabilité ou les intentions. Le biais est établi lorsque le contenu pertinent est constant.

**Conclusion de l’audit :** documenté mais dépendant de l’identité, du conflit et de la connaissance de la source.

## Comment le limiter ?

Évaluer d’abord le contenu sans source, puis ajouter séparément les informations réellement pertinentes sur la fiabilité.

## Classement

- Nature scientifique : effet de source dans l’évaluation de propositions conflictuelles
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Reactive_devaluation
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Maoz, I., Ward, A., Katz, M., & Ross, L. (2002). Reactive devaluation of an “Israeli” versus “Palestinian” peace proposal. *Journal of Conflict Resolution*, 46(4), 515–546. https://doi.org/10.1177/0022002702046004003

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
