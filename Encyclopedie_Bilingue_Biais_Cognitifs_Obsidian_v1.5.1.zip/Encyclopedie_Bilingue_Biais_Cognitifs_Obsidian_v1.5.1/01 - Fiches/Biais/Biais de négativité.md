---
type: famille-de-tendances
nom_fr: Biais de négativité
nom_en: Negativity bias
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: famille d’asymétries donnant davantage de poids aux informations négatives
robustesse: nombreux résultats convergents, mais pas d’effet unitaire ni constant
taches_wikipedia:
- Recall
- Opinion reporting
saveurs_classement_wikipedia:
- Baseline
- Association
codex:
- Trop d'informations
- Limites de la mémoire
aliases: []
---
# Biais de négativité

> **English:** Negativity bias

## Définition — français

Poids psychologique souvent supérieur accordé aux informations négatives par rapport aux informations positives comparables.

## Definition — English

The often greater psychological weight given to negative information than to comparable positive information.

## Exemple

Après une évaluation contenant neuf compliments et une critique, une personne repense surtout à la remarque négative pendant toute la soirée.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attention, apprentissage et mémorisation renforcés pour les signaux potentiellement menaçants.

## Mécanisme probable

Attention, apprentissage et mémorisation renforcés pour les signaux potentiellement menaçants.

## Analyse critique

Le terme recouvre plusieurs asymétries distinctes dans l’attention, l’apprentissage, la mémoire et l’évaluation. Le poids supérieur du négatif dépend du domaine, de l’intensité, de la rareté et de la pertinence de l’information.

**Conclusion de l’audit :** tendance générale bien documentée, mais concept trop large pour être traité comme un effet unique.

## Comment le limiter ?

Évaluer séparément fréquence, gravité et représentativité des éléments négatifs.

## Classement

- Nature scientifique : famille d’asymétries donnant davantage de poids aux informations négatives
- Tâche(s) du classement Wikipédia : Recall, Opinion reporting
- Sous-catégorie(s) (« flavors ») : Baseline, Association
- Codex : Trop d'informations, Limites de la mémoire
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Negativity_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Baumeister, R. F., Bratslavsky, E., Finkenauer, C., & Vohs, K. D. (2001). Bad is stronger than good. *Review of General Psychology*, 5(4), 323–370. https://doi.org/10.1037/1089-2680.5.4.323

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
