---
type: biais-cognitif
nom_fr: Réactance
nom_en: Reactance
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: état motivationnel et famille de réponses à une menace sur la liberté
robustesse: robuste comme construction générale; expression et sens du comportement variables
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Outcome
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Réactance

> **English:** Reactance

## Définition — français

Réaction motivationnelle visant à restaurer une liberté perçue comme menacée ou supprimée.

## Definition — English

A motivational response aimed at restoring a freedom perceived as threatened or removed.

## Exemple

Une interdiction formulée de manière autoritaire augmente l’attrait de l’option interdite.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Menace perçue sur l’autonomie, colère et désir de rétablir le choix.

## Mécanisme probable

Menace perçue sur l’autonomie, colère et désir de rétablir le choix.

## Analyse critique

La réactance ne conduit pas toujours à faire exactement l’inverse; elle peut produire contestation, évitement ou réévaluation de la source.

**Conclusion de l’audit :** robuste comme construction générale; expression et sens du comportement variables.

## Comment le limiter ?

Expliquer la raison, préserver des choix réels et employer un langage respectueux de l’autonomie.

## Classement

- Nature scientifique : état motivationnel et famille de réponses à une menace sur la liberté
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Reactance_(psychology)
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Steindl, C., Jonas, E., Sittenthaler, S., Traut-Mattausch, E., & Greenberg, J. (2015). Understanding psychological reactance: New developments and findings. *Zeitschrift für Psychologie*, 223(4), 205–214. https://doi.org/10.1027/2151-2604/a000222

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
