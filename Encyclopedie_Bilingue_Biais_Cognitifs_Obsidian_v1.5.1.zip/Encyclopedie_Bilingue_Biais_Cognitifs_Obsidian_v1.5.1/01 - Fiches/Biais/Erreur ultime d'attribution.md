---
type: biais-cognitif
nom_fr: Erreur ultime d'attribution
nom_en: Ultimate attribution error
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: hypothèse d’attribution intergroupe
robustesse: soutien empirique limité et hétérogène selon les revues
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases: []
---
# Erreur ultime d'attribution

> **English:** Ultimate attribution error

## Définition — français

Tendance proposée à expliquer les actes négatifs de l’exogroupe par ses dispositions et ses actes positifs par les circonstances, avec le schéma inverse pour l’endogroupe.

## Definition — English

A proposed tendency to explain outgroup harm dispositionally and outgroup good behavior situationally, with the reverse pattern for the ingroup.

## Exemple

Une faute de l’autre groupe est attribuée à sa nature, tandis qu’un geste positif est décrit comme exceptionnel ou intéressé.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Favoritisme de groupe et protection d’une image collective positive.

## Mécanisme probable

Favoritisme de groupe et protection d’une image collective positive.

## Analyse critique

La revue de la littérature a trouvé un soutien seulement limité au modèle complet. Les attributions intergroupes varient selon le statut, le conflit et le type d’acte.

**Conclusion de l’audit :** soutien empirique limité et hétérogène selon les revues.

## Comment le limiter ?

Coder séparément valence, groupe, contrôle et contexte; rechercher des données comparables avant de conclure à ce schéma.

## Classement

- Nature scientifique : hypothèse d’attribution intergroupe
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Ultimate_attribution_error
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Pettigrew, T. F. (1979). The ultimate attribution error: Extending Allport’s cognitive analysis of prejudice. *Personality and Social Psychology Bulletin*, 5(4), 461–476. https://doi.org/10.1177/014616727900500407
- Hewstone, M. (1990). The “ultimate attribution error”? A review of the literature on intergroup causal attribution. *European Journal of Social Psychology*, 20(4), 311–335. https://doi.org/10.1002/ejsp.2420200404

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
