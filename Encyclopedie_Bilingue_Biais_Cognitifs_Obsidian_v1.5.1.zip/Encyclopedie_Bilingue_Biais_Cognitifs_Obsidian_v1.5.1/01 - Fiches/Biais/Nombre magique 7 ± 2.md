---
type: resultat-classique
nom_fr: Nombre magique 7 ± 2
nom_en: The magical number 7 ± 2
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Manque de sens
aliases: []
nature_scientifique: estimation historique de limites de traitement et de mémoire immédiate
robustesse: article fondateur mais slogan souvent surinterprété; la capacité centrale non groupée est généralement plus proche de trois à cinq éléments
---
# Nombre magique 7 ± 2

> **English:** The magical number 7 ± 2

## Définition — français

Formule historique selon laquelle plusieurs tâches de traitement immédiat semblent limitées à environ sept unités, avec forte dépendance au regroupement.

## Definition — English

A historical formulation suggesting that several immediate-processing tasks are limited to about seven units, strongly depending on chunking.

## Exemple

Sept chiffres peuvent être retenus plus facilement lorsqu’ils sont regroupés en unités familières.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Capacité limitée, regroupement et connaissances à long terme.

## Mécanisme probable

Capacité limitée, regroupement et connaissances à long terme.

## Analyse critique

Miller ne démontrait pas une constante universelle de la mémoire de travail. Les estimations modernes distinguent tâches, chunks et stratégies et proposent souvent environ quatre unités centrales.

**Conclusion de l’audit :** article fondateur mais slogan souvent surinterprété; la capacité centrale non groupée est généralement plus proche de trois à cinq éléments.

## Comment le limiter ?

Mesurer la tâche précise, contrôler le regroupement et ne pas utiliser 7 ± 2 comme règle universelle de design.

## Classement

- Nature scientifique : estimation historique de limites de traitement et de mémoire immédiate
- Tâche(s) du classement Wikipédia : non repris dans la liste anglaise contrôlée
- Sous-catégorie(s) (« flavors ») : non applicable
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/The_Magical_Number_Seven,_Plus_or_Minus_Two
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Miller, G. A. (1956). The magical number seven, plus or minus two. *Psychological Review*, 63(2), 81–97. https://doi.org/10.1037/h0043158
- Cowan, N. (2001). The magical number 4 in short-term memory. *Behavioral and Brain Sciences*, 24(1), 87–114. https://doi.org/10.1017/S0140525X01003922

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
