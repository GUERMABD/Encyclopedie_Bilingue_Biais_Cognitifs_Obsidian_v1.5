---
type: biais-cognitif
nom_fr: Oubli de la fréquence de base
nom_en: Base rate fallacy
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Baseline
codex:
- Trop d'informations
aliases: []
nature_scientifique: biais de raisonnement probabiliste
robustesse: établie mais très dépendante du format et du contexte
---
# Oubli de la fréquence de base

> **English:** Base rate fallacy

## Définition — français

Sous-pondération de la fréquence de base d’un événement au profit d’une information particulière, souvent plus saillante ou plus représentative.

## Definition — English

The underweighting of an event’s base rate in favor of specific, often more salient or representative, case information.

## Exemple

Évaluer un diagnostic surtout à partir d’un symptôme impressionnant en négligeant que la maladie est très rare dans la population concernée.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Le récit individuel active des associations directes, tandis que la structure statistique des ensembles reste peu visible.

## Mécanisme probable

Le récit individuel active des associations directes, tandis que la structure statistique des ensembles reste peu visible.

## Analyse critique

Le terme “négligence” ne décrit pas toutes les réponses : les personnes utilisent souvent partiellement les taux de base, et leur usage augmente lorsque les ensembles sont rendus transparents ou appris par l’expérience.

**Conclusion de l’audit :** établie mais très dépendante du format et du contexte.

## Comment le limiter ?

Présenter les données sous forme de fréquences naturelles, dessiner les ensembles imbriqués et calculer séparément vrais positifs et faux positifs.

## Classement

- Nature scientifique : biais de raisonnement probabiliste
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Trop d'informations
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Base_rate_fallacy
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kahneman, D., & Tversky, A. (1973). On the psychology of prediction. *Psychological Review*, 80(4), 237–251. https://doi.org/10.1037/h0034747
- Barbey, A. K., & Sloman, S. A. (2007). Base-rate respect: From statistical formats to cognitive structures. *Behavioral and Brain Sciences*, 30(3), 241–254. https://doi.org/10.1017/S0140525X07001963

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
