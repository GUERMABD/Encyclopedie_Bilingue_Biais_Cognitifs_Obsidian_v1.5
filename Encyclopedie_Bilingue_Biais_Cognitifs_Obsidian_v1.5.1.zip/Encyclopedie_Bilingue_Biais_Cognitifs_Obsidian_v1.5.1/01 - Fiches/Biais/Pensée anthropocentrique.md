---
type: strategie-cognitive
nom_fr: Pensée anthropocentrique
nom_en: Anthropocentric thinking
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Self-perspective
codex: []
aliases: []
nature_scientifique: raisonnement sur le vivant ou la nature à partir de l’humain comme référence privilégiée
robustesse: documenté dans certains raisonnements biologiques et téléologiques, mais pas un défaut automatique ni un mécanisme unique
---
# Pensée anthropocentrique

> **English:** Anthropocentric thinking

## Définition — français

Tendance à comprendre des organismes ou phénomènes naturels par analogie avec l’être humain ou comme orientés vers ses besoins.

## Definition — English

The tendency to understand organisms or natural phenomena by analogy with humans or as oriented toward human needs.

## Exemple

Attribuer à une plante des besoins ou intentions calqués directement sur l’expérience humaine.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Accessibilité du modèle humain, analogie et téléologie intuitive.

## Mécanisme probable

Accessibilité du modèle humain, analogie et téléologie intuitive.

## Analyse critique

L’analogie humaine peut être utile sous incertitude. Des travaux indiquent qu’elle n’est pas nécessairement un défaut cognitif automatique persistant.

**Conclusion de l’audit :** documenté dans certains raisonnements biologiques et téléologiques, mais pas un défaut automatique ni un mécanisme unique.

## Comment le limiter ?

Comparer plusieurs espèces, expliciter les limites de l’analogie et utiliser des mécanismes biologiques.

## Classement

- Nature scientifique : raisonnement sur le vivant ou la nature à partir de l’humain comme référence privilégiée
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Anthropocentric_thinking
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Arenson, M., & Coley, J. D. (2018). Anthropocentric by default? Attribution of familiar and novel properties to living things. *Cognitive Science*, 42, 253–285. https://doi.org/10.1111/cogs.12501
- Preston, J. L., & Shin, F. (2021). Anthropocentric biases in teleological thinking. *Journal of Experimental Psychology: General*, 150(5), 943–955. https://doi.org/10.1037/xge0000981

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
