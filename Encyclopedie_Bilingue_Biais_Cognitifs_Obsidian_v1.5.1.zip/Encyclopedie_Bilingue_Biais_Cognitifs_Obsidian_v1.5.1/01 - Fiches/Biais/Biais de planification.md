---
type: biais-de-prevision
nom_fr: Biais de planification
nom_en: Planning fallacy
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: sous-estimation des durées ou coûts futurs malgré l’expérience passée
robustesse: effet bien documenté, avec variations selon les tâches, données et incitations
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
---
# Biais de planification

> **English:** Planning fallacy

## Définition — français

Tendance à sous-estimer la durée, les coûts ou les difficultés d'une tâche future malgré l'expérience de retards comparables.

## Definition — English

The tendency to underestimate the time, cost, or difficulty of a future task despite comparable past delays.

## Exemple

Prévoir deux jours pour un rapport alors que les rapports similaires ont pris une semaine.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Focalisation sur le scénario idéal interne et négligence des statistiques de projets comparables.

## Mécanisme probable

Focalisation sur le scénario idéal interne et négligence des statistiques de projets comparables.

## Analyse critique

Le biais de planification est observé lorsque les prévisions reposent excessivement sur le scénario interne du projet et insuffisamment sur les résultats de projets comparables. Une estimation optimiste n’est toutefois pas toujours un biais : contraintes imposées, incitations stratégiques et incertitude réelle doivent être distinguées.

**Conclusion de l’audit :** biais de prévision établi, à séparer du mensonge stratégique et de l’incertitude normale.

## Comment le limiter ?

Utiliser la vue externe : distribution des durées de projets analogues, marge explicite et découpage en livrables.

## Classement

- Nature scientifique : sous-estimation des durées ou coûts futurs malgré l’expérience passée
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Planning_fallacy
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Buehler, R., Griffin, D., & Ross, M. (1994). Exploring the ‘planning fallacy’: Why people underestimate their task completion times. *Journal of Personality and Social Psychology*, 67(3), 366–381. https://doi.org/10.1037/0022-3514.67.3.366

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
