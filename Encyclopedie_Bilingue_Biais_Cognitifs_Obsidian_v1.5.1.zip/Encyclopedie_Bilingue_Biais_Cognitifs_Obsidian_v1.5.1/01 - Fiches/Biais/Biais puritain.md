---
type: biais-cognitif
nom_fr: Biais puritain
nom_en: Puritanical bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: étiquette d’attribution morale
robustesse: des phénomènes apparentés sont documentés, mais l’étiquette elle-même est peu standardisée
---
# Biais puritain

> **English:** Puritanical bias

## Définition — français

Tendance à expliquer un échec ou un comportement indésirable par un défaut moral ou un manque de volonté en négligeant les contraintes sociales et situationnelles.

## Definition — English

The tendency to explain an undesirable outcome through moral deficiency or lack of willpower while neglecting social and situational constraints.

## Exemple

Le chômage d’une personne est attribué uniquement à la paresse sans examiner le marché, la santé ou les contraintes familiales.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Moralisation de l’autocontrôle et attribution dispositionnelle.

## Mécanisme probable

Moralisation de l’autocontrôle et attribution dispositionnelle.

## Analyse critique

Cette entrée recoupe l’erreur fondamentale d’attribution et les jugements de mérite. Les travaux sur le puritanisme implicite ne valident pas une loi générale portant ce nom.

**Conclusion de l’audit :** des phénomènes apparentés sont documentés, mais l’étiquette elle-même est peu standardisée.

## Comment le limiter ?

Examiner les causes individuelles et structurelles, puis distinguer responsabilité, capacité et conditions de choix.

## Classement

- Nature scientifique : étiquette d’attribution morale
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Puritanical_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Uhlmann, E. L., Poehlman, T. A., Tannenbaum, D., & Bargh, J. A. (2011). Implicit Puritanism in American moral cognition. *Journal of Experimental Social Psychology*, 47(2), 312–320. https://doi.org/10.1016/j.jesp.2010.10.013
- Loewenstein, G. (2018). Self-Control and Its Discontents: A Commentary on Duckworth, Milkman, and Laibson. *Psychological Science in the Public Interest*, 19(3), 95–101. https://doi.org/10.1177/1529100619828401

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
