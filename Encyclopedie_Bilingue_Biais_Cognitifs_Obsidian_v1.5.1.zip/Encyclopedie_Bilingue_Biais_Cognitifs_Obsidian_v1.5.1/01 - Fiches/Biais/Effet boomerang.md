---
type: biais-cognitif
nom_fr: Effet boomerang
nom_en: Backfire effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet possible de correction renforçant une croyance erronée
robustesse: observé dans certains contextes mais effet général rare; les corrections réduisent le plus souvent les erreurs
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Inertia
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Effet boomerang

> **English:** Backfire effect

## Définition — français

Dans certains cas, une correction peut accroître l’adhésion à la croyance qu’elle cherchait à réfuter.

## Definition — English

In some cases, a correction can increase endorsement of the misconception it was intended to reduce.

## Exemple

Après une réfutation fortement identitaire, un sous-groupe affirme plus fermement la croyance initiale.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Réactance, identité, contre-argumentation et mémorisation imparfaite de la correction.

## Mécanisme probable

Réactance, identité, contre-argumentation et mémorisation imparfaite de la correction.

## Analyse critique

La littérature récente ne soutient pas un « effet boomerang » fréquent et inévitable. Les corrections factuelles fonctionnent généralement; il faut distinguer persistance, oubli et véritable augmentation.

**Conclusion de l’audit :** observé dans certains contextes mais effet général rare; les corrections réduisent le plus souvent les erreurs.

## Comment le limiter ?

Corriger clairement avec une explication alternative, citer la source et tester la compréhension sans répéter inutilement le mythe.

## Classement

- Nature scientifique : effet possible de correction renforçant une croyance erronée
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Confirmation_bias#backfire_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Nyhan, B., & Reifler, J. (2010). When corrections fail: The persistence of political misperceptions. *Political Behavior*, 32, 303–330. https://doi.org/10.1007/s11109-010-9112-2
- Wood, T., & Porter, E. (2019). The elusive backfire effect: Mass attitudes’ steadfast factual adherence. *Political Behavior*, 41, 135–163. https://doi.org/10.1007/s11109-018-9443-y

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
