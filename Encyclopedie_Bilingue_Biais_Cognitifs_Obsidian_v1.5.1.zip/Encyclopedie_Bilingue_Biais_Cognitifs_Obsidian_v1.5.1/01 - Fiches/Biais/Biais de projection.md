---
type: biais-cognitif
nom_fr: Biais de projection
nom_en: Projection bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de prévision des préférences futures
robustesse: bien documenté dans plusieurs choix intertemporels; dépendant de l’état et du domaine
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex:
- Manque de sens
aliases: []
---
# Biais de projection

> **English:** Projection bias

## Définition — français

Tendance à projeter excessivement ses goûts ou son état actuel sur ses préférences futures.

## Definition — English

The tendency to project current tastes or states too strongly onto future preferences.

## Exemple

Faire ses courses en ayant faim conduit à surestimer ce que l’on voudra manger plus tard.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Ancrage sur l’état présent et sous-estimation de l’adaptation ou du changement de préférences.

## Mécanisme probable

Ancrage sur l’état présent et sous-estimation de l’adaptation ou du changement de préférences.

## Analyse critique

Une stabilité réelle des préférences n’est pas un biais. Le diagnostic exige de distinguer projection excessive, information rationnelle et incertitude sur le futur.

**Conclusion de l’audit :** bien documenté dans plusieurs choix intertemporels; dépendant de l’état et du domaine.

## Comment le limiter ?

Décider dans un état neutre, consulter des choix passés comparables et prévoir une marge d’adaptation.

## Classement

- Nature scientifique : biais de prévision des préférences futures
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Affective_forecasting#Projection_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Loewenstein, G., O’Donoghue, T., & Rabin, M. (2003). Projection bias in predicting future utility. *Quarterly Journal of Economics*, 118(4), 1209–1248. https://doi.org/10.1162/003355303322552784

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
