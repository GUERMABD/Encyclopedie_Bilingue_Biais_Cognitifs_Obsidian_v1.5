---
type: illusion-perceptive
nom_fr: Paréidolie
nom_en: Pareidolia
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
nature_scientifique: perception d’une forme signifiante, souvent un visage, dans un stimulus ambigu
robustesse: phénomène perceptif robuste, surtout pour les visages; fréquence et interprétation varient entre personnes et stimuli
---
# Paréidolie

> **English:** Pareidolia

## Définition — français

Perception d’un objet ou motif familier dans une configuration ambiguë qui ne contient pas réellement cet objet.

## Definition — English

The perception of a familiar object or pattern in an ambiguous configuration that does not actually contain it.

## Exemple

En regardant l’avant d’une voiture, une personne voit spontanément un visage dans les phares, la calandre et la forme du capot.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Détection rapide de configurations familières et seuil asymétrique favorisant les faux positifs.

## Mécanisme probable

Détection rapide de configurations familières et seuil asymétrique favorisant les faux positifs.

## Analyse critique

La paréidolie ordinaire est fréquente et ne constitue pas en elle-même un trouble ni une croyance délirante.

**Conclusion de l’audit :** phénomène perceptif robuste, surtout pour les visages; fréquence et interprétation varient entre personnes et stimuli.

## Comment le limiter ?

Vérifier avec plusieurs angles, observateurs et informations sensorielles indépendantes.

## Classement

- Nature scientifique : perception d’une forme signifiante, souvent un visage, dans un stimulus ambigu
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Pareidolia
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Wardle, S. G., Taubert, J., Teichmann, L., & Baker, C. I. (2020). Rapid and dynamic processing of face pareidolia in the human brain. *Nature Communications*, 11, 4518. https://doi.org/10.1038/s41467-020-18325-8

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
