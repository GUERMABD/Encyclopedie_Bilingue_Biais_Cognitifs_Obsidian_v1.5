---
type: heuristique
nom_fr: Heuristique de fluidité
nom_en: Fluency heuristic
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: inférence fondée sur la vitesse ou facilité avec laquelle une information est traitée ou reconnue
robustesse: heuristique documentée pouvant être adaptative lorsque la fluidité corrèle avec le critère; biaisante sinon
---
# Heuristique de fluidité

> **English:** Fluency heuristic

## Définition — français

Utilisation de la facilité de traitement comme indice pour estimer une propriété telle que fréquence, familiarité ou vérité.

## Definition — English

Using processing ease as a cue to infer a property such as frequency, familiarity, or truth.

## Exemple

Un nom reconnu plus rapidement est jugé appartenir à une ville plus peuplée.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Substitution d’un indice accessible au critère recherché.

## Mécanisme probable

Substitution d’un indice accessible au critère recherché.

## Analyse critique

La fluidité n’est pas intrinsèquement irrationnelle; elle peut exploiter une corrélation réelle de l’environnement.

**Conclusion de l’audit :** heuristique documentée pouvant être adaptative lorsque la fluidité corrèle avec le critère; biaisante sinon.

## Comment le limiter ?

Identifier ce que la fluidité mesure réellement et vérifier avec une donnée indépendante.

## Classement

- Nature scientifique : inférence fondée sur la vitesse ou facilité avec laquelle une information est traitée ou reconnue
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : absent
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Fluency_heuristic
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Hertwig, R., Herzog, S. M., Schooler, L. J., & Reimer, T. (2008). Fluency heuristic: A model of how the mind exploits a by-product of information retrieval. *Journal of Experimental Psychology: Learning, Memory, and Cognition*, 34(5), 1191–1206. https://doi.org/10.1037/a0013025

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
