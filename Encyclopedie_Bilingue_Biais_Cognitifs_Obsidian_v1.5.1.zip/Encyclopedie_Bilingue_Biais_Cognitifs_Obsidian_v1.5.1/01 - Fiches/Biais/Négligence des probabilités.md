---
type: biais-cognitif
nom_fr: Négligence des probabilités
nom_en: Neglect of probability
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais d’évaluation du risque sous forte charge affective
robustesse: documenté dans certains contextes émotionnels; pas une ignorance générale des probabilités
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex:
- Manque de sens
aliases: []
---
# Négligence des probabilités

> **English:** Neglect of probability

## Définition — français

Tendance à accorder trop peu de poids à la probabilité lorsqu’un résultat suscite une émotion forte.

## Definition — English

The tendency to give too little weight to probability when an outcome evokes strong emotion.

## Exemple

Une menace très effrayante reçoit presque la même réaction qu’elle soit extrêmement improbable ou seulement peu probable.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Réaction affective au résultat et représentation comprimée des probabilités.

## Mécanisme probable

Réaction affective au résultat et représentation comprimée des probabilités.

## Analyse critique

Les individus ne négligent pas toujours les probabilités. L’effet dépend du format numérique, de l’émotion et de la possibilité de comparaison.

**Conclusion de l’audit :** documenté dans certains contextes émotionnels; pas une ignorance générale des probabilités.

## Comment le limiter ?

Afficher fréquences naturelles, conséquences et probabilités dans un même tableau, avec une option de comparaison.

## Classement

- Nature scientifique : biais d’évaluation du risque sous forte charge affective
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Neglect_of_probability
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Rottenstreich, Y., & Hsee, C. K. (2001). Money, kisses, and electric shocks: On the affective psychology of risk. *Psychological Science*, 12(3), 185–190. https://doi.org/10.1111/1467-9280.00334

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
