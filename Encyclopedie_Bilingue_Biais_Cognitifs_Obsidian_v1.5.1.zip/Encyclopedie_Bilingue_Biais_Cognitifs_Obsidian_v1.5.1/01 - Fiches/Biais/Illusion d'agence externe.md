---
type: effet-attribution
nom_fr: Illusion d'agence externe
nom_en: Illusion of external agency
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Manque de sens
aliases: []
nature_scientifique: attribution erronée de sa propre action ou de ses effets à une cause externe
robustesse: phénomènes d’attribution documentés expérimentalement et cliniquement; l’étiquette couvre des situations hétérogènes
---
# Illusion d'agence externe

> **English:** Illusion of external agency

## Définition — français

Expérience dans laquelle une action produite par soi est ressentie ou expliquée comme provenant d’une force extérieure.

## Definition — English

An experience in which one’s own action is felt or explained as originating from an external force.

## Exemple

Dans une tâche guidée subtilement, une personne attribue le mouvement à un dispositif extérieur.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Discordance entre intention, prédiction sensorielle, résultat et explication disponible.

## Mécanisme probable

Discordance entre intention, prédiction sensorielle, résultat et explication disponible.

## Analyse critique

Les expériences de laboratoire ne justifient pas à elles seules une théorie générale du libre arbitre ni une interprétation clinique d’un cas individuel.

**Conclusion de l’audit :** phénomènes d’attribution documentés expérimentalement et cliniquement; l’étiquette couvre des situations hétérogènes.

## Comment le limiter ?

Documenter la chronologie, les commandes réellement exercées et les signaux sensoriels disponibles.

## Classement

- Nature scientifique : attribution erronée de sa propre action ou de ses effets à une cause externe
- Tâche(s) du classement Wikipédia : non repris dans la liste anglaise contrôlée
- Sous-catégorie(s) (« flavors ») : non applicable
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Illusion_of_external_agency
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Wegner, D. M., & Wheatley, T. (1999). Apparent mental causation: Sources of the experience of will. *American Psychologist*, 54(7), 480–492. https://doi.org/10.1037/0003-066X.54.7.480

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
