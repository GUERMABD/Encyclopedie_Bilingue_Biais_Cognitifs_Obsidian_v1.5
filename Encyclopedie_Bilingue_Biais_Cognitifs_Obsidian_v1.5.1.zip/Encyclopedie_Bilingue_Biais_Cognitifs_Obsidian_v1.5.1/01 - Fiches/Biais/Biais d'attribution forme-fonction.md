---
type: biais-cognitif
nom_fr: Biais d'attribution forme-fonction
nom_en: Form-function attribution bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: biais d’attente en interaction humain-robot
robustesse: concept théorique et résultats de domaine; généralisation limitée
---
# Biais d'attribution forme-fonction

> **English:** Form-function attribution bias

## Définition — français

Tendance à déduire les capacités d’un robot ou d’un système à partir de son apparence, même lorsque sa forme ne correspond pas à ses fonctions réelles.

## Definition — English

The tendency to infer a robot’s or system’s capabilities from its appearance even when form does not match actual function.

## Exemple

Un robot à visage humain est supposé comprendre les émotions alors que son logiciel ne le permet pas.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Activation de catégories et d’attentes à partir d’indices morphologiques.

## Mécanisme probable

Activation de catégories et d’attentes à partir d’indices morphologiques.

## Analyse critique

Il s’agit d’un concept spécialisé en interaction humain-robot. Une inférence fondée sur la forme peut être rationnelle lorsque la conception signale effectivement la fonction.

**Conclusion de l’audit :** concept théorique et résultats de domaine; généralisation limitée.

## Comment le limiter ?

Présenter clairement les capacités, tester les attentes des utilisateurs et éviter les formes qui promettent implicitement des fonctions absentes.

## Classement

- Nature scientifique : biais d’attente en interaction humain-robot
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Form-function_attribution_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Haring, K. S., Watanabe, K., Velonaki, M., Tossell, C. C., & Finomore, V. (2018). FFAB—The Form Function Attribution Bias in Human–Robot Interaction. *IEEE Transactions on Cognitive and Developmental Systems*, 10(4), 843–851. https://doi.org/10.1109/TCDS.2018.2851569

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
