---
type: biais-cognitif
nom_fr: A priori erronés
nom_en: False priors
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: catégorie formelle de biais d’estimation
robustesse: mécanisme plausible et modélisé; ce n’est pas un effet expérimental autonome
---
# A priori erronés

> **English:** False priors

## Définition — français

Jugements déformés parce que les croyances initiales utilisées avant l’examen des nouvelles données sont inadaptées ou mal calibrées.

## Definition — English

Judgments distorted because the prior beliefs used before considering new evidence are inappropriate or miscalibrated.

## Exemple

Un diagnostic rare est estimé fréquent dès le départ; même une mise à jour correcte conserve alors une probabilité excessive.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Point de départ probabiliste inadéquat, puis mise à jour à partir de cette base.

## Mécanisme probable

Point de départ probabiliste inadéquat, puis mise à jour à partir de cette base.

## Analyse critique

L’expression désigne surtout une famille d’erreurs bayésiennes. Un a priori différent n’est pas nécessairement irrationnel s’il reflète des informations ou populations différentes.

**Conclusion de l’audit :** mécanisme plausible et modélisé; ce n’est pas un effet expérimental autonome.

## Comment le limiter ?

Rendre les hypothèses initiales explicites, utiliser des taux de base pertinents et tester la sensibilité du résultat à plusieurs a priori.

## Classement

- Nature scientifique : catégorie formelle de biais d’estimation
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/False_priors
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Hilbert, M. (2012). Toward a synthesis of cognitive biases: How noisy information processing can bias human decision making. *Psychological Bulletin*, 138(2), 211–237. https://doi.org/10.1037/a0025940

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
