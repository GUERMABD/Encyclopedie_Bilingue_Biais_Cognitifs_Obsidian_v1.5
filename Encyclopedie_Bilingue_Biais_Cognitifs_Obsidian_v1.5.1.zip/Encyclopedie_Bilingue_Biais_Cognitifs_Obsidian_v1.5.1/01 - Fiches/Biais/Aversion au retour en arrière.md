---
type: biais-cognitif
nom_fr: Aversion au retour en arrière
nom_en: Doubling-back aversion
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Inertia
codex: []
aliases: []
nature_scientifique: effet de décision récemment introduit
robustesse: quatre études préenregistrées et reproductibilité computationnelle; réplications indépendantes encore limitées
---
# Aversion au retour en arrière

> **English:** Doubling-back aversion

## Définition — français

Réticence à choisir une voie plus efficace lorsqu’elle exige d’annuler ou de retracer une partie du progrès déjà accompli.

## Definition — English

Reluctance to choose a more efficient route when it requires undoing or retracing part of the progress already made.

## Exemple

Un trajet plus rapide est refusé parce qu’il commence par revenir vers le point de départ.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Impression de gaspiller l’effort passé et représentation négative du chemin restant.

## Mécanisme probable

Impression de gaspiller l’effort passé et représentation négative du chemin restant.

## Analyse critique

L’effet a été distingué du statu quo et des coûts irrécupérables, mais il a été nommé en 2025 et sa généralisation hors des paradigmes initiaux reste à établir.

**Conclusion de l’audit :** quatre études préenregistrées et reproductibilité computationnelle; réplications indépendantes encore limitées.

## Comment le limiter ?

Comparer le coût total restant de chaque option et traiter l’étape de retour comme un moyen, non comme une perte du progrès passé.

## Classement

- Nature scientifique : effet de décision récemment introduit
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Doubling-back_aversion
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Cho, K. Y., & Critcher, C. R. (2025). Doubling-back aversion: A reluctance to make progress by undoing it. *Psychological Science*, 36(5). https://doi.org/10.1177/09567976251331053

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
