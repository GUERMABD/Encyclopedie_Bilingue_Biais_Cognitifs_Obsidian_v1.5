---
type: biais-cognitif
nom_fr: Mot sur le bout de la langue
nom_en: Tip of the tongue
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: état de récupération lexicale partielle
robustesse: phénomène robuste et courant
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases:
- Tip of the tongue phenomenon
---
# Mot sur le bout de la langue

> **English:** Tip of the tongue

## Définition — français

Impression de connaître un mot sans parvenir momentanément à le produire, avec accès possible à certaines de ses caractéristiques.

## Definition — English

The feeling of knowing a word while being temporarily unable to produce it, sometimes with partial access to its features.

## Exemple

Le nom d’une personne semble imminent et sa première lettre est accessible, mais le mot ne vient pas.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Activation sémantique sans récupération phonologique complète.

## Mécanisme probable

Activation sémantique sans récupération phonologique complète.

## Analyse critique

Les indices partiels peuvent être exacts ou erronés. Le phénomène augmente avec certains mots et avec l’âge, mais n’indique pas à lui seul un trouble.

**Conclusion de l’audit :** phénomène robuste et courant.

## Comment le limiter ?

Faire une pause, changer d’indice ou consulter la source plutôt que répéter une piste erronée.

## Classement

- Nature scientifique : état de récupération lexicale partielle
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Tip_of_the_tongue
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Brown, R., & McNeill, D. (1966). The “tip of the tongue” phenomenon. *Journal of Verbal Learning and Verbal Behavior*, 5(4), 325–337. https://doi.org/10.1016/S0022-5371(66)80040-3

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
