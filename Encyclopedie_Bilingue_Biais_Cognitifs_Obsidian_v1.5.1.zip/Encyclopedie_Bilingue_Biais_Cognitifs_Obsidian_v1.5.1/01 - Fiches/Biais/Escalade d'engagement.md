---
type: comportement-de-decision
nom_fr: Escalade d'engagement
nom_en: Escalation of commitment
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: poursuite accrue d’une décision antérieure malgré des résultats défavorables
robustesse: phénomène bien documenté, mais produit par plusieurs mécanismes et pas toujours irrationnel
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Inertia
codex:
- Nécessité d'agir rapidement
aliases:
- Sunk cost fallacy
- Irrational escalation
---
# Escalade d'engagement

> **English:** Escalation of commitment

## Définition — français

Poursuite ou augmentation d'un engagement malgré des informations montrant que la décision initiale est probablement mauvaise.

## Definition — English

Continuing or increasing a commitment despite evidence that the original decision is probably wrong.

## Exemple

Financer encore un projet déficitaire pour ne pas reconnaître que les dépenses passées sont perdues.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Coûts irrécupérables, cohérence identitaire, justification de la décision et peur de l'échec visible.

## Mécanisme probable

Coûts irrécupérables, cohérence identitaire, justification de la décision et peur de l'échec visible.

## Analyse critique

L’escalade d’engagement est observée lorsque la responsabilité d’une décision antérieure et ses conséquences négatives favorisent un investissement supplémentaire. Elle doit être distinguée d’une poursuite rationnelle fondée sur de nouvelles informations, de coûts de sortie élevés ou d’une valeur future réellement positive.

**Conclusion de l’audit :** comportement de décision établi, à qualifier selon les informations disponibles.

## Comment le limiter ?

Définir à l'avance des critères d'arrêt et confier la revue à une personne non impliquée dans la décision initiale.

## Classement

- Nature scientifique : poursuite accrue d’une décision antérieure malgré des résultats défavorables
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Escalation_of_commitment
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Staw, B. M. (1976). Knee-deep in the big muddy: A study of escalating commitment to a chosen course of action. *Organizational Behavior and Human Performance*, 16(1), 27–44. https://doi.org/10.1016/0030-5073(76)90005-2

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
