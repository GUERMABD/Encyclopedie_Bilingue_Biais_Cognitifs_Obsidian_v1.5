---
type: biais-cognitif
nom_fr: Biais de congruence
nom_en: Congruence bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de test d’hypothèse
robustesse: bien documenté dans des tâches diagnostiques; sensible à la formation et au format
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex:
- Trop d'informations
aliases: []
---
# Biais de congruence

> **English:** Congruence bias

## Définition — français

Préférence pour des tests dont le résultat attendu serait compatible avec l’hypothèse envisagée, au détriment de tests plus discriminants.

## Definition — English

A preference for tests whose expected outcome is compatible with the focal hypothesis rather than tests that best discriminate among hypotheses.

## Exemple

Pour vérifier si une maladie est présente, on demande surtout les symptômes attendus et peu ceux qui distingueraient une autre maladie.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Focalisation sur l’hypothèse active et confusion entre résultat compatible et résultat probant.

## Mécanisme probable

Focalisation sur l’hypothèse active et confusion entre résultat compatible et résultat probant.

## Analyse critique

Ce biais est proche mais non identique au biais de confirmation : un test congruent peut parfois être rationnel, selon les coûts et les probabilités.

**Conclusion de l’audit :** bien documenté dans des tâches diagnostiques; sensible à la formation et au format.

## Comment le limiter ?

Comparer explicitement la valeur diagnostique des résultats possibles pour plusieurs hypothèses concurrentes.

## Classement

- Nature scientifique : biais de test d’hypothèse
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Congruence_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Baron, J., Beattie, J., & Hershey, J. C. (1988). Heuristics and biases in diagnostic reasoning: II. Congruence, information, and certainty. *Organizational Behavior and Human Decision Processes*, 42(1), 88–110. https://doi.org/10.1016/0749-5978(88)90021-0

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
