---
type: biais-cognitif
nom_fr: Biais de comparaison sociale
nom_en: Social comparison bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases:
- Social comparison effect
nature_scientifique: biais de recommandation et de compétition interpersonnelle
robustesse: effet expérimental documenté mais contexte organisationnel spécifique
---
# Biais de comparaison sociale

> **English:** Social comparison bias

## Définition — français

Réticence à recommander ou aider une personne comparable à soi lorsqu’elle pourrait devenir un concurrent direct.

## Definition — English

Reluctance to recommend or help a person similar to oneself when that person could become a direct competitor.

## Exemple

Un recruteur recommande moins un candidat excellent dans sa propre spécialité qu’un candidat excellent dans une autre spécialité.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Menace sur le statut et comparaison avec un rival proche.

## Mécanisme probable

Menace sur le statut et comparaison avec un rival proche.

## Analyse critique

Cette entrée ne désigne pas toute comparaison sociale. L’effet dépend de la compétition, de la proximité du domaine et des incitations.

**Conclusion de l’audit :** effet expérimental documenté mais contexte organisationnel spécifique.

## Comment le limiter ?

Séparer l’évaluation du candidat de l’intérêt personnel, employer plusieurs évaluateurs et des critères prédéfinis.

## Classement

- Nature scientifique : biais de recommandation et de compétition interpersonnelle
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Social_comparison_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Garcia, S. M., Song, H., & Tesser, A. (2010). Tainted recommendations: The social comparison bias. *Organizational Behavior and Human Decision Processes*, 113(2), 97–101. https://doi.org/10.1016/j.obhdp.2010.06.002

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
