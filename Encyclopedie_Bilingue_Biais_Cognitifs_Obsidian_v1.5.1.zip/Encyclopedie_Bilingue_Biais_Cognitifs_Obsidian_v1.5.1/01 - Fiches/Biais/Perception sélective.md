---
type: biais-cognitif
nom_fr: Perception sélective
nom_en: Selective perception
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: terme descriptif large sur la sélection et l’interprétation de l’information
robustesse: phénomènes sous-jacents bien documentés; concept trop large pour une robustesse unique
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Trop d'informations
aliases: []
---
# Perception sélective

> **English:** Selective perception

## Définition — français

Tendance générale à remarquer ou interpréter davantage les informations compatibles avec les attentes, objectifs ou intérêts du moment.

## Definition — English

A broad tendency to notice or interpret information in ways compatible with current expectations, goals, or interests.

## Exemple

Deux supporters regardent le même match et rapportent davantage de fautes commises par l’équipe adverse.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attention orientée, attentes perceptives et interprétation motivée.

## Mécanisme probable

Attention orientée, attentes perceptives et interprétation motivée.

## Analyse critique

La « perception sélective » regroupe plusieurs mécanismes et n’est pas un effet expérimental unique. Une différence de perception peut aussi venir de positions ou d’informations différentes.

**Conclusion de l’audit :** phénomènes sous-jacents bien documentés; concept trop large pour une robustesse unique.

## Comment le limiter ?

Définir les observations codables, utiliser des évaluateurs indépendants et distinguer ce qui a été vu de son interprétation.

## Classement

- Nature scientifique : terme descriptif large sur la sélection et l’interprétation de l’information
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Trop d'informations
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Selective_perception
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Hastorf, A. H., & Cantril, H. (1954). They saw a game: A case study. *Journal of Abnormal and Social Psychology*, 49(1), 129–134. https://doi.org/10.1037/h0057880

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
