---
type: biais-cognitif
nom_fr: Biais de poursuite du plan
nom_en: Plan continuation bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Inertia
codex: []
aliases: []
nature_scientifique: biais de décision opérationnelle sous pression
robustesse: bien documenté en sécurité aérienne et domaines analogues; définition et mesure contextuelles
---
# Biais de poursuite du plan

> **English:** Plan continuation bias

## Définition — français

Tendance à continuer un plan initial malgré des indices croissants indiquant qu’il devrait être modifié ou abandonné.

## Definition — English

The tendency to continue an initial plan despite mounting cues that it should be changed or abandoned.

## Exemple

Un équipage poursuit l’atterrissage alors que les critères d’approche stabilisée ne sont plus respectés.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Engagement, charge de travail, rétrécissement attentionnel et coûts perçus du changement tardif.

## Mécanisme probable

Engagement, charge de travail, rétrécissement attentionnel et coûts perçus du changement tardif.

## Analyse critique

Une poursuite peut être justifiée lorsque les alternatives sont plus risquées. Le concept ne doit pas remplacer l’analyse détaillée des contraintes, procédures et communications.

**Conclusion de l’audit :** bien documenté en sécurité aérienne et domaines analogues; définition et mesure contextuelles.

## Comment le limiter ?

Fixer des critères d’abandon explicites, annoncer les points de décision et autoriser tout membre à demander une réévaluation.

## Classement

- Nature scientifique : biais de décision opérationnelle sous pression
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Plan_continuation_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Dismukes, R. K., Berman, B. A., & Loukopoulos, L. D. (2007). *The Limits of Expertise: Rethinking Pilot Error and the Causes of Airline Accidents*. Ashgate.

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
