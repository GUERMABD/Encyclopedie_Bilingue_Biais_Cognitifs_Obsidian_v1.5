---
type: effet-decision
nom_fr: Effet de pseudo-certitude
nom_en: Pseudocertainty effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: effet de cadrage dans les choix risqués à étapes
robustesse: effet classique reproduit dans des paradigmes de cadrage, mais sensible à la représentation du problème
---
# Effet de pseudo-certitude

> **English:** Pseudocertainty effect

## Définition — français

Tendance à traiter comme certain un résultat qui n’est garanti qu’à l’intérieur d’une branche conditionnelle d’un choix.

## Definition — English

The tendency to treat an outcome as certain when it is guaranteed only within one conditional branch of a choice.

## Exemple

Une seconde étape est présentée comme un gain certain alors que l’accès à cette étape reste probabiliste.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Isolement des branches et cadrage local des probabilités.

## Mécanisme probable

Isolement des branches et cadrage local des probabilités.

## Analyse critique

L’effet dépend de la présentation séquentielle; il ne prouve pas une incapacité générale à comprendre les probabilités.

**Conclusion de l’audit :** effet classique reproduit dans des paradigmes de cadrage, mais sensible à la représentation du problème.

## Comment le limiter ?

Reconstituer l’arbre complet et calculer les probabilités finales non conditionnelles.

## Classement

- Nature scientifique : effet de cadrage dans les choix risqués à étapes
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Pseudocertainty_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tversky, A., & Kahneman, D. (1981). The framing of decisions and the psychology of choice. *Science*, 211(4481), 453–458. https://doi.org/10.1126/science.7455683

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
