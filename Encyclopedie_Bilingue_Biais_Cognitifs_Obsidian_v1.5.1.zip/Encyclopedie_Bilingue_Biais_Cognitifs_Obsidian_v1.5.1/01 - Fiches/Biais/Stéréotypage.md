---
type: processus-psychosocial
nom_fr: Stéréotypage
nom_en: Stereotyping
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
nature_scientifique: attribution de caractéristiques à une personne à partir de son appartenance catégorielle
robustesse: processus largement documenté, mais hétérogène, contextuel et distinct d’un biais unique
---
# Stéréotypage

> **English:** Stereotyping

## Définition — français

Utilisation de croyances généralisées sur un groupe pour percevoir ou juger l’un de ses membres.

## Definition — English

Using generalized beliefs about a group to perceive or judge one of its members.

## Exemple

Supposer les compétences d’une personne à partir de son genre plutôt que de son parcours.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Catégorisation, apprentissage culturel, attentes et économie cognitive.

## Mécanisme probable

Catégorisation, apprentissage culturel, attentes et économie cognitive.

## Analyse critique

Un stéréotype peut être descriptif, prescriptif, explicite ou implicite. Il se distingue du préjudice affectif et de la discrimination comportementale.

**Conclusion de l’audit :** processus largement documenté, mais hétérogène, contextuel et distinct d’un biais unique.

## Comment le limiter ?

Individualiser l’évaluation, standardiser les preuves et contrôler les écarts de décision entre groupes.

## Classement

- Nature scientifique : attribution de caractéristiques à une personne à partir de son appartenance catégorielle
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Stereotype
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Hilton, J. L., & von Hippel, W. (1996). Stereotypes. *Annual Review of Psychology*, 47, 237–271. https://doi.org/10.1146/annurev.psych.47.1.237

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
