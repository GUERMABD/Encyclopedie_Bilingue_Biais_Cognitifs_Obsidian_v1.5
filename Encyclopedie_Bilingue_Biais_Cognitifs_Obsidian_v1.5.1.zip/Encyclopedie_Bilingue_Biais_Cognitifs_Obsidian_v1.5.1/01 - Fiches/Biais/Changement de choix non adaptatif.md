---
type: biais-cognitif
nom_fr: Changement de choix non adaptatif
nom_en: Non-adaptive choice switching
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: effet de regret sur une décision séquentielle
robustesse: deux études initiales dans un paradigme précis; réplications indépendantes limitées
---
# Changement de choix non adaptatif

> **English:** Non-adaptive choice switching

## Définition — français

Abandon d’une option objectivement meilleure après qu’elle a produit par hasard un mauvais résultat et du regret.

## Definition — English

Switching away from an objectively better option after it happened to produce a bad outcome and regret.

## Exemple

Après une perte aléatoire avec la stratégie la plus avantageuse, une personne choisit ensuite une stratégie moins rentable.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Inhibition du choix associé au regret et apprentissage excessif à partir d’un résultat unique.

## Mécanisme probable

Inhibition du choix associé au regret et apprentissage excessif à partir d’un résultat unique.

## Analyse critique

Le phénomène a été étudié dans un protocole étroit. Changer après un mauvais résultat peut être adaptatif si ce résultat apporte réellement une information sur l’option.

**Conclusion de l’audit :** deux études initiales dans un paradigme précis; réplications indépendantes limitées.

## Comment le limiter ?

Distinguer qualité de la décision et résultat, puis mettre à jour à partir de la distribution plutôt que d’un seul essai.

## Classement

- Nature scientifique : effet de regret sur une décision séquentielle
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Non-adaptive_choice_switching
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Marcatto, F., Cosulich, A., & Ferrante, D. (2015). Once bitten, twice shy: Experienced regret and non-adaptive choice switching. *PeerJ*, 3, e1035. https://doi.org/10.7717/peerj.1035

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
