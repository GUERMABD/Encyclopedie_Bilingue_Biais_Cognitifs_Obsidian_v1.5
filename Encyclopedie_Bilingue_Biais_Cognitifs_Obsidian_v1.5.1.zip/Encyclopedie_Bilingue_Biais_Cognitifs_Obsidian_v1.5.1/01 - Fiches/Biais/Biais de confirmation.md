---
type: famille-de-biais
nom_fr: Biais de confirmation
nom_en: Confirmation bias
statut_fr: article français contrôlé le 2026-08-01
traduction: terme français attesté
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: famille de processus de recherche, d’interprétation et de mémorisation sélectives
robustesse: ensemble bien documenté, mais définition large et effets dépendants de la tâche
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex:
- Trop d'informations
aliases: []
url_fr_verifiee: https://fr.wikipedia.org/wiki/Biais_de_confirmation
---
# Biais de confirmation

> **English:** Confirmation bias

## Définition — français

Tendance à rechercher, interpréter et mémoriser préférentiellement les éléments qui confortent une croyance déjà présente.

## Definition — English

The tendency to search for, interpret, and remember information in ways that support an existing belief.

## Exemple

Une personne convaincue qu'un produit est dangereux remarque surtout les témoignages négatifs et néglige les données contradictoires.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Sélection de l'information, interprétation orientée, recherche asymétrique de preuves et mémorisation congruente.

## Mécanisme probable

Sélection de l'information, interprétation orientée, recherche asymétrique de preuves et mémorisation congruente.

## Analyse critique

Le terme regroupe plusieurs processus distincts : recherche d’informations favorables, interprétation orientée, test asymétrique d’hypothèses et mémorisation sélective. Leur ampleur dépend de la tâche, des connaissances, des motivations et des incitations.

**Conclusion de l’audit :** famille de biais établie, mais non mécanisme unique.

## Comment le limiter ?

Formuler à l'avance ce qui réfuterait l'hypothèse, rechercher une preuve contraire et faire relire la conclusion par une personne indépendante.

## Classement

- Nature scientifique : famille de processus de recherche, d’interprétation et de mémorisation sélectives
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Trop d'informations
- Statut français : article français contrôlé le 2026-08-01

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Confirmation_bias
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Biais_de_confirmation

## Références scientifiques contrôlées

- Nickerson, R. S. (1998). Confirmation bias: A ubiquitous phenomenon in many guises. *Review of General Psychology*, 2(2), 175–220. https://doi.org/10.1037/1089-2680.2.2.175

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
