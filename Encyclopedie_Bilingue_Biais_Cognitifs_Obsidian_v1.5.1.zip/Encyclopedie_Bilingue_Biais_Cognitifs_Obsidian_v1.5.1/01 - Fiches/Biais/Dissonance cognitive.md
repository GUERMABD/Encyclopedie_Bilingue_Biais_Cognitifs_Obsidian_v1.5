---
type: théorie-motivationnelle
nom_fr: Dissonance cognitive
nom_en: Cognitive dissonance
statut_fr: article français contrôlé le 2026-08-01
traduction: terme français attesté
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
url_fr_verifiee: https://fr.wikipedia.org/wiki/Dissonance_cognitive
nature_scientifique: théorie et état motivationnel
robustesse: cadre majeur, effets et mécanismes dépendants des conditions
---
# Dissonance cognitive

> **English:** Cognitive dissonance

## Définition — français

État d’inconfort ou de tension associé à une incompatibilité perçue entre cognitions, engagements ou comportements, susceptible de motiver une réduction de cette incompatibilité.

## Definition — English

A state of discomfort or tension associated with perceived inconsistency among cognitions, commitments, or behavior, which may motivate inconsistency reduction.

## Exemple

Après avoir défendu librement une position contraire à son opinion pour une faible récompense, une personne peut ajuster son attitude afin de rendre son comportement plus cohérent.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Réduction d’une incompatibilité jugée importante, notamment par changement d’attitude, justification ou minimisation.

## Mécanisme probable

Réduction d’une incompatibilité jugée importante, notamment par changement d’attitude, justification ou minimisation.

## Analyse critique

La dissonance cognitive est une théorie et une famille d’effets, pas un biais unique. L’incohérence seule ne suffit pas toujours : engagement, liberté perçue, responsabilité et importance personnelle modulent les résultats. Les formulations populaires qui assimilent toute gêne ou tout désaccord à une dissonance sont trop larges.

**Conclusion de l’audit :** théorie établie, à employer avec ses conditions.

## Comment le limiter ou l’étudier correctement ?

Identifier précisément les cognitions incompatibles, l’engagement et les moyens concurrents de réduire la tension avant d’attribuer un changement à la dissonance.

## Classement

- Nature scientifique : théorie et état motivationnel
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : absent
- Statut français : article français contrôlé le 2026-08-01

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Cognitive_dissonance
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Dissonance_cognitive

## Références scientifiques contrôlées

- Festinger, L. (1957). *A Theory of Cognitive Dissonance*. Stanford University Press.
- Festinger, L., & Carlsmith, J. M. (1959). Cognitive consequences of forced compliance. *Journal of Abnormal and Social Psychology*, 58(2), 203–210. https://doi.org/10.1037/h0041593

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
