---
type: biais-cognitif
nom_fr: Effet moins-c'est-mieux
nom_en: Less-is-better effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet d’évaluabilité en jugement séparé
robustesse: répliqué sous des conditions spécifiques de comparaison séparée; disparaît souvent en comparaison conjointe
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex:
- Nécessité d'agir rapidement
aliases:
- Less–is–better effect
---
# Effet moins-c'est-mieux

> **English:** Less-is-better effect

## Définition — français

En évaluation séparée, une option objectivement moindre peut être mieux jugée si son attribut le plus facile à évaluer paraît supérieur.

## Definition — English

In separate evaluation, an objectively smaller option can be valued more when its most evaluable attribute appears superior.

## Exemple

Un petit service de vaisselle intact est mieux évalué qu’un grand ensemble contenant davantage de pièces intactes mais aussi quelques pièces cassées.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Évaluabilité d’un attribut et difficulté à représenter la valeur totale sans comparaison directe.

## Mécanisme probable

Évaluabilité d’un attribut et difficulté à représenter la valeur totale sans comparaison directe.

## Analyse critique

Ce n’est pas une préférence générale pour « moins ». L’inversion dépend du mode d’évaluation et de la difficulté à comparer les quantités totales.

**Conclusion de l’audit :** répliqué sous des conditions spécifiques de comparaison séparée; disparaît souvent en comparaison conjointe.

## Comment le limiter ?

Présenter les options côte à côte et afficher les totaux pertinents plutôt que l’impression de qualité locale.

## Classement

- Nature scientifique : effet d’évaluabilité en jugement séparé
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Less-is-better_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Hsee, C. K. (1998). Less is better: When low-value options are valued more highly than high-value options. *Journal of Behavioral Decision Making*, 11(2), 107–121. DOI : `10.1002/(SICI)1099-0771(199806)11:2<107::AID-BDM292>3.0.CO;2-Y`

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
