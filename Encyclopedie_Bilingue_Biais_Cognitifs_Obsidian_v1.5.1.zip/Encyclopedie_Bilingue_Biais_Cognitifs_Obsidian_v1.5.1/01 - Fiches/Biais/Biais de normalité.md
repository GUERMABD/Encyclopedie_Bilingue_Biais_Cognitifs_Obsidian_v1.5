---
type: biais-cognitif
nom_fr: Biais de normalité
nom_en: Normalcy bias
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex:
- Manque de sens
aliases: []
nature_scientifique: notion de perception et d’action face aux catastrophes
robustesse: observations plausibles mais définition souvent rétrospective et mesure peu standardisée
---
# Biais de normalité

> **English:** Normalcy bias

## Définition — français

Tendance supposée à sous-estimer une menace grave et à continuer comme si la situation ordinaire allait se maintenir.

## Definition — English

A proposed tendency to underestimate a serious threat and behave as though normal conditions will continue.

## Exemple

Malgré plusieurs alertes d’évacuation, des habitants retardent leur départ parce que les précédentes alertes n’ont pas été suivies d’un désastre.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Inertie, ambiguïté des signaux, apprentissage par fausses alertes et attachement aux routines.

## Mécanisme probable

Inertie, ambiguïté des signaux, apprentissage par fausses alertes et attachement aux routines.

## Analyse critique

Le comportement qualifié de biais peut refléter des informations contradictoires, des contraintes matérielles ou une confiance raisonnable dans des expériences passées. Le diagnostic rétrospectif est risqué.

**Conclusion de l’audit :** observations plausibles mais définition souvent rétrospective et mesure peu standardisée.

## Comment le limiter ?

Définir des seuils d’action à l’avance, utiliser des messages concrets et prévoir des moyens réels d’évacuation.

## Classement

- Nature scientifique : notion de perception et d’action face aux catastrophes
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Manque de sens
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Normalcy_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Yamori, K. (2009). Revisiting the concept of normalcy bias. *Japanese Journal of Experimental Social Psychology*, 48(2), 137–149. https://doi.org/10.2130/jjesp.48.137

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
