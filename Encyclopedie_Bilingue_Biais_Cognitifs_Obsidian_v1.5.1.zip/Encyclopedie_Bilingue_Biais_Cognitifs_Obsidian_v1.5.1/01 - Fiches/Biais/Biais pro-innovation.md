---
type: biais-cognitif
nom_fr: Biais pro-innovation
nom_en: Pro-innovation bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases:
- Pro–innovation bias
nature_scientifique: biais de sélection et d’interprétation dans l’étude de la diffusion
robustesse: documenté comme problème de recherche et de politique; pas une préférence individuelle unique
---
# Biais pro-innovation

> **English:** Pro-innovation bias

## Définition — français

Tendance à présumer qu’une innovation est souhaitable, qu’elle doit se diffuser et que ses limites sont secondaires.

## Definition — English

The tendency to assume that an innovation is desirable, should diffuse, and has only secondary limitations.

## Exemple

Une politique étudie uniquement les facteurs qui accélèrent l’adoption d’un outil sans examiner ses abandons ni ses effets négatifs.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Sélection des cas réussis, récit de progrès et intérêts des promoteurs.

## Mécanisme probable

Sélection des cas réussis, récit de progrès et intérêts des promoteurs.

## Analyse critique

Le concept vient surtout des études de diffusion. Une évaluation favorable n’est pas biaisée si elle repose sur des résultats comparatifs complets.

**Conclusion de l’audit :** documenté comme problème de recherche et de politique; pas une préférence individuelle unique.

## Comment le limiter ?

Étudier non-adoption, échecs, effets distributifs et options de retrait avec les mêmes critères que les bénéfices.

## Classement

- Nature scientifique : biais de sélection et d’interprétation dans l’étude de la diffusion
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Pro-innovation_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Karch, A., Nicholson-Crotty, S. C., Woods, N. D., & Bowman, A. O’M. (2016). Policy diffusion and the pro-innovation bias. *Political Research Quarterly*, 69(1), 83–95. https://doi.org/10.1177/1065912915622289

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
