---
type: effet-fluidite
nom_fr: Effet « ça rime donc c’est bon »
nom_en: Rhyme as reason effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex:
- Nécessité d'agir rapidement
aliases:
- Rhyme–as–reason effect
nature_scientifique: effet de la rime et de la fluidité sur l’évaluation de véracité
robustesse: effet original documenté dans un paradigme étroit; généralisation et taille à traiter prudemment
---
# Effet « ça rime donc c’est bon »

> **English:** Rhyme as reason effect

## Définition — français

Tendance à juger un aphorisme plus exact ou persuasif lorsqu’il rime.

## Definition — English

The tendency to judge an aphorism as more accurate or persuasive when it rhymes.

## Exemple

Une maxime rimée paraît plus vraie que la même idée formulée sans rime.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Fluidité phonologique attribuée à tort au contenu.

## Mécanisme probable

Fluidité phonologique attribuée à tort au contenu.

## Analyse critique

L’effet ne signifie pas que toute rime convainc ni qu’une formulation fluide annule l’examen du fond.

**Conclusion de l’audit :** effet original documenté dans un paradigme étroit; généralisation et taille à traiter prudemment.

## Comment le limiter ?

Reformuler l’énoncé sans rime et vérifier si les preuves restent convaincantes.

## Classement

- Nature scientifique : effet de la rime et de la fluidité sur l’évaluation de véracité
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Rhyme-as-reason_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- McGlone, M. S., & Tofighbakhsh, J. (2000). Birds of a feather flock conjointly (?): Rhyme as reason in aphorisms. *Psychological Science*, 11(5), 424–428. https://doi.org/10.1111/1467-9280.00282

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
