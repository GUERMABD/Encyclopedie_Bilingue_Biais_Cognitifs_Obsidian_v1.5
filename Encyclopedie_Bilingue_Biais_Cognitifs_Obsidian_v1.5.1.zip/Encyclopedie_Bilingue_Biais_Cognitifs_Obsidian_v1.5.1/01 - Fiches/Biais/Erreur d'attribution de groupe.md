---
type: biais-cognitif
nom_fr: Erreur d'attribution de groupe
nom_en: Group attribution error
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: erreur d’inférence du groupe vers les membres ou inversement
robustesse: établie dans des paradigmes précis; portée plus étroite que le stéréotypage en général
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
---
# Erreur d'attribution de groupe

> **English:** Group attribution error

## Définition — français

Inférer les préférences de chaque membre à partir d’une décision de groupe, ou attribuer une décision collective à des préférences individuelles partagées.

## Definition — English

Inferring each member’s preference from a group decision, or treating a collective outcome as evidence of shared individual preferences.

## Exemple

Une décision adoptée par compromis est interprétée comme l’opinion personnelle de tous les membres.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Négligence des règles de décision, des contraintes et de la distribution interne des opinions.

## Mécanisme probable

Négligence des règles de décision, des contraintes et de la distribution interne des opinions.

## Analyse critique

Le concept ne couvre pas toutes les généralisations sur les groupes. Il concerne surtout l’erreur entre processus collectif et états individuels.

**Conclusion de l’audit :** établie dans des paradigmes précis; portée plus étroite que le stéréotypage en général.

## Comment le limiter ?

Documenter la règle de décision, les votes et la diversité des positions avant d’attribuer une intention au groupe.

## Classement

- Nature scientifique : erreur d’inférence du groupe vers les membres ou inversement
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Group_attribution_error
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Allison, S. T., & Messick, D. M. (1985). The group attribution error. *Journal of Experimental Social Psychology*, 21(6), 563–579. https://doi.org/10.1016/0022-1031(85)90025-3

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
