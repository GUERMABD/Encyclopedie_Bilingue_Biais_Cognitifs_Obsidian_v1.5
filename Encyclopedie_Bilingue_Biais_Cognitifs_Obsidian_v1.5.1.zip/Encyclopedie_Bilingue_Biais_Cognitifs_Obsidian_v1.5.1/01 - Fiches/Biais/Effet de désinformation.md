---
type: biais-cognitif
nom_fr: Effet de désinformation
nom_en: Misinformation effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: distorsion mnésique induite par une information post-événement
robustesse: robuste en laboratoire; taille et conséquences variables
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Effet de désinformation

> **English:** Misinformation effect

## Définition — français

Modification du souvenir d’un événement après exposition à des informations trompeuses.

## Definition — English

The alteration of memory for an event after exposure to misleading post-event information.

## Exemple

Un témoin rapporte un panneau stop après l’avoir vu mentionné dans une question, alors que la scène montrait un cédez-le-passage.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Intégration sémantique, compétition et erreur de source.

## Mécanisme probable

Intégration sémantique, compétition et erreur de source.

## Analyse critique

L’effet ne signifie pas que la mémoire initiale est toujours remplacée. Des traces concurrentes peuvent subsister, et la méthode d’interrogation influence le résultat.

**Conclusion de l’audit :** robuste en laboratoire; taille et conséquences variables.

## Comment le limiter ?

Séparer les témoins, limiter les informations postérieures et documenter la formulation exacte des questions.

## Classement

- Nature scientifique : distorsion mnésique induite par une information post-événement
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Misinformation_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Loftus, E. F., Miller, D. G., & Burns, H. J. (1978). Semantic integration of verbal information into a visual memory. *Journal of Experimental Psychology: Human Learning and Memory*, 4(1), 19–31. https://doi.org/10.1037/0278-7393.4.1.19

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
