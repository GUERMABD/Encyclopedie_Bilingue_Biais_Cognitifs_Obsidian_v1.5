---
type: biais-cognitif
nom_fr: Effet dire, c'est croire
nom_en: Saying is believing effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet d’ajustement du message et de mémoire lié à l’audience
robustesse: établi en laboratoire; dépendant de l’objectif de communication et du sentiment de réalité partagée
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Effet dire, c'est croire

> **English:** Saying is believing effect

## Définition — français

Adapter un message aux attitudes supposées d’un auditoire peut orienter ensuite le souvenir et l’évaluation du sujet dans le sens du message produit.

## Definition — English

Tailoring a message to an audience can later bias memory and evaluation toward the message that was produced.

## Exemple

Après avoir décrit une personne à un auditeur qui l’apprécie, le locuteur se souvient d’elle de manière plus positive.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Réencodage du contenu produit et recherche d’une réalité partagée avec l’auditoire.

## Mécanisme probable

Réencodage du contenu produit et recherche d’une réalité partagée avec l’auditoire.

## Analyse critique

Il ne suffit pas de prononcer n’importe quelle affirmation pour y croire. L’effet étudié suppose généralement un ajustement du message à un destinataire précis.

**Conclusion de l’audit :** établi en laboratoire; dépendant de l’objectif de communication et du sentiment de réalité partagée.

## Comment le limiter ?

Distinguer les faits initiaux de la formulation adaptée au public et conserver les données sources.

## Classement

- Nature scientifique : effet d’ajustement du message et de mémoire lié à l’audience
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Saying_is_believing_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Higgins, E. T., & Rholes, W. S. (1978). “Saying is believing”: Effects of message modification on memory and liking for the person described. *Journal of Experimental Social Psychology*, 14(4), 363–378. https://doi.org/10.1016/0022-1031(78)90032-X

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
