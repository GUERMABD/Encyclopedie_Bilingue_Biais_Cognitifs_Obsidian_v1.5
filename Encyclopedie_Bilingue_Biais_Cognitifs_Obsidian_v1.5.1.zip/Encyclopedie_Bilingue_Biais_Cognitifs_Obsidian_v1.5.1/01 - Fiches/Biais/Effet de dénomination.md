---
type: biais-cognitif
nom_fr: Effet de dénomination
nom_en: Denomination effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet de représentation monétaire sur la dépense
robustesse: documenté dans plusieurs expériences initiales; contexte et moyens de paiement importants
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex:
- Manque de sens
aliases: []
---
# Effet de dénomination

> **English:** Denomination effect

## Définition — français

Variation de la propension à dépenser selon que la même somme est présentée en grandes ou petites coupures.

## Definition — English

Variation in spending propensity depending on whether the same amount is represented in large or small denominations.

## Exemple

Une personne hésite davantage à casser un gros billet qu’à dépenser plusieurs petites coupures de valeur totale identique.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Fongibilité psychologique imparfaite et douleur de payer.

## Mécanisme probable

Fongibilité psychologique imparfaite et douleur de payer.

## Analyse critique

L’effet concerne une représentation physique ou mentale de la somme et peut changer avec les paiements électroniques, les habitudes et le contexte.

**Conclusion de l’audit :** documenté dans plusieurs expériences initiales; contexte et moyens de paiement importants.

## Comment le limiter ?

Raisonner sur le montant total et non sur le nombre ou la taille des unités monétaires.

## Classement

- Nature scientifique : effet de représentation monétaire sur la dépense
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Denomination_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Raghubir, P., & Srivastava, J. (2009). The denomination effect. *Journal of Consumer Research*, 36(4), 701–713. https://doi.org/10.1086/599222

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
