---
type: biais-cognitif
nom_fr: Effet d'indiçage partiel
nom_en: Part-list cueing effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: 2026-08-01
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases:
- Part-set cueing effect
- Part–set cueing effect
- Indiçage partiel
nature_scientifique: effet expérimental de récupération en mémoire
robustesse: établie avec conditions limites
---

# Effet d'indiçage partiel

> **English:** Part-list cueing effect / part-set cueing effect

## Définition — français

La présentation d’une partie des éléments appris comme indices peut réduire le rappel des autres éléments, au lieu de le faciliter.

## Definition — English

Presenting part of a studied set as retrieval cues can impair recall of the remaining items rather than facilitate it.

## Exemple

Une étudiante apprend une liste de vingt noms d’animaux. Au moment du rappel, on lui redonne huit de ces noms comme indices. Ces indices peuvent perturber sa stratégie de recherche en mémoire : elle retrouve alors moins bien les douze noms restants que lorsqu’elle devait rappeler librement toute la liste.

**Ce que cela illustre :** les indices fournis réorganisent la recherche en mémoire et peuvent bloquer l’accès aux éléments non présentés ; davantage d’indices ne produit donc pas nécessairement un meilleur rappel.

## Analyse critique

L’effet est bien documenté, mais il dépend du matériel, des relations entre les éléments et de la tâche. Des conditions de facilitation existent également ; il ne faut donc pas présenter tout indiçage partiel comme nuisible.

**Conclusion de l’audit :** phénomène mnésique établi, avec conditions limites.

## Classement

- Nature scientifique : effet expérimental de récupération en mémoire
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Part-list_cueing_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Slamecka, N. J. (1968). An examination of trace storage in free recall. *Journal of Experimental Psychology*, 76(4, Pt. 1), 504–513. https://doi.org/10.1037/h0025695
- Lehmer, E.-M., & Bäuml, K.-H. T. (2018). The Many Faces of Part-List Cuing—Evidence for the Interplay Between Detrimental and Beneficial Mechanisms. *Frontiers in Psychology*, 9, 701. https://doi.org/10.3389/fpsyg.2018.00701

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les appellations *part-list cuing* et *part-set cuing* sont utilisées dans la littérature pour le même ensemble de paradigmes ; elles ne justifient pas deux fiches séparées.
- L’appartenance à Wikipédia ou au Codex ne constitue pas, à elle seule, une validation scientifique.
