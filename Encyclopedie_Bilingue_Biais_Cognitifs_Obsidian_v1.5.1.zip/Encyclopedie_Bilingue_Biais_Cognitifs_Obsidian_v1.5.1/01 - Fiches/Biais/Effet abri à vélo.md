---
type: biais-cognitif
nom_fr: Effet abri à vélo
nom_en: Law of Triviality
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Nécessité d'agir rapidement
aliases:
- Bike–shedding effect
nature_scientifique: aphorisme organisationnel, loi de trivialité de Parkinson
robustesse: observation plausible et populaire; validation expérimentale directe limitée
---
# Effet abri à vélo

> **English:** Law of Triviality

## Définition — français

Tendance supposée des groupes à consacrer un temps disproportionné aux questions simples et familières plutôt qu’aux enjeux complexes et importants.

## Definition — English

The proposed tendency for groups to spend disproportionate time on simple, familiar issues rather than complex and important ones.

## Exemple

Un comité approuve rapidement un investissement technique majeur puis débat longuement de la couleur d’un abri à vélos.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Facilité de participation, faible coût d’une opinion et évitement de la complexité.

## Mécanisme probable

Facilité de participation, faible coût d’une opinion et évitement de la complexité.

## Analyse critique

La loi de trivialité vient d’une satire de gestion, non d’un programme expérimental établissant un effet stable. Elle peut néanmoins décrire certains ordres du jour.

**Conclusion de l’audit :** observation plausible et populaire; validation expérimentale directe limitée.

## Comment le limiter ?

Allouer le temps selon l’importance, préparer l’expertise avant la réunion et définir le niveau de décision attendu pour chaque point.

## Classement

- Nature scientifique : aphorisme organisationnel, loi de trivialité de Parkinson
- Tâche(s) du classement Wikipédia : aucune
- Sous-catégorie(s) (« flavors ») : aucune
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Law_of_triviality
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Parkinson, C. N. (1958). *Parkinson’s Law, or The Pursuit of Progress*. John Murray.

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
