---
type: biais-cognitif
nom_fr: Cynisme naïf
nom_en: Naïve cynicism
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais d’attribution des motivations d’autrui
robustesse: programme de recherche limité; résultats suggestifs mais généralisation incertaine
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Trop d'informations
aliases: []
---
# Cynisme naïf

> **English:** Naïve cynicism

## Définition — français

Tendance à supposer que les jugements d’autrui sont plus fortement motivés par l’intérêt personnel ou les biais qu’ils ne le sont réellement.

## Definition — English

The tendency to assume that other people’s judgments are more self-interested or biased than they actually are.

## Exemple

On attribue le désaccord d’un collègue à son intérêt personnel tout en décrivant sa propre position comme fondée sur les faits.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Asymétrie soi-autrui et accès privilégié à ses propres justifications.

## Mécanisme probable

Asymétrie soi-autrui et accès privilégié à ses propres justifications.

## Analyse critique

Le concept est proche du biais de l’angle mort et de l’illusion d’objectivité. Sa base empirique est plus étroite que son usage populaire.

**Conclusion de l’audit :** programme de recherche limité; résultats suggestifs mais généralisation incertaine.

## Comment le limiter ?

Demander quelles preuves changeraient l’avis de chaque partie et envisager des motivations mixtes plutôt qu’une seule cause cachée.

## Classement

- Nature scientifique : biais d’attribution des motivations d’autrui
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Naïve_cynicism
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kruger, J., & Gilovich, T. (1999). “Naive cynicism” in everyday theories of responsibility assessment: On biased assumptions of bias. *Journal of Personality and Social Psychology*, 76(5), 743–753. https://doi.org/10.1037/0022-3514.76.5.743

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
