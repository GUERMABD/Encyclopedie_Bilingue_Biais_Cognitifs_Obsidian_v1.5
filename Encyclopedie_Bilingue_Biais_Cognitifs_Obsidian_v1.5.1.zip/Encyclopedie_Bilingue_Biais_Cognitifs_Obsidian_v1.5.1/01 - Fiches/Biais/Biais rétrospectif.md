---
type: biais-de-memoire-et-jugement
nom_fr: Biais rétrospectif
nom_en: Hindsight bias
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: reconstruction a posteriori de la prévisibilité ou de l’inévitabilité d’un résultat
robustesse: effet robuste, d’ampleur variable selon la connaissance du résultat et la tâche
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
---
# Biais rétrospectif

> **English:** Hindsight bias

## Définition — français

Tendance, après un événement, à le juger plus prévisible qu'il ne l'était avant qu'il survienne.

## Definition — English

The tendency to see an event as more predictable after it has occurred than it was beforehand.

## Exemple

Après une panne, affirmer que les signes annonciateurs étaient évidents alors qu'ils ne l'étaient pas dans les décisions prises à l'époque.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Reconstruction du souvenir et intégration du résultat connu dans l'évaluation passée.

## Mécanisme probable

Reconstruction du souvenir et intégration du résultat connu dans l'évaluation passée.

## Analyse critique

Le phénomène est robuste : connaître le résultat modifie souvent le souvenir des prévisions initiales et l’impression que l’événement était prévisible. Une analyse rétrospective n’est cependant pas biaisée lorsqu’elle reconstruit explicitement les informations disponibles au moment de la décision.

**Conclusion de l’audit :** effet établi de mémoire et de jugement.

## Comment le limiter ?

Conserver les prévisions et hypothèses datées, puis comparer après coup sans réécrire le contexte initial.

## Classement

- Nature scientifique : reconstruction a posteriori de la prévisibilité ou de l’inévitabilité d’un résultat
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Hindsight_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Roese, N. J., & Vohs, K. D. (2012). Hindsight bias. *Perspectives on Psychological Science*, 7(5), 411–426. https://doi.org/10.1177/1745691612454303

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
