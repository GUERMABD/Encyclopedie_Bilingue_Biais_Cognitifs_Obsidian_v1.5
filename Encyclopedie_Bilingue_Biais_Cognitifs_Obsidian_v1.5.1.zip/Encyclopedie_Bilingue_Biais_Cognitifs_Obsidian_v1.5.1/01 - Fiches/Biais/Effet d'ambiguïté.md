---
type: biais-cognitif
nom_fr: Effet d'ambiguïté
nom_en: Ambiguity effect
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex:
- Nécessité d'agir rapidement
aliases:
- Ambiguity bias
nature_scientifique: préférence face à l’incertitude
robustesse: établie comme phénomène de choix, pas nécessairement irrationnelle
---
# Effet d'ambiguïté

> **English:** Ambiguity effect

## Définition — français

Tendance à préférer une option dont les probabilités sont connues à une option dont les probabilités sont mal connues ou ambiguës.

## Definition — English

The tendency to prefer an option with known probabilities over one with poorly known or ambiguous probabilities.

## Exemple

Préférer une urne dont la proportion de couleurs est connue à une urne dont la composition est inconnue, même lorsque les gains possibles sont identiques.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Inconfort face à l’information manquante, prudence et crainte d’un modèle de probabilité défavorable.

## Mécanisme probable

Inconfort face à l’information manquante, prudence et crainte d’un modèle de probabilité défavorable.

## Analyse critique

Les paradoxes d’Ellsberg montrent une violation de certains modèles d’utilité subjective, mais l’aversion à l’ambiguïté n’est pas automatiquement irrationnelle : l’incertitude sur le modèle peut être pertinente.

**Conclusion de l’audit :** établie comme phénomène de choix, pas nécessairement irrationnelle.

## Comment le limiter ?

Distinguer risque mesurable et incertitude sur le modèle, rechercher l’information manquante et tester la sensibilité du choix à plusieurs probabilités plausibles.

## Classement

- Nature scientifique : préférence face à l’incertitude
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Nécessité d'agir rapidement
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Ambiguity_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Ellsberg, D. (1961). Risk, Ambiguity, and the Savage Axioms. *The Quarterly Journal of Economics*, 75(4), 643–669. https://doi.org/10.2307/1884324

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
