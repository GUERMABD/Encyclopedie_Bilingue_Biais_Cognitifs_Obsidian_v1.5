---
type: mecanisme-theorique
nom_fr: Substitution d'attribut
nom_en: Attribute substitution
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: mécanisme par lequel une question difficile est remplacée par une question plus accessible
robustesse: cadre théorique influent soutenu par de nombreux paradigmes, mais non processus directement observable unique
---
# Substitution d'attribut

> **English:** Attribute substitution

## Définition — français

Réponse à une question complexe au moyen d’un attribut plus facile à évaluer, souvent sans remarquer la substitution.

## Definition — English

Answering a difficult question by evaluating an easier attribute, often without noticing the substitution.

## Exemple

Évaluer la probabilité d’un événement à partir de la facilité avec laquelle un exemple vient à l’esprit.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Accessibilité différentielle et validation insuffisante de la réponse intuitive.

## Mécanisme probable

Accessibilité différentielle et validation insuffisante de la réponse intuitive.

## Analyse critique

Le concept sert à expliquer plusieurs heuristiques; il ne doit pas être utilisé comme explication circulaire sans identifier l’attribut remplacé et l’attribut substitut.

**Conclusion de l’audit :** cadre théorique influent soutenu par de nombreux paradigmes, mais non processus directement observable unique.

## Comment le limiter ?

Écrire la variable cible, puis vérifier que les données utilisées la mesurent réellement.

## Classement

- Nature scientifique : mécanisme par lequel une question difficile est remplacée par une question plus accessible
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Association
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Attribute_substitution
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kahneman, D., & Frederick, S. (2002). Representativeness revisited: Attribute substitution in intuitive judgment. In *Heuristics and Biases* (pp. 49–81). Cambridge University Press. https://doi.org/10.1017/CBO9780511808098.004

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
