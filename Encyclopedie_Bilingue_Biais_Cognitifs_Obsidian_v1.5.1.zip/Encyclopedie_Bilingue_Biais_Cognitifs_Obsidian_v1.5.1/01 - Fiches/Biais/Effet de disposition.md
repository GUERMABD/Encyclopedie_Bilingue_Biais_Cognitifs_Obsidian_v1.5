---
type: biais-cognitif
nom_fr: Effet de disposition
nom_en: Disposition effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: comportement d’investissement asymétrique envers gains et pertes
robustesse: largement documenté sur plusieurs marchés; mécanismes multiples
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Effet de disposition

> **English:** Disposition effect

## Définition — français

Tendance des investisseurs à vendre trop rapidement les actifs gagnants et à conserver trop longtemps les actifs perdants.

## Definition — English

The tendency for investors to sell winning assets too early and hold losing assets too long.

## Exemple

Un investisseur réalise un petit gain mais refuse de vendre une position déficitaire sans nouvelle information favorable.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Aversion à réaliser une perte, comptabilité mentale, regret et croyances sur le retour à la moyenne.

## Mécanisme probable

Aversion à réaliser une perte, comptabilité mentale, regret et croyances sur le retour à la moyenne.

## Analyse critique

Les impôts, frais, besoins de liquidité et informations privées peuvent rendre certains comportements rationnels. Le diagnostic exige un point de comparaison approprié.

**Conclusion de l’audit :** largement documenté sur plusieurs marchés; mécanismes multiples.

## Comment le limiter ?

Définir à l’avance les règles de sortie et réévaluer chaque position selon ses perspectives futures.

## Classement

- Nature scientifique : comportement d’investissement asymétrique envers gains et pertes
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Disposition_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Shefrin, H., & Statman, M. (1985). The disposition to sell winners too early and ride losers too long. *Journal of Finance*, 40(3), 777–790. https://doi.org/10.1111/j.1540-6261.1985.tb05002.x

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
