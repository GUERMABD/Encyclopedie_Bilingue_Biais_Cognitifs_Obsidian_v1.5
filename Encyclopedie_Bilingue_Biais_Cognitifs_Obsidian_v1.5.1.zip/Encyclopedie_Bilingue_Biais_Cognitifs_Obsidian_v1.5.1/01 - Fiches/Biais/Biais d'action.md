---
type: biais-cognitif
nom_fr: Biais d'action
nom_en: Action bias
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex: []
aliases: []
nature_scientifique: préférence décisionnelle pour l’intervention
robustesse: preuve contextuelle, pas de loi générale
---
# Biais d'action

> **English:** Action bias

## Définition — français

Préférence pour entreprendre une action plutôt que ne rien faire, même lorsque l’action n’améliore pas la décision ou augmente le coût attendu.

## Definition — English

A preference for taking action rather than doing nothing, even when action does not improve the decision or increases expected cost.

## Exemple

Modifier une stratégie uniquement pour montrer que l’on agit, alors que les données disponibles ne justifient aucun changement.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Valeur sociale de l’activité, désir d’influencer le résultat, responsabilité visible et difficulté à justifier l’inaction.

## Mécanisme probable

Valeur sociale de l’activité, désir d’influencer le résultat, responsabilité visible et difficulté à justifier l’inaction.

## Analyse critique

Les travaux soutiennent l’existence de préférences d’action dans certains domaines, mais le terme est large et ne décrit pas une tendance universelle. L’action peut aussi être rationnelle lorsqu’elle produit de l’information ou évite un coût d’attente.

**Conclusion de l’audit :** preuve contextuelle, pas de loi générale.

## Comment le limiter ?

Définir l’option “ne rien changer” comme une décision à part entière, comparer ses conséquences et exiger un bénéfice attendu avant toute intervention.

## Classement

- Nature scientifique : préférence décisionnelle pour l’intervention
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : absent du Codex historique
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Action_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Patt, A., & Zeckhauser, R. (2000). Action Bias and Environmental Decisions. *Journal of Risk and Uncertainty*, 21(1), 45–72. https://doi.org/10.1023/A:1026517309871

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
