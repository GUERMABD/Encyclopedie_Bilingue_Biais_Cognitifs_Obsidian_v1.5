---
type: biais-cognitif
nom_fr: Amnésie infantile
nom_en: Childhood amnesia
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: phénomène développemental de mémoire autobiographique
robustesse: bien documenté; âge limite variable selon les personnes et les méthodes
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Amnésie infantile

> **English:** Childhood amnesia

## Définition — français

Rareté des souvenirs autobiographiques fiables datant des premières années de la vie.

## Definition — English

The scarcity of reliable autobiographical memories from the earliest years of life.

## Exemple

Un adulte ne parvient généralement pas à restituer un souvenir épisodique vérifiable de sa première année.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Développement progressif du langage, du soi autobiographique et des systèmes de mémoire.

## Mécanisme probable

Développement progressif du langage, du soi autobiographique et des systèmes de mémoire.

## Analyse critique

Ce n’est pas l’effacement brutal de tous les événements précoces. Des apprentissages et traces non autobiographiques peuvent persister, tandis que la datation et la vérification des très anciens souvenirs restent difficiles.

**Conclusion de l’audit :** bien documenté; âge limite variable selon les personnes et les méthodes.

## Comment le limiter ?

Distinguer souvenir personnel, récit familial, photographie et reconstruction ultérieure.

## Classement

- Nature scientifique : phénomène développemental de mémoire autobiographique
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Childhood_amnesia
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Hayne, H., & Jack, F. (2011). Childhood amnesia. *Wiley Interdisciplinary Reviews: Cognitive Science*, 2(2), 136–145. https://doi.org/10.1002/wcs.107

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
