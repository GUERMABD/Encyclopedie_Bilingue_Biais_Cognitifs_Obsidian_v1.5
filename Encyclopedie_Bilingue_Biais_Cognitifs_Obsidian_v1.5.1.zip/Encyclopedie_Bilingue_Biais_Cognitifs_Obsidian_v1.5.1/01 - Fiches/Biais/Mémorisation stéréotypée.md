---
type: biais-mnesique
nom_fr: Mémorisation stéréotypée
nom_en: Stereotypical bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Limites de la mémoire
aliases: []
nature_scientifique: reconstruction ou sélection de souvenirs conformément à un stéréotype activé
robustesse: effets documentés mais variables; les informations incongruentes peuvent aussi bénéficier d’un avantage de distinctivité
---
# Mémorisation stéréotypée

> **English:** Stereotypical bias

## Définition — français

Déformation de l’encodage ou du rappel d’informations sur une personne dans le sens d’un stéréotype social.

## Definition — English

Distortion of encoding or recall about a person in a direction consistent with an activated social stereotype.

## Exemple

Un comportement ambigu est rappelé comme plus agressif lorsqu’il est associé à un groupe stéréotypé ainsi.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Schémas, associations automatiques et contrôle imparfait de la source.

## Mécanisme probable

Schémas, associations automatiques et contrôle imparfait de la source.

## Analyse critique

Cette fiche vise spécifiquement la mémoire. Elle se distingue du stéréotypage général et du biais stéréotypique plus large de jugement.

**Conclusion de l’audit :** effets documentés mais variables; les informations incongruentes peuvent aussi bénéficier d’un avantage de distinctivité.

## Comment le limiter ?

Noter les comportements précis, préserver la source et rechercher les éléments congruents comme incongruents.

## Classement

- Nature scientifique : reconstruction ou sélection de souvenirs conformément à un stéréotype activé
- Tâche(s) du classement Wikipédia : non repris dans la liste anglaise contrôlée
- Sous-catégorie(s) (« flavors ») : non applicable
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Implicit_stereotype
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Payne, B. K., Jacoby, L. L., & Lambert, A. J. (2004). Memory monitoring and the control of stereotype distortion. *Journal of Experimental Social Psychology*, 40(1), 52–64. https://doi.org/10.1016/S0022-1031(03)00069-6

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
