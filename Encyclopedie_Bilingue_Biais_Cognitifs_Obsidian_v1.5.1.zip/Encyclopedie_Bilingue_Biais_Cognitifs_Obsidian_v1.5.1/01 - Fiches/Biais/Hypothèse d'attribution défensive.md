---
type: biais-cognitif
nom_fr: Hypothèse d'attribution défensive
nom_en: Defensive attribution hypothesis
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: hypothèse motivationnelle sur l’attribution de responsabilité
robustesse: effets classiques mais résultats variables selon similarité, gravité et paradigme
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Hypothèse d'attribution défensive

> **English:** Defensive attribution hypothesis

## Définition — français

Proposition selon laquelle l’attribution de responsabilité à une victime ou à un acteur peut protéger l’observateur contre l’idée qu’un accident similaire pourrait lui arriver.

## Definition — English

The proposal that assigning responsibility to a victim or actor can protect observers from imagining that a similar accident could happen to them.

## Exemple

Un observateur blâme davantage une victime afin de croire qu’en agissant autrement il éviterait le même sort.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Réduction de menace, contrôle perçu et comparaison avec la victime.

## Mécanisme probable

Réduction de menace, contrôle perçu et comparaison avec la victime.

## Analyse critique

Les prédictions ne sont pas uniformes : la similarité peut accroître l’empathie ou le blâme selon les circonstances. La théorie ne doit pas être utilisée pour deviner les motivations individuelles.

**Conclusion de l’audit :** effets classiques mais résultats variables selon similarité, gravité et paradigme.

## Comment le limiter ?

Séparer les causes factuelles, la prévisibilité et les réactions émotionnelles de l’observateur.

## Classement

- Nature scientifique : hypothèse motivationnelle sur l’attribution de responsabilité
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Defensive_attribution_hypothesis
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Shaver, K. G. (1970). Defensive attribution: Effects of severity and relevance on responsibility assigned for an accident. *Journal of Personality and Social Psychology*, 14(2), 101–113. https://doi.org/10.1037/h0028777

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
