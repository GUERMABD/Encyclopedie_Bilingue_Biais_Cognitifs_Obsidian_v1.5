---
type: concept-metrologique-statistique
nom_fr: Biais systématique
nom_en: Systematic error
statut_fr: concept traité dans l’article français sur le biais statistique; correspondance non individuelle
traduction: terminologie technique harmonisée
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Baseline
codex: []
aliases:
- Systematic bias
- Erreur systématique
nature_scientifique: erreur systématique de mesure ou d’estimation
robustesse: concept normatif établi, mais expression trop générale
url_fr_verifiee: https://fr.wikipedia.org/wiki/Biais_%28statistique%29
---
# Biais systématique

> **English:** Systematic error

## Définition — français

Composante d’erreur qui, lors de mesures répétées, demeure constante ou varie de manière prévisible et décale les résultats par rapport à une valeur de référence.

## Definition — English

An error component that remains constant or varies predictably across repeated measurements, shifting results relative to a reference value.

## Exemple

Un capteur mal étalonné surestime toutes les températures d’environ 0,5 °C.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Étalonnage, procédure, modèle ou instrument peuvent produire un décalage orienté et reproductible.

## Mécanisme probable

Étalonnage, procédure, modèle ou instrument peuvent produire un décalage orienté et reproductible.

## Analyse critique

Cette entrée désigne une catégorie générique de métrologie et de statistique, pas un phénomène psychologique singulier. « Biais » et « erreur systématique » ont des usages techniques qui varient selon les domaines ; la fiche ne doit pas être confondue avec un biais cognitif.

**Conclusion de l’audit :** concept méthodologique valide, mais non spécifique aux sciences cognitives.

## Comment le limiter ou l’étudier correctement ?

Identifier une valeur de référence, estimer le décalage, corriger sa cause lorsqu’elle est connue et documenter l’incertitude résiduelle.

## Classement

- Nature scientifique : erreur systématique de mesure ou d’estimation
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : absent
- Statut français : concept traité dans l’article français sur le biais statistique; correspondance non individuelle

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Systematic_error
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Biais_%28statistique%29

## Références scientifiques contrôlées

- Joint Committee for Guides in Metrology. (2008, corrigé 2012). *International Vocabulary of Metrology — Basic and General Concepts and Associated Terms (VIM), 3rd edition*, entrée 2.17.
- National Institute of Standards and Technology. Analysis of bias. https://www.itl.nist.gov/div898/handbook/mpc/section4/mpc45.htm

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
