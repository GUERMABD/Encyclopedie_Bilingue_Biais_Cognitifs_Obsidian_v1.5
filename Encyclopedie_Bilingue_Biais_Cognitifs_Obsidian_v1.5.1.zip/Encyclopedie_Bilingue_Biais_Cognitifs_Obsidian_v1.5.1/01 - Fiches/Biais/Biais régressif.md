---
type: biais-cognitif
nom_fr: Biais régressif
nom_en: Regressive bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Baseline
codex: []
aliases: []
nature_scientifique: biais de rappel vers des valeurs moins extrêmes
robustesse: phénomène de régression mnésique documenté dans certaines estimations; terme peu utilisé comme biais autonome
---
# Biais régressif

> **English:** Regressive bias

## Définition — français

Tendance à se souvenir de valeurs élevées comme plus basses et de valeurs faibles comme plus hautes qu’elles ne l’étaient.

## Definition — English

The tendency to remember high values as lower and low values as higher than they actually were.

## Exemple

Des risques très rares sont rappelés comme plus fréquents, tandis que des risques fréquents sont rappelés comme moins fréquents.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Bruit mnésique, compression de l’échelle et régression vers la moyenne.

## Mécanisme probable

Bruit mnésique, compression de l’échelle et régression vers la moyenne.

## Analyse critique

Le terme peut être confondu avec la régression statistique ou le conservatisme. La direction dépend de l’échelle, des connaissances et des valeurs présentées.

**Conclusion de l’audit :** phénomène de régression mnésique documenté dans certaines estimations; terme peu utilisé comme biais autonome.

## Comment le limiter ?

Conserver les mesures originales, utiliser des échelles explicites et comparer le rappel aux valeurs réellement observées.

## Classement

- Nature scientifique : biais de rappel vers des valeurs moins extrêmes
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Regressive_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Lichtenstein, S., Slovic, P., Fischhoff, B., Layman, M., & Combs, B. (1978). Judged frequency of lethal events. *Journal of Experimental Psychology: Human Learning and Memory*, 4(6), 551–578. https://doi.org/10.1037/0278-7393.4.6.551

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
