---
type: effet-metacognitif
nom_fr: Effet difficile-facile
nom_en: Hard–easy effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Baseline
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: variation de la calibration de confiance selon la difficulté des questions
robustesse: profil fréquent mais partiellement produit par sélection des items, bruit de mesure et régression vers la moyenne
---
# Effet difficile-facile

> **English:** Hard–easy effect

## Définition — français

Tendance à être trop confiant sur les questions difficiles et parfois insuffisamment confiant sur les questions faciles.

## Definition — English

The tendency to be overconfident on difficult questions and sometimes underconfident on easy questions.

## Exemple

Une personne se dit sûre à 60 % sur des questions où elle ne réussit que 40 %, mais se sous-estime sur les plus simples.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Bruit dans les jugements, sélection de difficulté et utilisation imparfaite des indices métacognitifs.

## Mécanisme probable

Bruit dans les jugements, sélection de difficulté et utilisation imparfaite des indices métacognitifs.

## Analyse critique

Une partie du profil peut apparaître statistiquement même sans biais psychologique stable. Il faut analyser calibration, discrimination et construction du test.

**Conclusion de l’audit :** profil fréquent mais partiellement produit par sélection des items, bruit de mesure et régression vers la moyenne.

## Comment le limiter ?

Mesurer la calibration sur de nombreux items de difficulté variée et fournir un retour chiffré.

## Classement

- Nature scientifique : variation de la calibration de confiance selon la difficulté des questions
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Hard–easy_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Lichtenstein, S., & Fischhoff, B. (1977). Do those who know more also know more about how much they know? *Organizational Behavior and Human Performance*, 20(2), 159–183. https://doi.org/10.1016/0030-5073(77)90001-0

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
