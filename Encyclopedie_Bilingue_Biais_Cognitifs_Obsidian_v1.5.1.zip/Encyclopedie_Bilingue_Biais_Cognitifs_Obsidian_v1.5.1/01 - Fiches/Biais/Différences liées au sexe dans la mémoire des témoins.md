---
type: theme-de-recherche
nom_fr: Différences liées au sexe dans la mémoire des témoins
nom_en: Sex differences in eyewitness memory
statut_fr: traduction descriptive; aucune page française individuelle validée dans cette édition
traduction: terminologie corrigée selon la portée de la revue; ancien titre conservé comme alias
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Self-perspective
codex: []
aliases:
- Différences de genre dans la mémoire des témoins
- Gender differences in eyewitness memory
nature_scientifique: question comparative en psychologie du témoignage
robustesse: résultats mixtes et dépendants du type d’information
---
# Différences liées au sexe dans la mémoire des témoins

> **English:** Sex differences in eyewitness memory

## Définition — français

Domaine de recherche examinant si certaines performances de rappel, de reconnaissance ou d’identification de témoins diffèrent selon le sexe des participants et des personnes observées.

## Definition — English

A research topic examining whether eyewitness recall, recognition, or identification performance differs by the sex of participants and observed persons.

## Exemple

Des études comparent la précision du souvenir des détails personnels et environnementaux chez des témoins masculins et féminins.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attention sélective, familiarité et biais envers son propre sexe sont proposés, mais les explications causales restent insuffisamment testées.

## Mécanisme probable

Attention sélective, familiarité et biais envers son propre sexe sont proposés, mais les explications causales restent insuffisamment testées.

## Analyse critique

Cette entrée est un thème de recherche, pas un biais cognitif. La revue disponible ne montre pas de supériorité générale d’un sexe pour la quantité totale d’informations exactes ; les différences observées portent plutôt sur certains types de détails, avec des méthodes et résultats hétérogènes. Les travaux historiques confondent souvent sexe et genre.

**Conclusion de l’audit :** résultats spécifiques aux tâches, sans différence générale établie.

## Comment le limiter ou l’étudier correctement ?

Distinguer sexe et genre, préenregistrer les comparaisons, mesurer le type de détail et éviter toute généralisation à partir de moyennes faibles ou contextuelles.

## Classement

- Nature scientifique : question comparative en psychologie du témoignage
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : absent
- Statut français : traduction descriptive; aucune page française individuelle validée dans cette édition

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Gender_differences_in_eyewitness_memory
- Français : aucune page individuelle équivalente validée dans cette édition ; résolution complémentaire prévue via Wikidata.

## Références scientifiques contrôlées

- Russell, E. M., Longstaff, M. G., & Winskel, H. (2024). Sex differences in eyewitness memory: A scoping review. *Psychonomic Bulletin & Review*, 31, 985–999. https://doi.org/10.3758/s13423-023-02407-x

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
