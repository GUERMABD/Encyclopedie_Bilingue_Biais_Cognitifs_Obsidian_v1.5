---
type: biais-methodologique
nom_fr: Biais de sélection
nom_en: Selection bias
statut_fr: article français contrôlé le 2026-08-01
traduction: terme français normalisé
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: biais d’échantillonnage et d’inférence causale
robustesse: concept méthodologique établi
url_fr_verifiee: https://fr.wikipedia.org/wiki/Biais_de_s%C3%A9lection
---
# Biais de sélection

> **English:** Selection bias

## Définition — français

Distorsion d’une estimation causée par les mécanismes qui déterminent quels individus ou observations entrent dans l’échantillon, y restent ou sont inclus dans l’analyse.

## Definition — English

Distortion of an estimate caused by mechanisms determining which people or observations enter a sample, remain in it, or are included in the analysis.

## Exemple

Étudier uniquement les personnes restées dans une cohorte peut produire une association différente de celle de la population initiale si l’abandon dépend de l’exposition et du résultat.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Sélection sur une variable influencée par l’exposition, le résultat ou leurs causes, parfois sous la forme d’un conditionnement sur un collisionneur.

## Mécanisme probable

Sélection sur une variable influencée par l’exposition, le résultat ou leurs causes, parfois sous la forme d’un conditionnement sur un collisionneur.

## Analyse critique

C’est un biais méthodologique ou statistique, pas nécessairement une erreur de jugement humaine. Le terme couvre plusieurs mécanismes : échantillonnage, non-réponse, attrition, inclusion conditionnelle et sélection analytique. Dire qu’un échantillon est simplement « non représentatif » ne suffit pas toujours à caractériser le biais causal.

**Conclusion de l’audit :** concept méthodologique central et solidement défini.

## Comment le limiter ou l’étudier correctement ?

Définir la population source, documenter inclusion et attrition, représenter les mécanismes causaux et utiliser, lorsque justifié, pondération ou analyses de sensibilité.

## Classement

- Nature scientifique : biais d’échantillonnage et d’inférence causale
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : absent
- Statut français : article français contrôlé le 2026-08-01

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Selection_bias
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Biais_de_s%C3%A9lection

## Références scientifiques contrôlées

- Hernán, M. A., Hernández-Díaz, S., & Robins, J. M. (2004). A structural approach to selection bias. *Epidemiology*, 15(5), 615–625. https://doi.org/10.1097/01.ede.0000135174.63482.43

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
