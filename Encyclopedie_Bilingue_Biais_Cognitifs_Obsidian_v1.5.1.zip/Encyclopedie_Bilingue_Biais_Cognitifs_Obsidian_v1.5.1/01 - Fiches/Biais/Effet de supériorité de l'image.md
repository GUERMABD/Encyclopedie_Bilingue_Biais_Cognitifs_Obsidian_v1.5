---
type: biais-cognitif
nom_fr: Effet de supériorité de l'image
nom_en: Picture superiority effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: avantage mnésique fréquent des images sur les mots
robustesse: bien documenté, mais dépendant du matériel et du test
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Trop d'informations
aliases: []
---
# Effet de supériorité de l'image

> **English:** Picture superiority effect

## Définition — français

Meilleure mémorisation fréquente d’images que de mots désignant les mêmes objets.

## Definition — English

The frequent memory advantage of pictures over words naming the same objects.

## Exemple

Des dessins d’objets sont mieux reconnus plus tard que leurs noms écrits.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Distinctivité perceptive et combinaison de codes visuels et verbaux.

## Mécanisme probable

Distinctivité perceptive et combinaison de codes visuels et verbaux.

## Analyse critique

L’avantage n’est pas garanti pour les concepts abstraits, les images complexes ou les tests purement verbaux.

**Conclusion de l’audit :** bien documenté, mais dépendant du matériel et du test.

## Comment le limiter ?

Associer des images simples et pertinentes à une explication verbale.

## Classement

- Nature scientifique : avantage mnésique fréquent des images sur les mots
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Picture_superiority_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Ensor, T. M., Bancroft, T. D., & Hockley, W. E. (2019). Listening to the picture-superiority effect. *Experimental Psychology*, 66(2), 134–153. https://doi.org/10.1027/1618-3169/a000437

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
