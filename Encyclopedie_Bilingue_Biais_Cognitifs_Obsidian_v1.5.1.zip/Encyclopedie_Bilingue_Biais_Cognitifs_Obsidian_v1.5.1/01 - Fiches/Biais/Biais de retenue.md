---
type: biais-cognitif
nom_fr: Biais de retenue
nom_en: Restraint bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
nature_scientifique: biais de prévision de son autocontrôle
robustesse: effet expérimental documenté; amplitude et réplications variables selon les tentations
---
# Biais de retenue

> **English:** Restraint bias

## Définition — français

Tendance à surestimer sa capacité à résister à une tentation, ce qui peut conduire à s’y exposer davantage.

## Definition — English

The tendency to overestimate one’s ability to resist temptation, which can lead to greater exposure to it.

## Exemple

Une personne convaincue de pouvoir arrêter de grignoter garde des aliments très tentants à portée de main.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Sous-estimation de la puissance future des états viscéraux et confiance excessive dans le contrôle volontaire.

## Mécanisme probable

Sous-estimation de la puissance future des états viscéraux et confiance excessive dans le contrôle volontaire.

## Analyse critique

Une exposition volontaire n’est pas toujours irrationnelle et peut servir l’apprentissage. Les résultats dépendent du type de tentation et de l’état au moment de la prévision.

**Conclusion de l’audit :** effet expérimental documenté; amplitude et réplications variables selon les tentations.

## Comment le limiter ?

Réduire l’exposition, préparer une règle d’action et évaluer l’autocontrôle à partir de comportements passés comparables.

## Classement

- Nature scientifique : biais de prévision de son autocontrôle
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Restraint_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Nordgren, L. F., van Harreveld, F., & van der Pligt, J. (2009). The restraint bias: How the illusion of self-restraint promotes impulsive behavior. *Psychological Science*, 20(12), 1523–1528. https://doi.org/10.1111/j.1467-9280.2009.02468.x

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
