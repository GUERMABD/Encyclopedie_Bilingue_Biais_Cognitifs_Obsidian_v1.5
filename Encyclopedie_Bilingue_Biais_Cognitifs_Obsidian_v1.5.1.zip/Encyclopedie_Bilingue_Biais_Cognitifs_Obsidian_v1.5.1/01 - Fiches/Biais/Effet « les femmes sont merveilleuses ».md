---
type: effet-social
nom_fr: Effet « les femmes sont merveilleuses »
nom_en: Women are wonderful effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: évaluation affective moyenne plus positive des femmes sur certaines dimensions
robustesse: effet moyen documenté dans certains échantillons et mesures; très dépendant des rôles, dimensions et contextes
---
# Effet « les femmes sont merveilleuses »

> **English:** Women are wonderful effect

## Définition — français

Tendance moyenne à évaluer les femmes plus positivement que les hommes sur des traits chaleureux ou moraux.

## Definition — English

An average tendency to evaluate women more positively than men on warm or moral traits.

## Exemple

Des participantes et participants attribuent davantage de chaleur aux femmes, tout en leur refusant parfois compétence ou autorité.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Stéréotypes de genre, rôles sociaux et association femmes–communauté.

## Mécanisme probable

Stéréotypes de genre, rôles sociaux et association femmes–communauté.

## Analyse critique

Une attitude globale positive n’implique pas l’absence de sexisme, de discrimination ou de stéréotypes paternalistes.

**Conclusion de l’audit :** effet moyen documenté dans certains échantillons et mesures; très dépendant des rôles, dimensions et contextes.

## Comment le limiter ?

Évaluer séparément chaleur, compétence, pouvoir, comportement réel et conséquences institutionnelles.

## Classement

- Nature scientifique : évaluation affective moyenne plus positive des femmes sur certaines dimensions
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Women_are_wonderful_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Eagly, A. H., & Mladinic, A. (1994). Are people prejudiced against women? Some answers from research on attitudes, gender stereotypes, and judgments of competence. *European Review of Social Psychology*, 5(1), 1–35. https://doi.org/10.1080/14792779543000002

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
