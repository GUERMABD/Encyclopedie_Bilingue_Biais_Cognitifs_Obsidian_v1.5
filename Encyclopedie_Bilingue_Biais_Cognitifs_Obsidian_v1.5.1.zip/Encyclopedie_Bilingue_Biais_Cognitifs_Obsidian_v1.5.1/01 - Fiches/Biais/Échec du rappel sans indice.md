---
type: biais-cognitif
nom_fr: Échec du rappel sans indice
nom_en: Cue-dependent forgetting
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: défaillance d’accessibilité malgré une trace disponible
robustesse: distinction disponibilité-accessibilité classique et bien établie
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Trop d'informations
aliases:
- Cue–dependent forgetting
---
# Échec du rappel sans indice

> **English:** Cue-dependent forgetting

## Définition — français

Incapacité temporaire à rappeler une information qui devient accessible lorsqu’un indice approprié est fourni.

## Definition — English

A temporary failure to recall information that becomes accessible when an appropriate cue is provided.

## Exemple

Une personne ne parvient pas à produire le nom d’un ancien collègue, mais le reconnaît immédiatement lorsqu’il apparaît dans une liste.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Dépendance de la récupération aux indices et à l’organisation de l’encodage.

## Mécanisme probable

Dépendance de la récupération aux indices et à l’organisation de l’encodage.

## Analyse critique

L’échec du rappel ne prouve pas que l’information est absente de la mémoire. Inversement, la reconnaissance peut reposer sur une simple familiarité.

**Conclusion de l’audit :** distinction disponibilité-accessibilité classique et bien établie.

## Comment le limiter ?

Créer plusieurs indices de récupération et pratiquer le rappel dans des contextes variés.

## Classement

- Nature scientifique : défaillance d’accessibilité malgré une trace disponible
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Cue-dependent_forgetting
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tulving, E., & Pearlstone, Z. (1966). Availability versus accessibility of information in memory for words. *Journal of Verbal Learning and Verbal Behavior*, 5(4), 381–391. https://doi.org/10.1016/S0022-5371(66)80048-8

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
