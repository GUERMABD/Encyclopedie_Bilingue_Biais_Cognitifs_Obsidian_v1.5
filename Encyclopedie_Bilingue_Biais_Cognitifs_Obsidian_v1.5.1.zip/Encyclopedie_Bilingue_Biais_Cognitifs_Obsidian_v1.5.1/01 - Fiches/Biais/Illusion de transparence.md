---
type: biais-cognitif
nom_fr: Illusion de transparence
nom_en: Illusion of transparency
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: surestimation de la lisibilité de ses états internes
robustesse: effet social expérimental documenté
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases: []
---
# Illusion de transparence

> **English:** Illusion of transparency

## Définition — français

Tendance à surestimer la capacité d’autrui à détecter ses émotions, intentions ou connaissances internes.

## Definition — English

The tendency to overestimate others’ ability to detect one’s internal emotions, intentions, or knowledge.

## Exemple

Un orateur anxieux pense que son stress est évident pour tout le public.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Ancrage sur l’expérience interne intense et ajustement insuffisant vers l’information réellement visible.

## Mécanisme probable

Ancrage sur l’expérience interne intense et ajustement insuffisant vers l’information réellement visible.

## Analyse critique

Certains signaux sont effectivement perceptibles; l’illusion concerne l’écart entre visibilité estimée et réelle.

**Conclusion de l’audit :** effet social expérimental documenté.

## Comment le limiter ?

Demander un retour observable plutôt que déduire ce que les autres ont perçu.

## Classement

- Nature scientifique : surestimation de la lisibilité de ses états internes
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Illusion_of_transparency
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Gilovich, T., Savitsky, K., & Medvec, V. H. (1998). The illusion of transparency. *Journal of Personality and Social Psychology*, 75(2), 332–346. https://doi.org/10.1037/0022-3514.75.2.332

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
