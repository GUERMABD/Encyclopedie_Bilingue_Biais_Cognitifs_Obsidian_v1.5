---
type: biais-cognitif
nom_fr: Biais de la portion
nom_en: Unit bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Baseline
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: heuristique de consommation fondée sur l’unité
robustesse: effet expérimental documenté surtout pour l’alimentation; généralisation hors domaine à tester
---
# Biais de la portion

> **English:** Unit bias

## Définition — français

Tendance à considérer une unité ou portion proposée comme la quantité appropriée à consommer.

## Definition — English

The tendency to treat a provided unit or portion as the appropriate amount to consume.

## Exemple

Une personne termine un sachet individuel plus grand sans ajuster sa consommation à sa faim.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : La portion fournie sert de norme implicite et de point d’arrêt.

## Mécanisme probable

La portion fournie sert de norme implicite et de point d’arrêt.

## Analyse critique

La taille de portion agit avec la faim, le prix, les habitudes et les caractéristiques du produit. Le terme ne signifie pas que chaque portion est consommée intégralement.

**Conclusion de l’audit :** effet expérimental documenté surtout pour l’alimentation; généralisation hors domaine à tester.

## Comment le limiter ?

Servir de petites unités, afficher la quantité totale et décider de la portion avant de commencer.

## Classement

- Nature scientifique : heuristique de consommation fondée sur l’unité
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/List_of_cognitive_biases
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Geier, A. B., Rozin, P., & Doros, G. (2006). Unit bias: A new heuristic that helps explain the effect of portion size on food intake. *Psychological Science*, 17(6), 521–525. https://doi.org/10.1111/j.1467-9280.2006.01738.x

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
