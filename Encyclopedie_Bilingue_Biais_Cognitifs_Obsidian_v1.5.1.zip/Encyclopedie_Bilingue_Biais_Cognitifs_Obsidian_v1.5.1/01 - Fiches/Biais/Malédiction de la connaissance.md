---
type: biais-cognitif
nom_fr: Malédiction de la connaissance
nom_en: Curse of knowledge
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de prise de perspective
robustesse: bien documenté dans plusieurs tâches; dépendant de la saillance et des possibilités de simulation
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases: []
---
# Malédiction de la connaissance

> **English:** Curse of knowledge

## Définition — français

Difficulté à se représenter correctement ce qu’une personne moins informée sait, comprend ou prévoit.

## Definition — English

Difficulty accurately representing what a less-informed person knows, understands, or can predict.

## Exemple

Un expert rédige une procédure incompréhensible parce qu’il sous-estime les connaissances manquantes du débutant.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Ancrage sur son propre état de connaissance et ajustement insuffisant.

## Mécanisme probable

Ancrage sur son propre état de connaissance et ajustement insuffisant.

## Analyse critique

L’expertise n’entraîne pas toujours ce biais; des outils de conception et une expérience pédagogique peuvent le réduire.

**Conclusion de l’audit :** bien documenté dans plusieurs tâches; dépendant de la saillance et des possibilités de simulation.

## Comment le limiter ?

Tester auprès du public cible, expliciter les prérequis et demander au novice de reformuler.

## Classement

- Nature scientifique : biais de prise de perspective
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Curse_of_knowledge
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Camerer, C., Loewenstein, G., & Weber, M. (1989). The curse of knowledge in economic settings: An experimental analysis. *Journal of Political Economy*, 97(5), 1232–1254. https://doi.org/10.1086/261651

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
