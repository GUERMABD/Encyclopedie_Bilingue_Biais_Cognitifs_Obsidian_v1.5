---
type: effet-metacognitif
nom_fr: Effet de difficulté de traitement
nom_en: Processing difficulty effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: effet conditionnel de difficulté perceptive ou cognitive sur apprentissage et jugement
robustesse: résultats hétérogènes; une difficulté utile doit déclencher un traitement supplémentaire sans empêcher l’encodage
---
# Effet de difficulté de traitement

> **English:** Processing difficulty effect

## Définition — français

Modification de la mémorisation ou du jugement lorsqu’une information est plus difficile à traiter.

## Definition — English

A change in memory or judgment when information is more difficult to process.

## Exemple

Un texte légèrement dégradé peut parfois accroître l’attention, mais une dégradation forte nuit à l’apprentissage.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Effort attentionnel, métacognition et profondeur de traitement.

## Mécanisme probable

Effort attentionnel, métacognition et profondeur de traitement.

## Analyse critique

La formule « plus difficile = mieux appris » est fausse. Les effets désirables dépendent du niveau de difficulté, de la mesure et des connaissances antérieures.

**Conclusion de l’audit :** résultats hétérogènes; une difficulté utile doit déclencher un traitement supplémentaire sans empêcher l’encodage.

## Comment le limiter ?

Tester l’apprentissage par récupération différée et éviter de confondre effort ressenti et efficacité réelle.

## Classement

- Nature scientifique : effet conditionnel de difficulté perceptive ou cognitive sur apprentissage et jugement
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/List_of_cognitive_biases#Processing_difficulty_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Rosner, T. M., Davis, H., & Milliken, B. (2015). Perceptual blurring and recognition memory: A desirable difficulty effect revealed. *Acta Psychologica*, 160, 11–22. https://doi.org/10.1016/j.actpsy.2015.06.006
- Kornell, N., Rhodes, M. G., Castel, A. D., & Tauber, S. K. (2011). The ease-of-processing heuristic and the stability bias. *Psychological Science*, 22(6), 787–794. https://doi.org/10.1177/0956797611407929

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
