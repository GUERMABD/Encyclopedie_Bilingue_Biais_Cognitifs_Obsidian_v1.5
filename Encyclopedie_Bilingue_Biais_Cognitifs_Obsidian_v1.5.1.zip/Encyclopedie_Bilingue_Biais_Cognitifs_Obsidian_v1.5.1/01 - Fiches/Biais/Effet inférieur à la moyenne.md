---
type: biais-cognitif
nom_fr: Effet inférieur à la moyenne
nom_en: Worse-than-average effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de comparaison sociale
robustesse: répliqué pour certaines tâches difficiles ou peu fréquentes; très dépendant de la référence et de la difficulté
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Self-perspective
codex: []
aliases: []
---
# Effet inférieur à la moyenne

> **English:** Worse-than-average effect

## Définition — français

Tendance à se juger moins bon que la moyenne pour certaines capacités difficiles, rares ou mal maîtrisées.

## Definition — English

The tendency to judge oneself as below average for some difficult, uncommon, or poorly mastered abilities.

## Exemple

La plupart des personnes pensent être moins capables que la moyenne de jongler ou de survivre dans une situation extrême.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Ancrage sur sa propre difficulté puis ajustement insuffisant pour la difficulté rencontrée par autrui.

## Mécanisme probable

Ancrage sur sa propre difficulté puis ajustement insuffisant pour la difficulté rencontrée par autrui.

## Analyse critique

Il ne s’agit pas de l’opposé universel de la supériorité illusoire. Le sens de l’écart varie avec la difficulté, l’ambiguïté et le groupe de comparaison.

**Conclusion de l’audit :** répliqué pour certaines tâches difficiles ou peu fréquentes; très dépendant de la référence et de la difficulté.

## Comment le limiter ?

Définir la population de référence et utiliser des mesures objectives avant toute comparaison.

## Classement

- Nature scientifique : biais de comparaison sociale
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Worse-than-average_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kruger, J. (1999). Lake Wobegon be gone! The “below-average effect” and the egocentric nature of comparative ability judgments. *Journal of Personality and Social Psychology*, 77(2), 221–232. https://doi.org/10.1037/0022-3514.77.2.221

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
