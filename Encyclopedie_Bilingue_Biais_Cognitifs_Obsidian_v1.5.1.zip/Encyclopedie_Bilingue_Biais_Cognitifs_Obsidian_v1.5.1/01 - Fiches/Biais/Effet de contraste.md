---
type: famille-effets
nom_fr: Effet de contraste
nom_en: Contrast effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Trop d'informations
aliases: []
nature_scientifique: famille d’effets perceptifs et évaluatifs dépendant du point de comparaison
robustesse: phénomènes bien documentés, mais sans mécanisme unique ni amplitude universelle
---
# Effet de contraste

> **English:** Contrast effect

## Définition — français

Modification d’un jugement parce que l’objet est évalué après ou à côté d’un élément très différent.

## Definition — English

A shift in judgment caused by evaluating a target after or beside a markedly different comparison stimulus.

## Exemple

Un candidat de niveau moyen paraît exceptionnel lorsqu’il passe juste après une très mauvaise prestation, puis ordinaire lorsqu’on le compare au groupe entier.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Codage relatif, adaptation et comparaison avec un contexte local.

## Mécanisme probable

Codage relatif, adaptation et comparaison avec un contexte local.

## Analyse critique

Le terme regroupe des effets distincts en perception, en jugement social et en décision. Le contraste ne survient pas toujours; une assimilation au contexte est aussi possible.

**Conclusion de l’audit :** phénomènes bien documentés, mais sans mécanisme unique ni amplitude universelle.

## Comment le limiter ?

Employer des critères absolus, varier l’ordre de présentation et comparer plusieurs références.

## Classement

- Nature scientifique : famille d’effets perceptifs et évaluatifs dépendant du point de comparaison
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Contrast_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Sherif, M., Taub, D., & Hovland, C. I. (1958). Assimilation and contrast effects of anchoring stimuli on judgments. *Journal of Experimental Psychology*, 55(2), 150–155. https://doi.org/10.1037/h0048784

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
