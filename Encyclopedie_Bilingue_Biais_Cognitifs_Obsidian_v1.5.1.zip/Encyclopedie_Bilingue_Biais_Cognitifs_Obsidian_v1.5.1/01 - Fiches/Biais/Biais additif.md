---
type: biais-cognitif
nom_fr: Biais additif
nom_en: Additive bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: tendance de recherche de solutions par ajout
robustesse: résultat reproduit dans plusieurs tâches initiales; généralité à poursuivre
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex: []
aliases: []
---
# Biais additif

> **English:** Additive bias

## Définition — français

Tendance à envisager plus spontanément des modifications qui ajoutent des éléments que des modifications qui en retirent.

## Definition — English

The tendency to consider additive changes more readily than subtractive changes.

## Exemple

Pour simplifier une procédure, une équipe ajoute une nouvelle règle au lieu de supprimer une étape inutile.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Recherche limitée des solutions et disponibilité supérieure des transformations additives.

## Mécanisme probable

Recherche limitée des solutions et disponibilité supérieure des transformations additives.

## Analyse critique

L’étude fondatrice montre une tendance conditionnelle, renforcée par la charge cognitive. Elle ne prouve pas que l’ajout est toujours irrationnel ni que la soustraction est toujours meilleure.

**Conclusion de l’audit :** résultat reproduit dans plusieurs tâches initiales; généralité à poursuivre.

## Comment le limiter ?

Inclure explicitement la question « que peut-on supprimer ? » dans la recherche de solutions.

## Classement

- Nature scientifique : tendance de recherche de solutions par ajout
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Additive_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Adams, G. S., Converse, B. A., Hales, A. H., & Klotz, L. E. (2021). People systematically overlook subtractive changes. *Nature*, 592, 258–261. https://doi.org/10.1038/s41586-021-03380-y

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
