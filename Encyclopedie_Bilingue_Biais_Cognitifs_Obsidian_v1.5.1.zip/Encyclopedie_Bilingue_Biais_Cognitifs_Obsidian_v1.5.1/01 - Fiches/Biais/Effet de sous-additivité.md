---
type: effet-probabiliste
nom_fr: Effet de sous-additivité
nom_en: Subadditivity effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
- Hypothesis assessment
saveurs_classement_wikipedia:
- Baseline
- Association
codex:
- Manque de sens
aliases: []
nature_scientifique: violation de l’additivité dans l’estimation subjective de probabilités décomposées
robustesse: effet bien documenté dans le cadre de la théorie du support, modulé par la description et l’expertise
---
# Effet de sous-additivité

> **English:** Subadditivity effect

## Définition — français

Tendance à attribuer aux sous-cas explicites des probabilités dont la somme dépasse celle attribuée au cas global.

## Definition — English

The tendency for explicitly unpacked subcases to receive probabilities whose sum exceeds the probability assigned to the broad event.

## Exemple

Les probabilités estimées de plusieurs causes précises d’une panne dépassent l’estimation donnée à « toute autre panne ».

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Chaque description détaillée évoque davantage d’arguments et de support mental.

## Mécanisme probable

Chaque description détaillée évoque davantage d’arguments et de support mental.

## Analyse critique

La sous-additivité est une propriété de jugements construits, non une erreur arithmétique systématique dans toutes les situations.

**Conclusion de l’audit :** effet bien documenté dans le cadre de la théorie du support, modulé par la description et l’expertise.

## Comment le limiter ?

Vérifier que les catégories sont exclusives et exhaustives, puis normaliser les probabilités.

## Classement

- Nature scientifique : violation de l’additivité dans l’estimation subjective de probabilités décomposées
- Tâche(s) du classement Wikipédia : Estimation, Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Baseline, Association
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Subadditivity_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tversky, A., & Koehler, D. J. (1994). Support theory: A nonextensional representation of subjective probability. *Psychological Review*, 101(4), 547–567. https://doi.org/10.1037/0033-295X.101.4.547

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
