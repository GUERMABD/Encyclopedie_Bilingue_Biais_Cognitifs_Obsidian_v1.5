---
type: biais-cognitif
nom_fr: Argument tiré d'un sophisme
nom_en: Argument from fallacy
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Manque de sens
aliases: []
nature_scientifique: sophisme informel, aussi appelé sophisme du sophisme
robustesse: catégorie logique reconnue; pas un effet psychologique autonome
---
# Argument tiré d'un sophisme

> **English:** Argument from fallacy

## Définition — français

Conclure qu’une proposition est fausse uniquement parce qu’un argument avancé en sa faveur est invalide ou fallacieux.

## Definition — English

Concluding that a proposition is false solely because one argument offered for it is invalid or fallacious.

## Exemple

Un raisonnement erroné est utilisé pour défendre une conclusion vraie; la conclusion est rejetée avec le raisonnement.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Confusion entre qualité de l’argument et valeur de vérité de la conclusion.

## Mécanisme probable

Confusion entre qualité de l’argument et valeur de vérité de la conclusion.

## Analyse critique

Réfuter un argument ne réfute pas nécessairement sa conclusion. Inversement, repérer ce sophisme ne rend pas la conclusion vraie.

**Conclusion de l’audit :** catégorie logique reconnue; pas un effet psychologique autonome.

## Comment le limiter ?

Évaluer séparément la validité de l’argument et les preuves indépendantes concernant la conclusion.

## Classement

- Nature scientifique : sophisme informel, aussi appelé sophisme du sophisme
- Tâche(s) du classement Wikipédia : aucune
- Sous-catégorie(s) (« flavors ») : aucune
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Argument_from_fallacy
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tindale, C. W. (2007). *Fallacies and Argument Appraisal*. Cambridge University Press. https://doi.org/10.1017/CBO9780511806544

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
