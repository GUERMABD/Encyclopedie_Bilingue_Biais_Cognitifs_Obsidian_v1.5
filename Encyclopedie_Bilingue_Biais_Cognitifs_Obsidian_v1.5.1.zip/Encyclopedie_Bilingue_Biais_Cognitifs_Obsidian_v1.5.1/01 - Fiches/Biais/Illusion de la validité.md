---
type: biais-confiance
nom_fr: Illusion de la validité
nom_en: Illusion of validity
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
nature_scientifique: confiance excessive produite par un récit cohérent ou des indices redondants
robustesse: effet classique dans les tâches de prédiction; dépend de la structure des indices et du retour disponible
---
# Illusion de la validité

> **English:** Illusion of validity

## Définition — français

Confiance élevée dans une prédiction parce que les informations forment une histoire cohérente, même lorsqu’elles prédisent peu.

## Definition — English

High confidence in a prediction because the information forms a coherent story even when predictive validity is low.

## Exemple

Un entretien très cohérent donne une forte impression de compétence alors qu’il prédit mal la performance future.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Représentativité, cohérence narrative et négligence de la validité statistique.

## Mécanisme probable

Représentativité, cohérence narrative et négligence de la validité statistique.

## Analyse critique

Une histoire cohérente peut parfois être réellement informative; l’erreur apparaît lorsque la confiance excède la précision mesurée.

**Conclusion de l’audit :** effet classique dans les tâches de prédiction; dépend de la structure des indices et du retour disponible.

## Comment le limiter ?

Comparer les prédictions à des taux de base et à une validation hors échantillon.

## Classement

- Nature scientifique : confiance excessive produite par un récit cohérent ou des indices redondants
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Illusion_of_validity
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kahneman, D., & Tversky, A. (1973). On the psychology of prediction. *Psychological Review*, 80(4), 237–251. https://doi.org/10.1037/h0034747

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
