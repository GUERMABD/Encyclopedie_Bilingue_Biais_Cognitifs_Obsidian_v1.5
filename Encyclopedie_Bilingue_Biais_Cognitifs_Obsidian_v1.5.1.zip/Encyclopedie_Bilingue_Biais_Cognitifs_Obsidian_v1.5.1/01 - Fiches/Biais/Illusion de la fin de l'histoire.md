---
type: effet-prospectif
nom_fr: Illusion de la fin de l'histoire
nom_en: End-of-history illusion
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Inertia
codex: []
aliases: []
nature_scientifique: sous-estimation des changements futurs du soi par rapport aux changements passés rapportés
robustesse: effet initial observé sur un vaste échantillon, mais fondé surtout sur comparaisons transversales et auto-évaluations
---
# Illusion de la fin de l'histoire

> **English:** End-of-history illusion

## Définition — français

Tendance à croire que ses goûts, valeurs et traits changeront moins à l’avenir qu’ils n’ont changé dans le passé.

## Definition — English

The tendency to believe that one’s preferences, values, and traits will change less in the future than they changed in the past.

## Exemple

Une personne reconnaît avoir beaucoup changé en dix ans, mais pense être presque définitive aujourd’hui.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Difficulté à simuler le futur et disponibilité supérieure des souvenirs du passé.

## Mécanisme probable

Difficulté à simuler le futur et disponibilité supérieure des souvenirs du passé.

## Analyse critique

Les estimations rétrospectives peuvent elles-mêmes être reconstruites; l’effet ne prouve pas que chacun sous-estime toujours son évolution.

**Conclusion de l’audit :** effet initial observé sur un vaste échantillon, mais fondé surtout sur comparaisons transversales et auto-évaluations.

## Comment le limiter ?

Prévoir des marges de changement et éviter les engagements irréversibles fondés sur des préférences supposées permanentes.

## Classement

- Nature scientifique : sous-estimation des changements futurs du soi par rapport aux changements passés rapportés
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/End-of-history_illusion
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Quoidbach, J., Gilbert, D. T., & Wilson, T. D. (2013). The end of history illusion. *Science*, 339(6115), 96–98. https://doi.org/10.1126/science.1229294

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
