---
type: biais-cognitif
nom_fr: Effet acteur-observateur
nom_en: Actor-observer bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases:
- Actor–observer bias
nature_scientifique: hypothèse attributionnelle
robustesse: débattue dans sa forme générale
---
# Effet acteur-observateur

> **English:** Actor-observer bias

## Définition — français

Hypothèse selon laquelle une personne expliquerait davantage son propre comportement par la situation et celui d’autrui par ses dispositions personnelles.

## Definition — English

The hypothesis that people explain their own behavior more by situational causes and others’ behavior more by personal dispositions.

## Exemple

Un individu explique son retard par les transports, mais le retard d’un collègue par son manque de sérieux.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Différences d’information, de perspective visuelle et d’enjeu pour l’image de soi ont été proposées comme explications.

## Mécanisme probable

Différences d’information, de perspective visuelle et d’enjeu pour l’image de soi ont été proposées comme explications.

## Analyse critique

La méta-analyse de 173 études ne retrouve pas d’asymétrie générale substantielle. Des effets apparaissent surtout dans certaines conditions, notamment selon la valence, la relation entre les personnes et le type d’explication demandé.

**Conclusion de l’audit :** débattue dans sa forme générale.

## Comment le limiter ?

Ne pas utiliser cette étiquette comme loi générale. Comparer les mêmes informations pour l’acteur et l’observateur et examiner séparément les événements positifs et négatifs.

## Classement

- Nature scientifique : hypothèse attributionnelle
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Actor–observer_asymmetry#bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Malle, B. F. (2006). The actor-observer asymmetry in attribution: A (surprising) meta-analysis. *Psychological Bulletin*, 132(6), 895–919. https://doi.org/10.1037/0033-2909.132.6.895

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
