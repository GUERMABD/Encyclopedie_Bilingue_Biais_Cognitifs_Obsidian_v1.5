---
type: biais-cognitif
nom_fr: Biais de négligence du contexte
nom_en: Context neglect bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: concept critique lié au solutionnisme technologique
robustesse: concept utile mais sans paradigme psychologique unique ni étude fondatrice clairement établie
---
# Biais de négligence du contexte

> **English:** Context neglect bias

## Définition — français

Tendance à évaluer une solution technique en négligeant les conditions humaines, sociales, culturelles ou institutionnelles nécessaires à son fonctionnement.

## Definition — English

The tendency to evaluate a technical solution while neglecting the human, social, cultural, or institutional conditions required for it to work.

## Exemple

Une application est jugée suffisante pour résoudre un problème d’accès sans examiner l’équipement, la confiance ou les règles locales.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Focalisation sur l’objet technique et simplification des interactions avec le système social.

## Mécanisme probable

Focalisation sur l’objet technique et simplification des interactions avec le système social.

## Analyse critique

Cette étiquette est davantage une catégorie d’analyse de conception qu’un biais expérimental autonome. Elle recoupe erreur fondamentale d’attribution, négligence des taux de base et solutionnisme.

**Conclusion de l’audit :** concept utile mais sans paradigme psychologique unique ni étude fondatrice clairement établie.

## Comment le limiter ?

Cartographier les acteurs, contraintes, incitations et usages réels; tester la solution dans le contexte visé.

## Classement

- Nature scientifique : concept critique lié au solutionnisme technologique
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Context_neglect_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Morozov, E. (2013). *To Save Everything, Click Here: The Folly of Technological Solutionism*. PublicAffairs.

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
