---
type: biais-cognitif
nom_fr: Biais de véracité
nom_en: Truth bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: tendance de jugement et stratégie par défaut en détection du mensonge
robustesse: bien documenté comme tendance moyenne; fortement dépendant du taux réel de vérités et du contexte
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Biais de véracité

> **English:** Truth bias

## Définition — français

Tendance à juger un message comme véridique en l’absence d’un signal suffisamment fort de tromperie.

## Definition — English

The tendency to judge a message as truthful unless sufficiently strong evidence of deception is present.

## Exemple

Lors d’un entretien ordinaire, une déclaration ambiguë est d’abord acceptée plutôt que traitée comme mensongère.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Présomption de sincérité, fréquence élevée des messages vrais et coût social d’une suspicion permanente.

## Mécanisme probable

Présomption de sincérité, fréquence élevée des messages vrais et coût social d’une suspicion permanente.

## Analyse critique

Cette tendance peut être rationnelle lorsque la majorité des messages sont vrais. Elle ne signifie pas que les humains seraient incapables de détecter tout mensonge.

**Conclusion de l’audit :** bien documenté comme tendance moyenne; fortement dépendant du taux réel de vérités et du contexte.

## Comment le limiter ?

Vérifier les affirmations à enjeu élevé par des éléments indépendants plutôt que par l’impression de sincérité.

## Classement

- Nature scientifique : tendance de jugement et stratégie par défaut en détection du mensonge
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Truth_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Levine, T. R. (2014). Truth-default theory (TDT): A theory of human deception and deception detection. *Journal of Language and Social Psychology*, 33(4), 378–392. https://doi.org/10.1177/0261927X14535916

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
