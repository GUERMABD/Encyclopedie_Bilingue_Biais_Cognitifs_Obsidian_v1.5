---
type: biais-cognitif
nom_fr: Biais d'incarnation
nom_en: Embodiment bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: famille d’effets de cognition incarnée
robustesse: effets corps-concept documentés, mais étiquette trop large pour un effet unique
---
# Biais d'incarnation

> **English:** Embodiment bias

## Définition — français

Influence des propriétés et capacités corporelles sur la manière d’attribuer une signification ou une valeur à des objets et événements.

## Definition — English

Influence of bodily properties and capacities on how meaning or value is attributed to objects and events.

## Exemple

Des droitiers et des gauchers associent différemment le côté de leur main dominante à des évaluations positives.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Expérience sensorimotrice, accessibilité des actions et métaphores spatiales issues du corps.

## Mécanisme probable

Expérience sensorimotrice, accessibilité des actions et métaphores spatiales issues du corps.

## Analyse critique

La cognition incarnée regroupe plusieurs hypothèses. Une différence corporelle n’implique pas automatiquement un biais irrationnel, et certains effets d’amorçage corporel sont sensibles aux méthodes.

**Conclusion de l’audit :** effets corps-concept documentés, mais étiquette trop large pour un effet unique.

## Comment le limiter ?

Vérifier si le jugement change lorsque la posture, la main ou la contrainte corporelle change et utiliser des mesures convergentes.

## Classement

- Nature scientifique : famille d’effets de cognition incarnée
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Embodiment_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Casasanto, D. (2009). Embodiment of abstract concepts: Good and bad in right- and left-handers. *Journal of Experimental Psychology: General*, 138(3), 351–367. https://doi.org/10.1037/a0015854

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
