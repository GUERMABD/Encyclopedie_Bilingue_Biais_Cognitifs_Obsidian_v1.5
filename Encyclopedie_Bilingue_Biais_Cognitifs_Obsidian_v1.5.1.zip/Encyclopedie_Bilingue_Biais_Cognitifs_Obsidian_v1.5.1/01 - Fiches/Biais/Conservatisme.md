---
type: biais-cognitif
nom_fr: Conservatisme
nom_en: Conservatism bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: sous-ajustement dans certaines inférences probabilistes
robustesse: effet classique mais non universel; dépendant des priors, formats et modèles normatifs
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Inertia
codex:
- Trop d'informations
aliases:
- Conservatism
---
# Conservatisme

> **English:** Conservatism bias

## Définition — français

Tendance à réviser une croyance moins fortement que ne le prescrirait un modèle bayésien donné après réception de nouvelles données.

## Definition — English

The tendency to update a belief less than a specified Bayesian model would prescribe after receiving new evidence.

## Exemple

Après un test très informatif, l’estimation reste trop proche de la probabilité initiale.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Ancrage sur la croyance antérieure et traitement imparfait du rapport de vraisemblance.

## Mécanisme probable

Ancrage sur la croyance antérieure et traitement imparfait du rapport de vraisemblance.

## Analyse critique

Un écart au modèle peut venir d’un prior différent, d’une méfiance envers les données ou d’un modèle causal plus riche. Il ne faut pas qualifier tout maintien d’opinion de conservatisme.

**Conclusion de l’audit :** effet classique mais non universel; dépendant des priors, formats et modèles normatifs.

## Comment le limiter ?

Expliciter les probabilités initiales, la fiabilité du signal et le calcul de mise à jour.

## Classement

- Nature scientifique : sous-ajustement dans certaines inférences probabilistes
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Conservatism_(belief_revision)
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Phillips, L. D., & Edwards, W. (1966). Conservatism in a simple probability inference task. *Journal of Experimental Psychology*, 72(3), 346–354. https://doi.org/10.1037/h0023653

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
