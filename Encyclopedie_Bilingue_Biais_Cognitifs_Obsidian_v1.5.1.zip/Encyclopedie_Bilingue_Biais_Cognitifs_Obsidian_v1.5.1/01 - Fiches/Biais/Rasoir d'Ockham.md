---
type: principe-methodologique
nom_fr: Rasoir d'Ockham
nom_en: Occam's razor
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: principe de parcimonie pour comparer des explications compatibles avec les données
robustesse: principe philosophique et méthodologique, non biais cognitif ni garantie de vérité
---
# Rasoir d'Ockham

> **English:** Occam's razor

## Définition — français

Principe recommandant de ne pas multiplier les hypothèses sans nécessité lorsque plusieurs explications rendent compte des mêmes données.

## Definition — English

A principle recommending that unnecessary assumptions not be multiplied when competing explanations fit the same evidence.

## Exemple

Entre deux modèles de précision comparable, retenir provisoirement celui qui nécessite moins de paramètres non justifiés.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Préférence méthodologique pour la parcimonie, parfois formalisée par pénalisation de complexité.

## Mécanisme probable

Préférence méthodologique pour la parcimonie, parfois formalisée par pénalisation de complexité.

## Analyse critique

Le modèle le plus simple n’est pas toujours vrai. La simplicité dépend de la question, du langage et des coûts prédictifs.

**Conclusion de l’audit :** principe philosophique et méthodologique, non biais cognitif ni garantie de vérité.

## Comment le limiter ?

Comparer ajustement, prédiction hors échantillon et complexité plutôt que compter intuitivement les hypothèses.

## Classement

- Nature scientifique : principe de parcimonie pour comparer des explications compatibles avec les données
- Tâche(s) du classement Wikipédia : non repris dans la liste anglaise contrôlée
- Sous-catégorie(s) (« flavors ») : non applicable
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Occam's_razor
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Sober, E. (2015). *Ockham’s Razors: A User’s Manual*. Cambridge University Press. https://doi.org/10.1017/CBO9781107705937

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
