---
type: biais-cognitif
nom_fr: Erreur de la preuve anecdotique
nom_en: Anecdotal fallacy
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: erreur de raisonnement et de pondération des preuves
robustesse: bien documentée comme avantage persuasif du concret; le terme recouvre plusieurs erreurs
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Manque de sens
aliases: []
---
# Erreur de la preuve anecdotique

> **English:** Anecdotal fallacy

## Définition — français

Accorder à un récit particulier plus de poids qu’à des données plus représentatives sans justification méthodologique.

## Definition — English

Giving a particular story more weight than more representative evidence without methodological justification.

## Exemple

Un témoignage spectaculaire est préféré à une étude portant sur des milliers de cas.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Vivacité, facilité de simulation mentale et identification à un cas concret.

## Mécanisme probable

Vivacité, facilité de simulation mentale et identification à un cas concret.

## Analyse critique

Une anecdote peut signaler un problème réel ou générer une hypothèse. L’erreur consiste à lui faire remplacer l’estimation de fréquence, le groupe témoin ou l’ensemble des données.

**Conclusion de l’audit :** bien documentée comme avantage persuasif du concret; le terme recouvre plusieurs erreurs.

## Comment le limiter ?

Traiter l’anecdote comme un cas, puis demander le dénominateur, la sélection des cas et les données comparatives.

## Classement

- Nature scientifique : erreur de raisonnement et de pondération des preuves
- Tâche(s) du classement Wikipédia : aucune
- Sous-catégorie(s) (« flavors ») : aucune
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Anecdotal_evidence
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Borgida, E., & Nisbett, R. E. (1977). The differential impact of abstract versus concrete information on decisions. *Journal of Applied Social Psychology*, 7(3), 258–271. https://doi.org/10.1111/j.1559-1816.1977.tb00750.x

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
