---
type: heuristique
nom_fr: Heuristique de disponibilité
nom_en: Availability heuristic
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: raccourci d’estimation fondé sur la facilité de rappel ou de construction d’exemples
robustesse: heuristique bien documentée ; elle ne produit un biais que lorsque la disponibilité diverge de la fréquence
  réelle
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Association
codex:
- Trop d'informations
aliases: []
---
# Heuristique de disponibilité

> **English:** Availability heuristic

## Définition — français

Tendance à estimer la fréquence ou la probabilité d'un événement selon la facilité avec laquelle des exemples viennent à l'esprit.

## Definition — English

The tendency to estimate frequency or probability by how easily examples come to mind.

## Exemple

Après plusieurs reportages sur des accidents d'avion, une personne surestime le risque de prendre l'avion.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Confusion entre facilité de rappel et fréquence réelle.

## Mécanisme probable

Confusion entre facilité de rappel et fréquence réelle.

## Analyse critique

La disponibilité est d’abord une heuristique : la facilité avec laquelle des exemples viennent à l’esprit peut fournir une information utile lorsque mémoire et fréquence réelle sont corrélées. Elle produit une erreur lorsque la saillance, les médias, la récence ou l’émotion rendent certains événements plus accessibles que leur fréquence objective.

**Conclusion de l’audit :** heuristique établie, mais pas biais systématique dans toutes les situations.

## Comment le limiter ?

Comparer l'impression spontanée à des taux de base et à des données sur une période suffisamment longue.

## Classement

- Nature scientifique : raccourci d’estimation fondé sur la facilité de rappel ou de construction d’exemples
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Availability_heuristic
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tversky, A., & Kahneman, D. (1973). Availability: A heuristic for judging frequency and probability. *Cognitive Psychology*, 5(2), 207–232. https://doi.org/10.1016/0010-0285(73)90033-9

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
