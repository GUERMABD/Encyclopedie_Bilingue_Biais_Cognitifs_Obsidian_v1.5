---
type: biais-cognitif
nom_fr: Biais de pessimisme
nom_en: Pessimism bias
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases: []
nature_scientifique: famille de prévisions négativement décalées
robustesse: associations documentées notamment avec les symptômes dépressifs; pas une tendance universelle ni un effet unique
---
# Biais de pessimisme

> **English:** Pessimism bias

## Définition — français

Tendance à surestimer la probabilité ou la gravité d’issues défavorables par rapport aux données disponibles.

## Definition — English

The tendency to overestimate the probability or severity of unfavorable outcomes relative to available evidence.

## Exemple

Une personne estime presque certain l’échec d’un projet malgré un historique de réussite comparable.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attention aux menaces, humeur, apprentissage antérieur et pondération asymétrique des résultats négatifs.

## Mécanisme probable

Attention aux menaces, humeur, apprentissage antérieur et pondération asymétrique des résultats négatifs.

## Analyse critique

Un pronostic négatif peut être exact et la prudence peut être rationnelle. L’étiquette regroupe plusieurs processus et doit être distinguée du réalisme dépressif.

**Conclusion de l’audit :** associations documentées notamment avec les symptômes dépressifs; pas une tendance universelle ni un effet unique.

## Comment le limiter ?

Formuler des probabilités, utiliser des classes de référence et comparer régulièrement prédictions et résultats.

## Classement

- Nature scientifique : famille de prévisions négativement décalées
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Optimism_bias#Pessimism_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Strunk, D. R., Lopez, H., & DeRubeis, R. J. (2006). Depressive symptoms are associated with unrealistic negative predictions of future life events. *Behaviour Research and Therapy*, 44(6), 861–882. https://doi.org/10.1016/j.brat.2005.07.001

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
