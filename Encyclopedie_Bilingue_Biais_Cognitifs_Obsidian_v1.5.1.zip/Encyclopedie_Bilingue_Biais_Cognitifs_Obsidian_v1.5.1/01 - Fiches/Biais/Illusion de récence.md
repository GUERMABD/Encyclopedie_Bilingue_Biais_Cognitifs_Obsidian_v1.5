---
type: etiquette-linguistique
nom_fr: Illusion de récence
nom_en: Recency illusion
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
nature_scientifique: impression erronée qu’un usage linguistique ancien est récent
robustesse: étiquette utile et illustrée par des corpus, mais non biais psychologique standardisé
---
# Illusion de récence

> **English:** Recency illusion

## Définition — français

Impression qu’un mot, une expression ou une construction vient d’apparaître alors qu’elle est attestée depuis longtemps.

## Definition — English

The mistaken impression that a word, expression, or construction is new despite much older attestations.

## Exemple

Une tournure remarquée récemment est dénoncée comme invention moderne, alors que des archives la montrent au XIXe siècle.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attention récente, disponibilité personnelle et connaissance incomplète des corpus historiques.

## Mécanisme probable

Attention récente, disponibilité personnelle et connaissance incomplète des corpus historiques.

## Analyse critique

Le terme a été proposé dans le domaine linguistique et ne doit pas être généralisé à toute préférence pour les événements récents.

**Conclusion de l’audit :** étiquette utile et illustrée par des corpus, mais non biais psychologique standardisé.

## Comment le limiter ?

Consulter des corpus datés et distinguer apparition, hausse de fréquence et première observation personnelle.

## Classement

- Nature scientifique : impression erronée qu’un usage linguistique ancien est récent
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Recency_illusion
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Zwicky, A. M. (2005). Just between Dr. Language and I. *Language Log*, 7 August 2005.
- van der Meulen, M. (2022). Are we indeed so illuded? Recency and frequency illusions in Dutch prescriptivism. *Languages*, 7(1), 42. https://doi.org/10.3390/languages7010042

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
