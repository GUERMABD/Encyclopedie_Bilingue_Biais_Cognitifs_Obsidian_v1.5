---
type: biais-cognitif
nom_fr: Confusion de la source
nom_en: Source confusion
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: erreur de surveillance de la source mnésique
robustesse: cadre théorique et phénomènes associés bien établis
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Confusion de la source

> **English:** Source confusion

## Définition — français

Attribution erronée de l’origine d’une information correctement ou partiellement mémorisée.

## Definition — English

The incorrect attribution of the origin of remembered information.

## Exemple

Une personne se souvient d’un fait mais croit l’avoir lu dans une source officielle alors qu’il venait d’une conversation.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Évaluation imparfaite des caractéristiques perceptives, contextuelles et cognitives du souvenir.

## Mécanisme probable

Évaluation imparfaite des caractéristiques perceptives, contextuelles et cognitives du souvenir.

## Analyse critique

Il ne s’agit pas nécessairement d’un faux contenu : l’information peut être exacte tandis que son origine est mal attribuée.

**Conclusion de l’audit :** cadre théorique et phénomènes associés bien établis.

## Comment le limiter ?

Enregistrer la source avec l’information et vérifier les citations avant réutilisation.

## Classement

- Nature scientifique : erreur de surveillance de la source mnésique
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Misattribution_of_memory#Source_confusion
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Johnson, M. K., Hashtroudi, S., & Lindsay, D. S. (1993). Source monitoring. *Psychological Bulletin*, 114(1), 3–28. https://doi.org/10.1037/0033-2909.114.1.3

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
