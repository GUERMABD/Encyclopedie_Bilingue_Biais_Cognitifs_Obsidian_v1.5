---
type: biais-cognitif
nom_fr: Supériorité illusoire
nom_en: Illusory superiority
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: famille de biais de comparaison entre soi et autrui
robustesse: effet moyen robuste mais fortement modulé par la difficulté, l’ambiguïté et le groupe de référence
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases:
- Effet Lac Wobegon
- Lake Wobegon effect
- better-than-average effect
---
# Supériorité illusoire

> **English:** Illusory superiority

## Définition — français

Tendance à s’évaluer au-dessus de la moyenne sur certaines qualités ou capacités, particulièrement lorsque les critères sont ambigus ou valorisés.

## Definition — English

The tendency to rate oneself above average on some valued or ambiguous traits and abilities.

## Exemple

Dans une enquête, une majorité de conducteurs se décrit comme plus prudente et plus compétente que le conducteur moyen du même groupe.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Information plus riche sur soi, définition favorable des critères et comparaison égocentrée.

## Mécanisme probable

Information plus riche sur soi, définition favorable des critères et comparaison égocentrée.

## Analyse critique

L’« effet Lac Wobegon » est un alias, non un phénomène distinct. L’effet n’apparaît pas pour toutes les tâches et peut s’inverser pour des capacités difficiles.

**Conclusion de l’audit :** effet moyen robuste mais fortement modulé par la difficulté, l’ambiguïté et le groupe de référence.

## Comment le limiter ?

Définir des critères mesurables, choisir une population de référence explicite et rechercher un retour externe calibré.

## Classement

- Nature scientifique : famille de biais de comparaison entre soi et autrui
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Illusory_superiority
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Alicke, M. D., Klotz, M. L., Breitenbecher, D. L., Yurak, T. J., & Vredenburg, D. S. (1995). Personal contact, individuation, and the better-than-average effect. *Journal of Personality and Social Psychology*, 68(5), 804–825. https://doi.org/10.1037/0022-3514.68.5.804
- Kruger, J. (1999). Lake Wobegon be gone! The “below-average effect” and the egocentric nature of comparative ability judgments. *Journal of Personality and Social Psychology*, 77(2), 221–232. https://doi.org/10.1037/0022-3514.77.2.221

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
