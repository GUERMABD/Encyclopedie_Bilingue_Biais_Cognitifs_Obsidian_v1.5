---
type: biais-cognitif
nom_fr: Décalage empathique
nom_en: Hot-cold empathy gap
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de prévision entre états viscéraux ou affectifs
robustesse: bien documenté comme famille d’effets; ampleur dépendante du type d’état et de l’expérience
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Association
codex:
- Trop d'informations
aliases:
- Empathy gap
---
# Décalage empathique

> **English:** Hot-cold empathy gap

## Définition — français

Difficulté à prédire ou comprendre les choix et sentiments d’un autre état affectif ou physiologique depuis l’état présent.

## Definition — English

Difficulty predicting or understanding choices and feelings in a different affective or physiological state from the current one.

## Exemple

Lorsqu’elle est rassasiée, une personne sous-estime combien la faim influencera ses décisions plus tard.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Ancrage sur l’état actuel et faible simulation des états « chauds » ou « froids ».

## Mécanisme probable

Ancrage sur l’état actuel et faible simulation des états « chauds » ou « froids ».

## Analyse critique

L’expérience et des indices concrets peuvent améliorer la prévision. Le terme recouvre des écarts chaud-froid, intrapersonnels ou interpersonnels, qui ne sont pas identiques.

**Conclusion de l’audit :** bien documenté comme famille d’effets; ampleur dépendante du type d’état et de l’expérience.

## Comment le limiter ?

Planifier dans plusieurs états, utiliser des engagements préalables et consulter des données de comportement passées.

## Classement

- Nature scientifique : biais de prévision entre états viscéraux ou affectifs
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Empathy_gap
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Loewenstein, G. (1996). Out of control: Visceral influences on behavior. *Organizational Behavior and Human Decision Processes*, 65(3), 272–292. https://doi.org/10.1006/obhd.1996.0028

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
