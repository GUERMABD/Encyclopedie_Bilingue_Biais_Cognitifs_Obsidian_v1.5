---
type: effet-clinique-contextuel
nom_fr: Effet placebo
nom_en: Placebo effect
statut_fr: article français contrôlé le 2026-08-01
traduction: terme français attesté
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Manque de sens
aliases: []
nature_scientifique: effet psychophysiologique et contextuel de soin
robustesse: réel mais variable selon les résultats et le contexte
url_fr_verifiee: https://fr.wikipedia.org/wiki/Effet_placebo
---
# Effet placebo

> **English:** Placebo effect

## Définition — français

Modification d’un résultat clinique liée au contexte thérapeutique, aux attentes, au conditionnement ou à la relation de soin, indépendamment de l’action spécifique du traitement étudié.

## Definition — English

A change in a clinical outcome related to treatment context, expectations, conditioning, or the care relationship, independently of the treatment's specific action.

## Exemple

Une personne rapporte une diminution de douleur après une intervention inerte présentée dans un contexte thérapeutique crédible.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attentes, apprentissage, conditionnement et contexte relationnel peuvent modifier surtout certains résultats subjectifs.

## Mécanisme probable

Attentes, apprentissage, conditionnement et contexte relationnel peuvent modifier surtout certains résultats subjectifs.

## Analyse critique

Il ne s’agit pas d’un biais cognitif au sens strict. Les comparaisons placebo–absence de traitement ne montrent pas un effet clinique important et général. Des effets modestes et variables apparaissent surtout pour certains résultats rapportés par les patients, notamment la douleur et la nausée ; amélioration spontanée, régression vers la moyenne et biais de déclaration doivent être distingués de l’effet placebo.

**Conclusion de l’audit :** effet contextuel réel, mais portée générale souvent exagérée.

## Comment le limiter ou l’étudier correctement ?

Comparer placebo, absence de traitement et traitement actif ; privilégier les mesures objectives lorsque cela est possible et contrôler l’évolution naturelle.

## Classement

- Nature scientifique : effet psychophysiologique et contextuel de soin
- Tâche(s) du classement Wikipédia : non repris dans la liste anglaise contrôlée
- Sous-catégorie(s) (« flavors ») : non applicable
- Codex : Manque de sens
- Statut français : article français contrôlé le 2026-08-01

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Placebo
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Effet_placebo

## Références scientifiques contrôlées

- Hróbjartsson, A., & Gøtzsche, P. C. (2010). Placebo interventions for all clinical conditions. *Cochrane Database of Systematic Reviews*, (1), CD003974. https://doi.org/10.1002/14651858.CD003974.pub3

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
