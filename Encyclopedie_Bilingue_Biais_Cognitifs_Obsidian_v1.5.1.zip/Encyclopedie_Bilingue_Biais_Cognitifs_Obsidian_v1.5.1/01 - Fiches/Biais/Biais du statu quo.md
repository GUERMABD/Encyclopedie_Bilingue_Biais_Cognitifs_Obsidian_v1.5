---
type: biais-de-decision
nom_fr: Biais du statu quo
nom_en: Status quo bias
statut_fr: article français contrôlé le 2026-08-01
traduction: terme français attesté
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: préférence excessive pour l’option existante ou présélectionnée
robustesse: effet établi, mais mécanismes et amplitude variables selon les coûts et le contexte
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Inertia
codex:
- Nécessité d'agir rapidement
aliases: []
url_fr_verifiee: https://fr.wikipedia.org/wiki/Biais_du_statu_quo
---
# Biais du statu quo

> **English:** Status quo bias

## Définition — français

Préférence disproportionnée pour la situation existante, même lorsque des alternatives sont disponibles.

## Definition — English

A disproportionate preference for the existing state of affairs when alternatives are available.

## Exemple

Une personne conserve pendant des années un abonnement devenu trop cher et mal adapté, uniquement parce qu’il est déjà en place.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Coûts perçus du changement, aversion aux pertes, inertie et effet de défaut.

## Mécanisme probable

Coûts perçus du changement, aversion aux pertes, inertie et effet de défaut.

## Analyse critique

La préférence pour l’existant est documentée, mais elle n’est pas nécessairement irrationnelle : coûts de transition, apprentissage, incertitude et valeur de l’option peuvent la justifier. Le biais apparaît lorsque l’option actuelle reçoit un avantage qui dépasse ces raisons objectives.

**Conclusion de l’audit :** effet de décision établi, dont la rationalité doit être évaluée au cas par cas.

## Comment le limiter ?

Comparer l'existant comme s'il s'agissait d'une option nouvelle et chiffrer les coûts de maintien comme ceux du changement.

## Classement

- Nature scientifique : préférence excessive pour l’option existante ou présélectionnée
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Nécessité d'agir rapidement
- Statut français : article français contrôlé le 2026-08-01

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Status_quo_bias
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Biais_du_statu_quo

## Références scientifiques contrôlées

- Samuelson, W., & Zeckhauser, R. (1988). Status quo bias in decision making. *Journal of Risk and Uncertainty*, 1, 7–59. https://doi.org/10.1007/BF00055564

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
