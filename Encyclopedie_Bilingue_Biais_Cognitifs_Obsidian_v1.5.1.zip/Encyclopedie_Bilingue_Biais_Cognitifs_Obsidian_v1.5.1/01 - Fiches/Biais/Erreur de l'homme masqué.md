---
type: sophisme-logique
nom_fr: Erreur de l'homme masqué
nom_en: Masked–man fallacy
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Manque de sens
aliases: []
nature_scientifique: sophisme intensionnel fondé sur la substitution invalide d’identiques dans un contexte de croyance
robustesse: problème classique de logique et de philosophie du langage, non biais expérimental autonome
---
# Erreur de l'homme masqué

> **English:** Masked–man fallacy

## Définition — français

Erreur consistant à supposer que deux descriptions d’une même personne peuvent être substituées dans un énoncé de connaissance ou de croyance.

## Definition — English

A fallacy that substitutes co-referential descriptions inside a belief or knowledge statement as if the context were extensional.

## Exemple

Je sais qui est mon père; je ne sais pas qui est l’homme masqué; donc l’homme masqué n’est pas mon père.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Confusion entre identité réelle et manière dont un sujet représente l’identité.

## Mécanisme probable

Confusion entre identité réelle et manière dont un sujet représente l’identité.

## Analyse critique

Le problème concerne la logique des contextes intensionnels; il ne mesure pas une faiblesse psychologique universelle.

**Conclusion de l’audit :** problème classique de logique et de philosophie du langage, non biais expérimental autonome.

## Comment le limiter ?

Séparer ce qui est vrai dans le monde de ce que l’agent sait sous chaque description.

## Classement

- Nature scientifique : sophisme intensionnel fondé sur la substitution invalide d’identiques dans un contexte de croyance
- Tâche(s) du classement Wikipédia : non repris dans la liste anglaise contrôlée
- Sous-catégorie(s) (« flavors ») : non applicable
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Masked-man_fallacy
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kripke, S. A. (1980). *Naming and Necessity*. Harvard University Press.

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
