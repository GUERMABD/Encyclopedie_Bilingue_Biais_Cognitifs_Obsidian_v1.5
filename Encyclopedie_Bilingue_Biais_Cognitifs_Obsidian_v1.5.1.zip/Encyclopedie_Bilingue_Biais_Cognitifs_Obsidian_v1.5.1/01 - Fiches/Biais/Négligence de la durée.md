---
type: biais-cognitif
nom_fr: Négligence de la durée
nom_en: Duration neglect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais d’évaluation rétrospective des expériences
robustesse: forte négligence moyenne de la durée dans les évaluations rétrospectives; hétérogénéité selon les tâches
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Négligence de la durée

> **English:** Duration neglect

## Définition — français

Poids insuffisant accordé à la durée d’une expérience dans son évaluation globale rétrospective.

## Definition — English

Underweighting the duration of an experience in its retrospective overall evaluation.

## Exemple

Deux épisodes douloureux de durées différentes reçoivent des évaluations proches lorsque leurs moments marquants sont similaires.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Résumé de l’expérience par quelques moments saillants plutôt que par intégration temporelle complète.

## Mécanisme probable

Résumé de l’expérience par quelques moments saillants plutôt que par intégration temporelle complète.

## Analyse critique

La méta-analyse corrigée trouve un effet moyen de la durée proche de zéro, compatible avec une forte négligence de la durée. Ce résultat reste hétérogène selon les tâches et ne signifie pas que la durée est toujours ignorée individuellement.

**Conclusion de l’audit :** forte négligence moyenne de la durée dans les évaluations rétrospectives; hétérogénéité selon les tâches.

## Comment le limiter ?

Mesurer séparément intensité, durée, fréquence et conséquences.

## Classement

- Nature scientifique : biais d’évaluation rétrospective des expériences
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Duration_neglect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Alaybek, B., Dalal, R. S., Fyffe, S., Aitken, J. A., Zhou, Y., Qu, X., Roman, A., & Baines, J. I. (2022). All’s well that ends (and peaks) well? A meta-analysis of the peak-end rule and duration neglect. *Organizational Behavior and Human Decision Processes*, 170, 104149. https://doi.org/10.1016/j.obhdp.2022.104149
- Alaybek, B., Dalal, R. S., Fyffe, S., Aitken, J. A., Zhou, Y., Qu, X., Roman, A., & Baines, J. I. (2024). Corrigendum to “All’s well that ends (and peaks) well? A meta-analysis of the peak-end rule and duration neglect”. *Organizational Behavior and Human Decision Processes*, 180, 104278. https://doi.org/10.1016/j.obhdp.2023.104278

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
