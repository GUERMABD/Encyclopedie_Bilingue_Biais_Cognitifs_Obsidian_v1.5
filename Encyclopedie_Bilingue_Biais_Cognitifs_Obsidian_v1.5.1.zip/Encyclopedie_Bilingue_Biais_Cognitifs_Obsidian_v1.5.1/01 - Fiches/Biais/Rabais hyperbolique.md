---
type: biais-cognitif
nom_fr: Rabais hyperbolique
nom_en: Hyperbolic discounting
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: modèle d’actualisation intertemporelle non exponentielle
robustesse: modèle influent soutenu par de nombreux comportements; forme exacte variable
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Rabais hyperbolique

> **English:** Hyperbolic discounting

## Définition — français

Dépréciation des récompenses futures plus forte à court terme qu’à long terme, pouvant produire des renversements de préférence.

## Definition — English

A steeper discounting of future rewards at short delays than at long delays, which can produce preference reversals.

## Exemple

Une personne préfère 10 € aujourd’hui à 12 € demain, mais 12 € dans 31 jours à 10 € dans 30 jours.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Sensibilité décroissante au délai et conflit entre soi présents et futurs.

## Mécanisme probable

Sensibilité décroissante au délai et conflit entre soi présents et futurs.

## Analyse critique

Le rabais hyperbolique est un modèle, pas un biais unique directement observé dans chaque choix. Le risque, la liquidité et la confiance influencent aussi les préférences.

**Conclusion de l’audit :** modèle influent soutenu par de nombreux comportements; forme exacte variable.

## Comment le limiter ?

Utiliser des engagements préalables et comparer les choix à délais équivalents.

## Classement

- Nature scientifique : modèle d’actualisation intertemporelle non exponentielle
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Hyperbolic_discounting
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Ainslie, G. (1975). Specious reward: A behavioral theory of impulsiveness and impulse control. *Psychological Bulletin*, 82(4), 463–496. https://doi.org/10.1037/h0076860

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
