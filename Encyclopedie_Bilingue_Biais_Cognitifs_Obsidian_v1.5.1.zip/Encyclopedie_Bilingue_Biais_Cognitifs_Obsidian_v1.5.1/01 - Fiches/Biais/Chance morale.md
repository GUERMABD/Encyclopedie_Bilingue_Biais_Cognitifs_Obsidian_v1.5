---
type: biais-cognitif
nom_fr: Chance morale
nom_en: Moral luck
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
nature_scientifique: problème de philosophie morale
robustesse: concept philosophique majeur; ce n’est pas un biais cognitif expérimental
---
# Chance morale

> **English:** Moral luck

## Définition — français

Situation où l’évaluation morale d’un agent dépend en partie de facteurs hors de son contrôle.

## Definition — English

A situation in which moral evaluation of an agent depends partly on factors beyond that agent’s control.

## Exemple

Deux conducteurs sont également négligents; seul celui devant lequel un piéton surgit cause un décès et reçoit un blâme beaucoup plus fort.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Tension entre principe de contrôle, résultats réels et responsabilité.

## Mécanisme probable

Tension entre principe de contrôle, résultats réels et responsabilité.

## Analyse critique

La chance morale est un problème normatif, non une erreur psychologique démontrée. Les philosophes contestent si l’écart de jugement est injustifié ou constitutif de la responsabilité.

**Conclusion de l’audit :** concept philosophique majeur; ce n’est pas un biais cognitif expérimental.

## Comment le limiter ?

Séparer intention, degré de négligence, risque imposé, résultat et responsabilité réparatrice.

## Classement

- Nature scientifique : problème de philosophie morale
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Moral_luck
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Williams, B. A. O., & Nagel, T. (1976). Moral luck. *Aristotelian Society Supplementary Volume*, 50(1), 115–152. https://doi.org/10.1093/aristoteliansupp/50.1.115

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
