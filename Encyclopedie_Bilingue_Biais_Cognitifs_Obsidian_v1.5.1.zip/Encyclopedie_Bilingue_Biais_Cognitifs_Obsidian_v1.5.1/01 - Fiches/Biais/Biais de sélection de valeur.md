---
type: biais-cognitif
nom_fr: Biais de sélection de valeur
nom_en: Value selection bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: biais d’échantillonnage mental dans l’évaluation multi-attributs
robustesse: concept expérimental récent; soutien initial, réplications indépendantes limitées
---
# Biais de sélection de valeur

> **English:** Value selection bias

## Définition — français

Tendance à considérer surtout les valeurs ou attributs qui différencient les options, en négligeant ceux qui sont partagés.

## Definition — English

The tendency to focus on values or attributes that differentiate options while neglecting those they share.

## Exemple

Deux emplois sont comparés sur le salaire différent, tandis que des avantages importants identiques disparaissent du jugement.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Sélection attentionnelle des attributs diagnostiques ou contrastifs.

## Mécanisme probable

Sélection attentionnelle des attributs diagnostiques ou contrastifs.

## Analyse critique

L’effet est distinct du simple choix rationnel d’attributs pertinents seulement si les valeurs communes devraient influencer l’utilité totale. La littérature est encore récente.

**Conclusion de l’audit :** concept expérimental récent; soutien initial, réplications indépendantes limitées.

## Comment le limiter ?

Établir la liste complète des valeurs avant la comparaison et calculer séparément contributions communes et différences.

## Classement

- Nature scientifique : biais d’échantillonnage mental dans l’évaluation multi-attributs
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Value_selection_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Talboy, A., & Schneider, S. (2022). Reference Dependence in Bayesian Reasoning: Value Selection Bias, Congruence Effects, and Response Prompt Sensitivity. *Frontiers in Psychology*, 13, 729285. https://doi.org/10.3389/fpsyg.2022.729285

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
