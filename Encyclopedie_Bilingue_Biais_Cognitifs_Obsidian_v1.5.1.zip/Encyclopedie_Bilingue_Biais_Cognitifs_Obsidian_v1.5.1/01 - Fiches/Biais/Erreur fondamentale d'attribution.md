---
type: biais-d-attribution
nom_fr: Erreur fondamentale d'attribution
nom_en: Fundamental attribution error
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: tendance à privilégier des explications dispositionnelles du comportement d’autrui au détriment
  du contexte
robustesse: phénomène documenté dans plusieurs paradigmes, mais amplitude et interprétation fortement culturelles
  et situationnelles
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Erreur fondamentale d'attribution

> **English:** Fundamental attribution error

## Définition — français

Tendance à surestimer les causes personnelles du comportement d'autrui et à sous-estimer le contexte situationnel.

## Definition — English

The tendency to overemphasize personal causes of others' behavior and underweight situational causes.

## Exemple

Qualifier un collègue de négligent sans examiner la charge de travail, les consignes ou les outils disponibles.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Saillance de l'acteur, accès limité aux contraintes de situation et explications dispositionnelles rapides.

## Mécanisme probable

Saillance de l'acteur, accès limité aux contraintes de situation et explications dispositionnelles rapides.

## Analyse critique

La tendance à sous-pondérer le contexte est observée dans plusieurs paradigmes, mais l’expression « fondamentale » exagère son universalité. Les explications dispositionnelles et situationnelles varient selon la culture, les informations disponibles, la saillance et la perspective de l’observateur.

**Conclusion de l’audit :** biais d’attribution documenté, mais non universel ni invariant.

## Comment le limiter ?

Lister au moins trois explications situationnelles avant de conclure sur la personnalité.

## Classement

- Nature scientifique : tendance à privilégier des explications dispositionnelles du comportement d’autrui au détriment du contexte
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Fundamental_attribution_error
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Choi, I., Nisbett, R. E., & Norenzayan, A. (1999). Causal attribution across cultures: Variation and universality. *Psychological Bulletin*, 125(1), 47–63. https://doi.org/10.1037/0033-2909.125.1.47

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
