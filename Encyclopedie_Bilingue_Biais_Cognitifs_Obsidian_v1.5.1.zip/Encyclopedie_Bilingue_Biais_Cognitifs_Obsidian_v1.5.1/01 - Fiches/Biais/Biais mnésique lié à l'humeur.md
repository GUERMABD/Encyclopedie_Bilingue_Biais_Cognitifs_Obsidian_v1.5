---
type: biais-cognitif
nom_fr: Biais mnésique lié à l'humeur
nom_en: Mood-congruent memory bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet de congruence entre humeur et récupération mnésique
robustesse: documenté mais hétérogène selon les tâches et populations
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Trop d'informations
aliases:
- Mood–congruent memory bias
---
# Biais mnésique lié à l'humeur

> **English:** Mood-congruent memory bias

## Définition — français

Facilité accrue à récupérer des informations dont la tonalité émotionnelle correspond à l’humeur actuelle.

## Definition — English

Improved retrieval of information whose emotional tone matches the current mood.

## Exemple

Dans une humeur triste, des souvenirs négatifs peuvent devenir plus accessibles que des souvenirs neutres ou positifs.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : L’humeur sert de contexte de récupération et oriente l’attention vers les contenus congruents.

## Mécanisme probable

L’humeur sert de contexte de récupération et oriente l’attention vers les contenus congruents.

## Analyse critique

L’effet n’est ni automatique ni de même taille pour tous les types de mémoire. Il doit être distingué de la mémoire dépendante de l’état, qui concerne la concordance entre états d’encodage et de rappel.

**Conclusion de l’audit :** documenté mais hétérogène selon les tâches et populations.

## Comment le limiter ?

Reporter les décisions importantes lorsque l’humeur est extrême et consulter des traces écrites.

## Classement

- Nature scientifique : effet de congruence entre humeur et récupération mnésique
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Mood_congruence
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Faul, L., & LaBar, K. S. (2023). Mood-congruent memory revisited. *Psychological Review*, 130(6), 1421–1456. https://doi.org/10.1037/rev0000394

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
