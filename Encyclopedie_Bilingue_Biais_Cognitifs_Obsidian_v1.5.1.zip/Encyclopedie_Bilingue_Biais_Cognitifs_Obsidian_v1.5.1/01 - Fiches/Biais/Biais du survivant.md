---
type: erreur-de-selection
nom_fr: Biais du survivant
nom_en: Survivorship bias
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: erreur d’inférence produite par l’observation des seuls cas ayant franchi un processus de sélection
robustesse: mécanisme statistique certain ; manifestations empiriques dépendantes du domaine étudié
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
---
# Biais du survivant

> **English:** Survivorship bias

## Définition — français

Erreur consistant à analyser seulement les personnes ou objets ayant franchi une sélection, en oubliant ceux qui ont disparu ou échoué.

## Definition — English

The error of focusing on cases that passed a selection process while overlooking those that failed or disappeared.

## Exemple

Étudier uniquement les entreprises encore actives pour déduire les recettes du succès entrepreneurial.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Échantillon tronqué et invisibilité des échecs.

## Mécanisme probable

Échantillon tronqué et invisibilité des échecs.

## Analyse critique

Le mécanisme est une erreur de sélection : les cas disparus, échoués ou non observables sont absents de l’échantillon analysé. Il peut résulter d’un raisonnement humain, mais relève d’abord de la méthodologie statistique et de la définition de la population observée.

**Conclusion de l’audit :** erreur de sélection valide, et non biais cognitif autonome dans tous les usages.

## Comment le limiter ?

Définir la population de départ et rechercher explicitement les cas absents, abandonnés ou non publiés.

## Classement

- Nature scientifique : erreur d’inférence produite par l’observation des seuls cas ayant franchi un processus de sélection
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Survivorship_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Carpenter, J. N., & Lynch, A. W. (1999). Survivorship bias and attrition effects in measures of performance persistence. *Journal of Financial Economics*, 54(3), 337–374. https://doi.org/10.1016/S0304-405X(99)00040-9

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
