---
type: etiquette-informelle
nom_fr: Réflexe de Semmelweis
nom_en: Semmelweis reflex
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Inertia
codex:
- Trop d'informations
aliases: []
nature_scientifique: étiquette décrivant le rejet prématuré d’une idée contraire aux croyances établies
robustesse: expression historique et clinique discutée, sans mesure psychométrique standard ni effet autonome clairement isolé
---
# Réflexe de Semmelweis

> **English:** Semmelweis reflex

## Définition — français

Rejet presque réflexe d’une information nouvelle parce qu’elle contredit des pratiques ou croyances installées.

## Definition — English

Near-reflexive rejection of new information because it conflicts with established beliefs or practices.

## Exemple

Une procédure efficace est écartée sans examen uniquement parce qu’elle remet en cause la pratique dominante.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Persévérance des croyances, identité professionnelle, coûts de changement et aversion à l’incertitude.

## Mécanisme probable

Persévérance des croyances, identité professionnelle, coûts de changement et aversion à l’incertitude.

## Analyse critique

L’histoire de Semmelweis ne permet pas de qualifier toute critique d’idée nouvelle d’irrationnelle. La prudence scientifique peut être légitime.

**Conclusion de l’audit :** expression historique et clinique discutée, sans mesure psychométrique standard ni effet autonome clairement isolé.

## Comment le limiter ?

Évaluer la méthode et les données indépendamment de leur nouveauté, puis organiser une réplication ou un essai contrôlé.

## Classement

- Nature scientifique : étiquette décrivant le rejet prématuré d’une idée contraire aux croyances établies
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Semmelweis_reflex
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Gupta, V. K., Saini, C., Oberoi, M., Kalra, G., & Nasir, M. I. (2020). Semmelweis reflex: An age-old prejudice. *World Neurosurgery*, 136, e119–e125. https://doi.org/10.1016/j.wneu.2019.12.012

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
