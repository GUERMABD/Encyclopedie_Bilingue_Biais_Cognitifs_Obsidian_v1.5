---
type: biais-cognitif
nom_fr: Croyance en un monde juste
nom_en: Just–world hypothesis
statut_fr: article français contrôlé le 2026-08-01
traduction: terme français attesté
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases:
- Just-world fallacy
url_fr_verifiee: https://fr.wikipedia.org/wiki/Croyance_en_un_monde_juste
nature_scientifique: croyance sociale et schéma d’attribution
robustesse: concept établi, interprétation normative à manier avec prudence
---
# Croyance en un monde juste

> **English:** Just–world hypothesis

## Définition — français

Croyance selon laquelle les personnes reçoivent généralement les conséquences qu’elles méritent, et méritent les conséquences qu’elles reçoivent.

## Definition — English

The belief that people generally get outcomes they deserve and deserve the outcomes they get.

## Exemple

Face à une victime, un observateur suppose qu’elle a nécessairement commis une faute afin de rendre l’événement compatible avec l’idée d’un monde ordonné.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Besoin de prévisibilité et de cohérence morale, pouvant conduire à réinterpréter la victime ou les circonstances.

## Mécanisme probable

Besoin de prévisibilité et de cohérence morale, pouvant conduire à réinterpréter la victime ou les circonstances.

## Analyse critique

Il s’agit d’abord d’un construit de croyance, pas d’une erreur logique unique. Il peut être associé au blâme des victimes, mais ses effets varient selon la distinction entre monde juste pour soi et pour autrui.

**Conclusion de l’audit :** concept établi, interprétation normative à manier avec prudence.

## Comment le limiter ?

Séparer le jugement moral des faits causaux, rechercher les contraintes subies par la personne et éviter d’inférer la responsabilité à partir du seul résultat.

## Classement

- Nature scientifique : croyance sociale et schéma d’attribution
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : article français contrôlé le 2026-08-01

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Just-world_hypothesis
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Croyance_en_un_monde_juste

## Références scientifiques contrôlées

- Lerner, M. J., & Miller, D. T. (1978). Just world research and the attribution process: Looking back and ahead. *Psychological Bulletin*, 85(5), 1030–1051. https://doi.org/10.1037/0033-2909.85.5.1030

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
