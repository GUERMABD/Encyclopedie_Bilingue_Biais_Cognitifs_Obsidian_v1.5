---
type: biais-cognitif
nom_fr: Biais de proportionnalité
nom_en: Proportionality bias
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: heuristique causale
robustesse: soutien expérimental limité mais cohérent dans certains raisonnements de conspiration; pas une tendance universelle
---
# Biais de proportionnalité

> **English:** Proportionality bias

## Définition — français

Tendance à supposer qu’un événement important doit avoir une cause d’importance comparable.

## Definition — English

The tendency to assume that a major event must have a correspondingly major cause.

## Exemple

Un accident historique majeur paraît incompatible avec une chaîne de petites erreurs ordinaires.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Recherche de correspondance entre ampleur de l’effet et ampleur intuitive de la cause.

## Mécanisme probable

Recherche de correspondance entre ampleur de l’effet et ampleur intuitive de la cause.

## Analyse critique

Les grands événements ont parfois de grandes causes. Le biais apparaît lorsque la proportion remplace l’examen des mécanismes, probabilités et interactions cumulatives.

**Conclusion de l’audit :** soutien expérimental limité mais cohérent dans certains raisonnements de conspiration; pas une tendance universelle.

## Comment le limiter ?

Reconstruire la chaîne causale et comparer les hypothèses selon leurs preuves plutôt que selon leur grandeur apparente.

## Classement

- Nature scientifique : heuristique causale
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Proportionality_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Leman, P. J., & Cinnirella, M. (2007). A major event has a major cause: Evidence for the role of heuristics in reasoning about conspiracy theories. *Social Psychological Review*, 9(2), 18–28.

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
