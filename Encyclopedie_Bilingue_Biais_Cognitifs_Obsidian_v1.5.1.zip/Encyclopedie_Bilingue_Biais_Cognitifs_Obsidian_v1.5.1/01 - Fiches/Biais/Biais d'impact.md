---
type: biais-cognitif
nom_fr: Biais d'impact
nom_en: Impact bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de prévision affective
robustesse: bien documenté en moyenne; magnitude et direction modulées par adaptation, attention et expérience
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
---
# Biais d'impact

> **English:** Impact bias

## Définition — français

Tendance à surestimer l’intensité ou surtout la durée de l’effet émotionnel futur d’un événement.

## Definition — English

The tendency to overestimate the intensity or especially the duration of a future event’s emotional impact.

## Exemple

Une personne pense qu’un échec affectera son bonheur beaucoup plus longtemps qu’il ne le fera ensuite.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Focalisation sur l’événement et sous-estimation de l’adaptation, des événements concurrents et des ressources psychologiques.

## Mécanisme probable

Focalisation sur l’événement et sous-estimation de l’adaptation, des événements concurrents et des ressources psychologiques.

## Analyse critique

Les événements n’ont pas tous un faible impact; certains changements durables affectent réellement le bien-être. Le biais est un écart de prévision moyen, non une promesse d’adaptation complète.

**Conclusion de l’audit :** bien documenté en moyenne; magnitude et direction modulées par adaptation, attention et expérience.

## Comment le limiter ?

Comparer avec des expériences passées et des personnes ayant vécu l’événement, en distinguant intensité et durée.

## Classement

- Nature scientifique : biais de prévision affective
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Impact_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Gilbert, D. T., Pinel, E. C., Wilson, T. D., Blumberg, S. J., & Wheatley, T. P. (1998). Immune neglect: A source of durability bias in affective forecasting. *Journal of Personality and Social Psychology*, 75(3), 617–638. https://doi.org/10.1037/0022-3514.75.3.617

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
