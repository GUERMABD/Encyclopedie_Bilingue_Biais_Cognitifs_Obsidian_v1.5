---
type: biais-organisationnel
nom_fr: Substitution de l'indicateur à l'objectif
nom_en: Surrogation
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: confusion progressive entre un indicateur de performance et l’objectif stratégique qu’il représente
robustesse: effet documenté en comptabilité de gestion et pilotage, mais dépendant du système d’incitation et du contexte
---
# Substitution de l'indicateur à l'objectif

> **English:** Surrogation

## Définition — français

Tendance à traiter une mesure comme l’objectif lui-même et à optimiser la mesure au détriment du résultat recherché.

## Definition — English

The tendency to treat a performance measure as the goal itself and optimize the measure at the expense of the intended outcome.

## Exemple

Une équipe maximise le nombre de dossiers fermés tout en diminuant la résolution réelle des problèmes.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attention sélective, incitations et simplification de la stratégie en métrique.

## Mécanisme probable

Attention sélective, incitations et simplification de la stratégie en métrique.

## Analyse critique

L’usage d’indicateurs est nécessaire; le problème apparaît lorsque leur lien avec l’objectif n’est plus contrôlé.

**Conclusion de l’audit :** effet documenté en comptabilité de gestion et pilotage, mais dépendant du système d’incitation et du contexte.

## Comment le limiter ?

Employer plusieurs indicateurs, auditer les effets pervers et réexaminer régulièrement la chaîne objectif–mesure.

## Classement

- Nature scientifique : confusion progressive entre un indicateur de performance et l’objectif stratégique qu’il représente
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Surrogation
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Choi, J. W., Hecht, G. W., & Tayler, W. B. (2012). Lost in translation: The effects of incentive compensation on strategy surrogation. *The Accounting Review*, 87(4), 1135–1163. https://doi.org/10.2308/accr-10273

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
