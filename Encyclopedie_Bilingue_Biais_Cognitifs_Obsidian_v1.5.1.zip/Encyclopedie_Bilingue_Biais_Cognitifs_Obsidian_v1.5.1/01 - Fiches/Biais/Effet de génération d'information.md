---
type: biais-cognitif
nom_fr: Effet de génération d'information
nom_en: Generation effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: avantage mnésique de la génération active
robustesse: effet moyen robuste avec conditions limites
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Effet de génération d'information

> **English:** Generation effect

## Définition — français

Meilleure mémorisation d’une information produite activement que de la même information simplement lue.

## Definition — English

Better memory for information actively generated than for the same information merely read.

## Exemple

Un étudiant complète lui-même les mots manquants d’un résumé ; lors du contrôle, il les rappelle mieux que ceux simplement relus.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Traitement actif, distinctivité et liens supplémentaires avec les indices.

## Mécanisme probable

Traitement actif, distinctivité et liens supplémentaires avec les indices.

## Analyse critique

Le bénéfice dépend de la réussite de la génération et du type de matériel. Une réponse erronée non corrigée peut être contre-productive.

**Conclusion de l’audit :** effet moyen robuste avec conditions limites.

## Comment le limiter ?

Faire produire la réponse, puis fournir immédiatement une correction fiable.

## Classement

- Nature scientifique : avantage mnésique de la génération active
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Generation_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Bertsch, S., Pesta, B. J., Wiscott, R., & McDaniel, M. A. (2007). The generation effect: A meta-analytic review. *Memory & Cognition*, 35, 201–210. https://doi.org/10.3758/BF03193441

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
