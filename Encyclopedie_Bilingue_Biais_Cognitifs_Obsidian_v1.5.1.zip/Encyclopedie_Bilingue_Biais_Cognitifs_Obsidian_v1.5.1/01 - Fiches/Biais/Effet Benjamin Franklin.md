---
type: biais-cognitif
nom_fr: Effet Benjamin Franklin
nom_en: Ben Franklin effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Self-perspective
codex: []
aliases: []
nature_scientifique: effet d’attitude après avoir rendu un service
robustesse: étude classique et prolongements, mais conditions et mécanismes moins généraux que le récit populaire
---
# Effet Benjamin Franklin

> **English:** Ben Franklin effect

## Définition — français

Possibilité d’apprécier davantage une personne après lui avoir rendu un service, surtout lorsque le geste paraît librement choisi.

## Definition — English

The possibility of liking someone more after doing them a favor, especially when the act seems freely chosen.

## Exemple

Après avoir accepté une petite demande personnelle, une personne évalue plus favorablement le demandeur.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Réduction de dissonance, auto-perception ou signal affiliatif de la demande.

## Mécanisme probable

Réduction de dissonance, auto-perception ou signal affiliatif de la demande.

## Analyse critique

L’effet n’implique pas que demander des faveurs améliore toujours une relation; une demande coûteuse, forcée ou manipulatrice peut produire l’inverse.

**Conclusion de l’audit :** étude classique et prolongements, mais conditions et mécanismes moins généraux que le récit populaire.

## Comment le limiter ?

Employer seulement des demandes modestes et légitimes, laisser un refus réel et ne pas utiliser l’effet comme technique de manipulation.

## Classement

- Nature scientifique : effet d’attitude après avoir rendu un service
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Ben_Franklin_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Jecker, J., & Landy, D. (1969). Liking a person as a function of doing him a favour. *Human Relations*, 22(4), 371–378. https://doi.org/10.1177/001872676902200407

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
