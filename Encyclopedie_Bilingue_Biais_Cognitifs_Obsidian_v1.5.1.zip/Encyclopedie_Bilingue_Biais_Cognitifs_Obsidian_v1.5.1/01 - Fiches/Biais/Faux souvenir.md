---
type: biais-cognitif
nom_fr: Faux souvenir
nom_en: False memory
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: catégorie de distorsions mnésiques
robustesse: existence bien établie; méthodes et taux de production très variables
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Faux souvenir

> **English:** False memory

## Définition — français

Souvenir d’un événement ou d’un détail qui ne s’est pas produit comme il est rappelé.

## Definition — English

A memory for an event or detail that did not occur as remembered.

## Exemple

Après qu’un témoin lui a suggéré la présence d’un sac rouge, une personne affirme ensuite l’avoir vu elle-même, avec assurance.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Reconstruction, associations, suggestion et erreurs de source.

## Mécanisme probable

Reconstruction, associations, suggestion et erreurs de source.

## Analyse critique

La confiance ne garantit pas l’exactitude, mais l’existence de faux souvenirs ne rend pas tous les témoignages faux. Les résultats dépendent fortement des méthodes.

**Conclusion de l’audit :** existence bien établie; méthodes et taux de production très variables.

## Comment le limiter ?

Éviter les questions suggestives, recueillir tôt le récit libre et rechercher des corroborations indépendantes.

## Classement

- Nature scientifique : catégorie de distorsions mnésiques
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/False_memory
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Scoboria, A., Wade, K. A., Lindsay, D. S., Azad, T., Strange, D., Ost, J., & Hyman, I. E. (2017). A mega-analysis of memory reports from eight peer-reviewed false memory implantation studies. *Memory*, 25(2), 146–163. https://doi.org/10.1080/09658211.2016.1260747

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
