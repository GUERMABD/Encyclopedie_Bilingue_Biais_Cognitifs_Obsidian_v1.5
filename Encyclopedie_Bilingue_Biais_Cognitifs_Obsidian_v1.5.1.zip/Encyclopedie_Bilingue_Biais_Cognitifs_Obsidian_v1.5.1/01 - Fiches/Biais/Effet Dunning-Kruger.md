---
type: effet-metacognitif-conteste
nom_fr: Effet Dunning-Kruger
nom_en: Dunning–Kruger effect
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: relation proposée entre niveau de compétence et précision de l’autoévaluation
robustesse: résultats mixtes ; une partie du profil classique peut être statistique et l’effet résiduel paraît faible
  ou contextuel
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Baseline
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Effet Dunning-Kruger

> **English:** Dunning–Kruger effect

## Définition — français

Relation possible entre faible compétence et mauvaise capacité à évaluer cette compétence, pouvant conduire à une surestimation.

## Definition — English

A possible link between low skill and poor ability to assess that skill, which can produce overestimation.

## Exemple

Un débutant ignore les critères permettant de reconnaître ses propres erreurs et se juge donc meilleur qu'il ne l'est.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Les compétences nécessaires pour réussir peuvent recouper celles nécessaires pour s'autoévaluer.

## Mécanisme probable

Les compétences nécessaires pour réussir peuvent recouper celles nécessaires pour s'autoévaluer.

## Analyse critique

La caricature selon laquelle les personnes les moins compétentes se croiraient systématiquement expertes n’est pas soutenue comme loi générale. Les courbes classiques combinent mauvaise calibration, régression vers la moyenne, bornes des échelles et regroupement par quartiles. Des analyses corrigées trouvent soit aucun effet spécifique, soit un effet résiduel faible selon les données et les méthodes.

**Conclusion de l’audit :** hypothèse métacognitive plausible dans certains domaines, mais effet populaire fortement exagéré et statut général contesté.

## Comment le limiter ?

Utiliser des critères objectifs, des tests étalonnés, des retours externes et suivre l'évolution plutôt qu'une autoévaluation isolée.

## Classement

- Nature scientifique : relation proposée entre niveau de compétence et précision de l’autoévaluation
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Nécessité d'agir rapidement
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Dunning–Kruger_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kruger, J., & Dunning, D. (1999). Unskilled and unaware of it: How difficulties in recognizing one’s own incompetence lead to inflated self-assessments. *Journal of Personality and Social Psychology*, 77(6), 1121–1134. https://doi.org/10.1037/0022-3514.77.6.1121
- Gignac, G. E., & Zajenkowski, M. (2020). The Dunning–Kruger effect is (mostly) a statistical artefact: Valid approaches to testing the hypothesis with individual differences data. *Intelligence*, 80, 101449. https://doi.org/10.1016/j.intell.2020.101449
- Dunkel, C. S., Nedelec, J., & van der Linden, D. (2023). Reevaluating the Dunning–Kruger effect: A response to and replication of Gignac and Zajenkowski (2020). *Intelligence*, 96, 101717. https://doi.org/10.1016/j.intell.2022.101717

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
