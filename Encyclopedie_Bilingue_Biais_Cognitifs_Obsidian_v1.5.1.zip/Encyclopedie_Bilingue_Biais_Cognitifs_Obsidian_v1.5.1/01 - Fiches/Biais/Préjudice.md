---
type: concept-psychosocial
nom_fr: Préjudice
nom_en: Prejudice
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Limites de la mémoire
aliases: []
nature_scientifique: attitude évaluative envers une personne fondée sur son appartenance de groupe
robustesse: champ de recherche vaste et robuste, mais concept multidimensionnel et non biais cognitif unique
---
# Préjudice

> **English:** Prejudice

## Définition — français

Évaluation négative ou parfois positive d’une personne en raison de son appartenance réelle ou supposée à un groupe.

## Definition — English

A negative or sometimes positive evaluation of a person based on actual or perceived group membership.

## Exemple

Écarter une candidature en raison de l’origine supposée plutôt que des compétences.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Catégorisation sociale, normes, menace, apprentissage et rapports de pouvoir.

## Mécanisme probable

Catégorisation sociale, normes, menace, apprentissage et rapports de pouvoir.

## Analyse critique

Le préjudice se distingue du stéréotype, qui est une croyance, et de la discrimination, qui est un comportement. Il n’existe pas une seule cause ni une seule mesure.

**Conclusion de l’audit :** champ de recherche vaste et robuste, mais concept multidimensionnel et non biais cognitif unique.

## Comment le limiter ?

Standardiser les critères, mesurer les décisions réelles et évaluer les interventions avec des groupes de comparaison.

## Classement

- Nature scientifique : attitude évaluative envers une personne fondée sur son appartenance de groupe
- Tâche(s) du classement Wikipédia : non repris dans la liste anglaise contrôlée
- Sous-catégorie(s) (« flavors ») : non applicable
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Prejudice
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Paluck, E. L., Porat, R., Clark, C. S., & Green, D. P. (2021). Prejudice reduction: Progress and challenges. *Annual Review of Psychology*, 72, 533–560. https://doi.org/10.1146/annurev-psych-071620-030619

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
