---
type: biais-cognitif
nom_fr: Effet de récence
nom_en: Recency effect
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: composante finale de l’effet de position sérielle
robustesse: robuste à court délai; sensible aux distracteurs
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Baseline
codex:
- Limites de la mémoire
aliases: []
---
# Effet de récence

> **English:** Recency effect

## Définition — français

Meilleur rappel des derniers éléments d’une séquence lors d’un rappel immédiat.

## Definition — English

Better recall of the last items in a sequence during immediate recall.

## Exemple

Les derniers mots d’une liste sont rappelés en premier juste après la présentation.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Accessibilité récente et maintien temporaire.

## Mécanisme probable

Accessibilité récente et maintien temporaire.

## Analyse critique

Un délai rempli par une tâche distractrice réduit souvent cet avantage. L’effet ne garantit pas une meilleure mémoire à long terme.

**Conclusion de l’audit :** robuste à court délai; sensible aux distracteurs.

## Comment le limiter ?

Récapituler l’ensemble après la séquence et tester à distance.

## Classement

- Nature scientifique : composante finale de l’effet de position sérielle
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Limites de la mémoire
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Serial-position_effect#Recency_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Murdock, B. B. (1962). The serial position effect of free recall. *Journal of Experimental Psychology*, 64(5), 482–488. https://doi.org/10.1037/h0045106

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
