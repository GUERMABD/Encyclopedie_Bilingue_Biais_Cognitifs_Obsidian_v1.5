---
type: effet-interpersonnel
nom_fr: Effet Pygmalion
nom_en: Pygmalion effect
statut_fr: article français contrôlé le 2026-08-01
traduction: terme français attesté
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex: []
aliases: []
nature_scientifique: effet d’attente interpersonnelle
robustesse: effet contextuel généralement faible à modéré
url_fr_verifiee: https://fr.wikipedia.org/wiki/Effet_Pygmalion
---
# Effet Pygmalion

> **English:** Pygmalion effect

## Définition — français

Influence possible des attentes d’une personne en position d’autorité sur ses comportements envers autrui et, indirectement, sur les performances de celui-ci.

## Definition — English

The possible influence of an authority figure's expectations on their behavior toward another person and, indirectly, on that person's performance.

## Exemple

Un enseignant qui attend de meilleurs résultats d’un élève peut lui donner davantage d’occasions, de retours et d’encouragements, ce qui contribue à son progrès.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Les attentes peuvent modifier la qualité des interactions, les occasions offertes, le feedback et le concept de soi de la personne ciblée.

## Mécanisme probable

Les attentes peuvent modifier la qualité des interactions, les occasions offertes, le feedback et le concept de soi de la personne ciblée.

## Analyse critique

Ce n’est pas un biais cognitif individuel unique, mais un effet interpersonnel et autoréalisateur. Les effets observés ne sont ni automatiques ni uniformes ; ils sont souvent faibles à modérés et dépendent du contexte, de la précision initiale des attentes et des comportements qui les transmettent.

**Conclusion de l’audit :** effet plausible et documenté, mais non automatique.

## Comment le limiter ou l’étudier correctement ?

Mesurer les performances initiales, masquer les hypothèses lorsque possible et distinguer attentes exactes, traitement différentiel et changement réel.

## Classement

- Nature scientifique : effet d’attente interpersonnelle
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : absent
- Statut français : article français contrôlé le 2026-08-01

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Pygmalion_effect
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Effet_Pygmalion

## Références scientifiques contrôlées

- Raudenbush, S. W. (1984). Magnitude of teacher expectancy effects on pupil IQ as a function of the credibility of expectancy induction: A synthesis of findings from 18 experiments. *Journal of Educational Psychology*, 76(1), 85–97. https://doi.org/10.1037/0022-0663.76.1.85
- Friedrich, A., Flunger, B., Nagengast, B., Jonkmann, K., & Trautwein, U. (2015). Pygmalion effects in the classroom: Teacher expectancy effects on students' math achievement. *Contemporary Educational Psychology*, 41, 1–12. https://doi.org/10.1016/j.cedpsych.2014.10.006

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
