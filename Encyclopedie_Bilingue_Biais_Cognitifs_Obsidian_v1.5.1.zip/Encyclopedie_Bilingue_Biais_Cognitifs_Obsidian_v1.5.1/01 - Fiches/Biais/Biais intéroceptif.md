---
type: biais-cognitif
nom_fr: Biais intéroceptif
nom_en: Interoceptive bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Baseline
codex: []
aliases: []
nature_scientifique: terme ambigu couvrant critère de réponse et influence des états corporels
robustesse: interoception étudiée, mais l’étiquette du corpus mélange des concepts distincts et l’exemple du juge affamé est contesté
---
# Biais intéroceptif

> **English:** Interoceptive bias

## Définition — français

Influence systématique des sensations ou états corporels sur la détection de signaux internes ou sur des jugements externes.

## Definition — English

Systematic influence of bodily sensations or states on detecting internal signals or making external judgments.

## Exemple

La faim modifie l’évaluation d’un aliment; cela ne prouve pas qu’elle modifie de la même manière toute décision sans rapport.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Signaux viscéraux, critère de réponse, attention au corps et attribution de l’état.

## Mécanisme probable

Signaux viscéraux, critère de réponse, attention au corps et attribution de l’état.

## Analyse critique

La littérature distingue précision, sensibilité déclarée et biais de réponse intéroceptif. Les présenter comme un seul biais conduit à des conclusions erronées.

**Conclusion de l’audit :** interoception étudiée, mais l’étiquette du corpus mélange des concepts distincts et l’exemple du juge affamé est contesté.

## Comment le limiter ?

Mesurer séparément exactitude, confiance et critère de réponse; contrôler l’état corporel dans les décisions sensibles.

## Classement

- Nature scientifique : terme ambigu couvrant critère de réponse et influence des états corporels
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Interoceptive_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Petersen, S., Van Staeyen, K., Vögele, C., von Leupoldt, A., & Van den Bergh, O. (2015). Interoception and symptom reporting: Disentangling accuracy and bias. *Frontiers in Psychology*, 6, 732. https://doi.org/10.3389/fpsyg.2015.00732
- Wolters, C., Gerlach, A. L., & Pohl, A. (2022). Interoceptive accuracy and bias in somatic symptom disorder, illness anxiety disorder, and functional syndromes: A systematic review and meta-analysis. *PLOS ONE*, 17(8), e0271717. https://doi.org/10.1371/journal.pone.0271717

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
