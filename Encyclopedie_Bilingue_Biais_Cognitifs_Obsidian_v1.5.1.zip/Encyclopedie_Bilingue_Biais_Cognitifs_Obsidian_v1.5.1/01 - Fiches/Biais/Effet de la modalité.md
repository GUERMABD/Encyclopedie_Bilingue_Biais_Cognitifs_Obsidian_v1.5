---
type: biais-cognitif
nom_fr: Effet de la modalité
nom_en: Modality effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: différence de rappel selon la modalité de présentation
robustesse: effet classique, fortement dépendant de la tâche et de la position sérielle
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Effet de la modalité

> **English:** Modality effect

## Définition — français

Différence de performance mnésique entre une présentation auditive et visuelle, notamment pour les derniers éléments d’une liste.

## Definition — English

A memory-performance difference between auditory and visual presentation, especially for recent list items.

## Exemple

Les derniers mots entendus sont parfois mieux rappelés que les derniers mots lus.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Persistance temporaire de codes sensoriels et stratégies d’encodage différentes.

## Mécanisme probable

Persistance temporaire de codes sensoriels et stratégies d’encodage différentes.

## Analyse critique

Il ne s’agit pas d’une supériorité générale de l’audio sur le visuel. Le résultat varie avec la tâche, le délai et les interférences.

**Conclusion de l’audit :** effet classique, fortement dépendant de la tâche et de la position sérielle.

## Comment le limiter ?

Choisir la modalité selon le contenu et combiner les formats sans surcharge.

## Classement

- Nature scientifique : différence de rappel selon la modalité de présentation
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Modality_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Craik, F. I. M. (1969). Modality effects in short-term storage. *Journal of Verbal Learning and Verbal Behavior*, 8(5), 658–664. https://doi.org/10.1016/S0022-5371(69)80119-2

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
