---
type: biais-cognitif
nom_fr: Biais d'homogénéité de l'exogroupe
nom_en: Outgroup homogeneity bias
statut_fr: article français contrôlé le 2026-08-01
traduction: terme français attesté
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases:
- Out–group homogeneity bias
url_fr_verifiee: https://fr.wikipedia.org/wiki/Biais_d%27homog%C3%A9n%C3%A9it%C3%A9_de_l%27exogroupe
nature_scientifique: biais de perception des groupes
robustesse: établie mais dépendante de la familiarité et du contexte
---
# Biais d'homogénéité de l'exogroupe

> **English:** Outgroup homogeneity bias

## Définition — français

Tendance à percevoir les membres d’un groupe extérieur comme plus semblables entre eux que les membres de son propre groupe.

## Definition — English

The tendency to perceive members of an outgroup as more similar to one another than members of one’s ingroup.

## Exemple

Dire d’un groupe extérieur qu’« ils pensent tous pareil » tout en reconnaissant de nombreuses différences au sein de son propre groupe.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Connaissance plus détaillée de l’endogroupe, attention différente aux individus et généralisation à partir d’un petit nombre d’exemples.

## Mécanisme probable

Connaissance plus détaillée de l’endogroupe, attention différente aux individus et généralisation à partir d’un petit nombre d’exemples.

## Analyse critique

L’effet classique est réel dans plusieurs contextes, mais il peut être réduit ou inversé lorsque l’exogroupe est mieux connu, plus important ou perçu à un niveau différent.

**Conclusion de l’audit :** établie mais dépendante de la familiarité et du contexte.

## Comment le limiter ?

Chercher des exemples variés, distinguer les individus des catégories et vérifier la diversité réelle à partir de données plutôt que d’impressions.

## Classement

- Nature scientifique : biais de perception des groupes
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : article français contrôlé le 2026-08-01

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Outgroup_homogeneity_bias
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Biais_d%27homog%C3%A9n%C3%A9it%C3%A9_de_l%27exogroupe

## Références scientifiques contrôlées

- Quattrone, G. A., & Jones, E. E. (1980). The perception of variability within in-groups and out-groups: Implications for the law of small numbers. *Journal of Personality and Social Psychology*, 38(1), 141–152. https://doi.org/10.1037/0022-3514.38.1.141

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
