---
type: biais-cognitif
nom_fr: Effet de profondeur du traitement
nom_en: Levels-of-processing effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet de l’encodage sémantique sur la mémoire
robustesse: effet classique bien documenté, mais « profondeur » n’est pas une échelle unique
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases:
- Levels–of–processing effect
---
# Effet de profondeur du traitement

> **English:** Levels-of-processing effect

## Définition — français

Meilleure rétention lorsque le traitement porte sur le sens plutôt que seulement sur les caractéristiques superficielles.

## Definition — English

Better retention when processing focuses on meaning rather than only surface features.

## Exemple

Évaluer le sens d’un mot conduit généralement à un meilleur souvenir que compter ses lettres.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Élaboration sémantique et indices de récupération plus riches.

## Mécanisme probable

Élaboration sémantique et indices de récupération plus riches.

## Analyse critique

Le terme « profondeur » est descriptif et dépend de la compatibilité entre encodage et test. Un traitement sémantique n’est pas toujours supérieur pour toutes les tâches.

**Conclusion de l’audit :** effet classique bien documenté, mais « profondeur » n’est pas une échelle unique.

## Comment le limiter ?

Relier les connaissances à des exemples, explications et questions de compréhension.

## Classement

- Nature scientifique : effet de l’encodage sémantique sur la mémoire
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Levels-of-processing_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Craik, F. I. M., & Tulving, E. (1975). Depth of processing and the retention of words in episodic memory. *Journal of Experimental Psychology: General*, 104(3), 268–294. https://doi.org/10.1037/0096-3445.104.3.268

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
