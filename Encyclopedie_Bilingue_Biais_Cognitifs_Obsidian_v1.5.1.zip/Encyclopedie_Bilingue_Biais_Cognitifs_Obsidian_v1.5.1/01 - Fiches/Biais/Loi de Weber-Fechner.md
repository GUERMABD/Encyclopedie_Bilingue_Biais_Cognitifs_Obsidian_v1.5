---
type: loi-psychophysique
nom_fr: Loi de Weber-Fechner
nom_en: Weber–Fechner law
statut_fr: article français contrôlé le 2026-08-01
traduction: terme français attesté
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Baseline
codex:
- Trop d'informations
aliases: []
nature_scientifique: modèle historique de relation stimulus–sensation
robustesse: valide comme approximation dans certains domaines, non universelle
url_fr_verifiee: https://fr.wikipedia.org/wiki/Loi_de_Weber-Fechner
---
# Loi de Weber-Fechner

> **English:** Weber–Fechner law

## Définition — français

Modèle psychophysique historique selon lequel la grandeur ressentie croît approximativement comme le logarithme de l’intensité physique du stimulus.

## Definition — English

A historical psychophysical model in which perceived magnitude increases approximately with the logarithm of physical stimulus intensity.

## Exemple

Une même augmentation absolue d’intensité peut être très perceptible à faible niveau et peu perceptible à niveau élevé.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Le modèle relie variation physique et échelle subjective ; il ne décrit pas un mécanisme de jugement irrationnel.

## Mécanisme probable

Le modèle relie variation physique et échelle subjective ; il ne décrit pas un mécanisme de jugement irrationnel.

## Analyse critique

Ce n’est pas un biais cognitif, mais une loi ou approximation psychophysique. Elle présente des écarts aux extrêmes et selon les modalités. La dénomination « Weber–Fechner » fusionne en outre des lois logiquement distinctes : loi de Weber sur les seuils différentiels et loi logarithmique de Fechner.

**Conclusion de l’audit :** modèle historique utile, à portée limitée et terminologie discutée.

## Comment le limiter ou l’étudier correctement ?

Préciser la modalité sensorielle et la plage d’intensité, vérifier empiriquement la forme de la relation et comparer avec d’autres modèles comme la loi de puissance de Stevens.

## Classement

- Nature scientifique : modèle historique de relation stimulus–sensation
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Trop d'informations
- Statut français : article français contrôlé le 2026-08-01

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Weber%E2%80%93Fechner_law
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Loi_de_Weber-Fechner

## Références scientifiques contrôlées

- Stevens, S. S. (1957). On the psychophysical law. *Psychological Review*, 64(3), 153–181. https://doi.org/10.1037/h0046162
- Algom, D. (2021). The Weber–Fechner law: A misnomer that persists but that should go away. *Psychological Review*, 128(4), 757–765. https://doi.org/10.1037/rev0000278

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
