---
type: processus-mnesiques
nom_fr: Nivellement et affinement
nom_en: Leveling and sharpening
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
nature_scientifique: 'transformations reconstructives des récits: perte de détails et accentuation sélective'
robustesse: phénomènes historiques influents, mais catégories larges et peu standardisées dans la recherche contemporaine
---
# Nivellement et affinement

> **English:** Leveling and sharpening

## Définition — français

Lors de transmissions ou rappels successifs, certains détails disparaissent tandis que d’autres deviennent plus saillants.

## Definition — English

Across repeated recall or transmission, some details are lost while others become selectively emphasized.

## Exemple

Une rumeur devient plus courte et accentue progressivement un détail compatible avec les attentes du groupe.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Reconstruction schématique, sélection narrative et contraintes de communication.

## Mécanisme probable

Reconstruction schématique, sélection narrative et contraintes de communication.

## Analyse critique

Les termes proviennent des travaux classiques sur les rumeurs et la mémoire reconstructive. Ils ne forment pas une loi quantitative unique.

**Conclusion de l’audit :** phénomènes historiques influents, mais catégories larges et peu standardisées dans la recherche contemporaine.

## Comment le limiter ?

Conserver la version originale, tracer les transformations et demander des rappels indépendants.

## Classement

- Nature scientifique : transformations reconstructives des récits: perte de détails et accentuation sélective
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Leveling_and_sharpening
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Allport, G. W., & Postman, L. (1947). *The Psychology of Rumor*. Henry Holt.
- Koriat, A., Goldsmith, M., & Pansky, A. (2000). Toward a psychology of memory accuracy. *Annual Review of Psychology*, 51, 481–537. https://doi.org/10.1146/annurev.psych.51.1.481

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
