---
type: biais-cognitif
nom_fr: Effet de positivité
nom_en: Positivity effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: asymétrie liée à l’âge dans l’attention et la mémoire émotionnelles
robustesse: documenté, mais dépendant des objectifs, ressources et tâches
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Manque de sens
aliases: []
---
# Effet de positivité

> **English:** Positivity effect

## Définition — français

Tendance relative de certains adultes plus âgés à privilégier les informations positives par rapport aux négatives.

## Definition — English

A relative tendency for some older adults to favor positive over negative information.

## Exemple

Un groupe âgé rappelle proportionnellement davantage d’images positives qu’un groupe jeune dans certaines tâches.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Modification des objectifs motivationnels et contrôle attentionnel.

## Mécanisme probable

Modification des objectifs motivationnels et contrôle attentionnel.

## Analyse critique

Ce n’est pas un optimisme automatique de toutes les personnes âgées. L’effet varie selon les contraintes cognitives, la pertinence et la méthode.

**Conclusion de l’audit :** documenté, mais dépendant des objectifs, ressources et tâches.

## Comment le limiter ?

Ne pas déduire l’état émotionnel individuel à partir de l’âge; examiner la tâche et les objectifs.

## Classement

- Nature scientifique : asymétrie liée à l’âge dans l’attention et la mémoire émotionnelles
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Positivity_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Mather, M., & Carstensen, L. L. (2005). Aging and motivated cognition: The positivity effect in attention and memory. *Trends in Cognitive Sciences*, 9(10), 496–502. https://doi.org/10.1016/j.tics.2005.08.005

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
