---
type: biais-cognitif
nom_fr: Erreur du parieur
nom_en: Gambler's fallacy
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Baseline
codex:
- Manque de sens
aliases: []
nature_scientifique: erreur de raisonnement sur les séquences aléatoires
robustesse: établie lorsque les essais sont indépendants
---
# Erreur du parieur

> **English:** Gambler's fallacy

## Définition — français

Croyance qu’après une série d’un même résultat, le résultat opposé devient plus probable alors que les essais restent indépendants et de probabilité constante.

## Definition — English

The belief that after a run of one outcome, the opposite outcome becomes more likely even though trials remain independent and stationary.

## Exemple

Après plusieurs résultats rouges à la roulette, croire que le noir est désormais “dû”.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attente que de courtes séquences ressemblent immédiatement à la distribution globale et confusion entre équilibre à long terme et compensation à court terme.

## Mécanisme probable

Attente que de courtes séquences ressemblent immédiatement à la distribution globale et confusion entre équilibre à long terme et compensation à court terme.

## Analyse critique

L’étiquette ne s’applique pas lorsque le mécanisme change, lorsque les essais ne sont pas indépendants ou lorsque de nouvelles informations rendent réellement un résultat plus probable.

**Conclusion de l’audit :** établie lorsque les essais sont indépendants.

## Comment le limiter ?

Vérifier l’indépendance des essais et recalculer la probabilité à chaque essai sans utiliser la série passée lorsqu’elle n’apporte aucune information.

## Classement

- Nature scientifique : erreur de raisonnement sur les séquences aléatoires
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Gambler's_fallacy
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tversky, A., & Kahneman, D. (1971). Belief in the law of small numbers. *Psychological Bulletin*, 76(2), 105–110. https://doi.org/10.1037/h0031322

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
