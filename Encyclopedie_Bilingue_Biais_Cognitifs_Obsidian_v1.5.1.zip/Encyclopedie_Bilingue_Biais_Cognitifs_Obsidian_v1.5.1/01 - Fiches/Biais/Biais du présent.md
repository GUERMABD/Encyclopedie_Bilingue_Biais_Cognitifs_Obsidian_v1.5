---
type: biais-cognitif
nom_fr: Biais du présent
nom_en: Present bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: préférence intertemporelle disproportionnée pour l’immédiat
robustesse: largement documenté; interprétation dépendante des contraintes réelles
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
---
# Biais du présent

> **English:** Present bias

## Définition — français

Poids disproportionné accordé aux coûts et bénéfices immédiats par rapport aux conséquences futures.

## Definition — English

Disproportionate weight placed on immediate costs and benefits relative to future consequences.

## Exemple

Une personne renonce à une épargne avantageuse pour une dépense immédiate qu’elle regrettait d’avance.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Actualisation non constante et conflit entre préférences présentes et futures.

## Mécanisme probable

Actualisation non constante et conflit entre préférences présentes et futures.

## Analyse critique

Une préférence pour l’immédiat peut être rationnelle en présence d’incertitude, de besoin urgent ou de contrainte de liquidité. Le biais suppose une incohérence ou un poids excessif.

**Conclusion de l’audit :** largement documenté; interprétation dépendante des contraintes réelles.

## Comment le limiter ?

Utiliser des engagements préalables, automatiser l’épargne et rendre les conséquences futures concrètes.

## Classement

- Nature scientifique : préférence intertemporelle disproportionnée pour l’immédiat
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Present_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Laibson, D. (1997). Golden eggs and hyperbolic discounting. *Quarterly Journal of Economics*, 112(2), 443–478. https://doi.org/10.1162/003355397555253

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
