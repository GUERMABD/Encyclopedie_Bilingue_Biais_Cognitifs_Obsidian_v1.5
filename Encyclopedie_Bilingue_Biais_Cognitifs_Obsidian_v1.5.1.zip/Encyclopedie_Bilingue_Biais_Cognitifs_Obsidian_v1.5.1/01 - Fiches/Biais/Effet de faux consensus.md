---
type: biais-cognitif
nom_fr: Effet de faux consensus
nom_en: False consensus effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: biais de perception sociale
robustesse: établie mais modulée par l’information disponible
---
# Effet de faux consensus

> **English:** False consensus effect

## Définition — français

Tendance à surestimer la fréquence avec laquelle les autres partagent ses choix, opinions ou comportements.

## Definition — English

The tendency to overestimate how common one’s own choices, opinions, or behaviors are among other people.

## Exemple

Une personne favorable à une règle estime spontanément qu’une large majorité y est également favorable, sans données représentatives.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Accessibilité de son propre choix, fréquentation de personnes semblables et interprétation subjective des options.

## Mécanisme probable

Accessibilité de son propre choix, fréquentation de personnes semblables et interprétation subjective des options.

## Analyse critique

Une méta-analyse classique soutient l’existence moyenne de l’effet, mais son ampleur dépend fortement du protocole. Une information représentative et des incitations à l’exactitude peuvent le réduire.

**Conclusion de l’audit :** établie mais modulée par l’information disponible.

## Comment le limiter ?

S’appuyer sur des enquêtes représentatives, distinguer son entourage de la population et expliciter les différentes interprétations possibles des options.

## Classement

- Nature scientifique : biais de perception sociale
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/False_consensus_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Ross, L., Greene, D., & House, P. (1977). The ‘false consensus effect’: An egocentric bias in social perception and attribution processes. *Journal of Experimental Social Psychology*, 13(3), 279–301. https://doi.org/10.1016/0022-1031(77)90049-X
- Mullen, B., Atkins, J. L., Champion, D. S., Edwards, C., Hardy, D., Story, J. E., & Vanderklok, M. (1985). The false consensus effect: A meta-analysis of 115 hypothesis tests. *Journal of Experimental Social Psychology*, 21(3), 262–283. https://doi.org/10.1016/0022-1031(85)90020-4

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
