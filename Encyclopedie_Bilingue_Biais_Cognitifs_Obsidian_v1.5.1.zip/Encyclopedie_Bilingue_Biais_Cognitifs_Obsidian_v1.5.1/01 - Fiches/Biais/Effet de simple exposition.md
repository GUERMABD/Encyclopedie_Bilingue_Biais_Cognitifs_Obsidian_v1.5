---
type: biais-cognitif
nom_fr: Effet de simple exposition
nom_en: Mere exposure effect
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Inertia
codex:
- Trop d'informations
aliases:
- Mere–exposure effect
nature_scientifique: effet affectif de familiarité
robustesse: établie mais non monotone
---
# Effet de simple exposition

> **English:** Mere exposure effect

## Définition — français

Augmentation moyenne de l’appréciation d’un stimulus après des expositions répétées, en l’absence d’un renforcement explicite.

## Definition — English

The average increase in liking for a stimulus following repeated exposure without explicit reinforcement.

## Exemple

Un symbole initialement neutre devient légèrement plus apprécié après avoir été vu plusieurs fois.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Familiarité accrue et traitement plus fluide, parfois interprétés comme un signal positif ou de sécurité.

## Mécanisme probable

Familiarité accrue et traitement plus fluide, parfois interprétés comme un signal positif ou de sécurité.

## Analyse critique

L’effet moyen est soutenu par une méta-analyse, mais il dépend du nombre d’expositions, de la complexité et de la familiarité initiale. Une exposition excessive ou négative peut réduire l’appréciation.

**Conclusion de l’audit :** établie mais non monotone.

## Comment le limiter ?

Ne pas confondre familiarité et qualité ; comparer les options à l’aveugle et contrôler le nombre d’expositions lorsqu’il influence l’évaluation.

## Classement

- Nature scientifique : effet affectif de familiarité
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Trop d'informations
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Mere-exposure_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Zajonc, R. B. (1968). Attitudinal effects of mere exposure. *Journal of Personality and Social Psychology*, 9(2, Pt. 2), 1–27. https://doi.org/10.1037/h0025848
- Bornstein, R. F. (1989). Exposure and affect: Overview and meta-analysis of research, 1968–1987. *Psychological Bulletin*, 106(2), 265–289. https://doi.org/10.1037/0033-2909.106.2.265

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
