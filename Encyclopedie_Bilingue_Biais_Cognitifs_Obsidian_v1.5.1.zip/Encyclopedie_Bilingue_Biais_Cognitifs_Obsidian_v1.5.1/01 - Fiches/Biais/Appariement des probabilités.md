---
type: biais-cognitif
nom_fr: Appariement des probabilités
nom_en: Probability matching
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: stratégie de prédiction proportionnelle
robustesse: phénomène robuste dans certaines tâches répétées; pas toujours stratégie par défaut
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Appariement des probabilités

> **English:** Probability matching

## Définition — français

Tendance à répartir ses prédictions selon les probabilités observées plutôt qu’à choisir systématiquement l’issue la plus probable.

## Definition — English

The tendency to distribute predictions according to observed probabilities rather than always choosing the most likely outcome.

## Exemple

Face à un événement A survenant 70 % du temps, une personne choisit A environ 70 % du temps au lieu de toujours choisir A.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Exploration, recherche de structure et apprentissage par renforcement.

## Mécanisme probable

Exploration, recherche de structure et apprentissage par renforcement.

## Analyse critique

Dans une tâche stationnaire simple, cette stratégie réduit l’exactitude attendue par rapport à la maximisation. Dans des environnements changeants, explorer peut être utile.

**Conclusion de l’audit :** phénomène robuste dans certaines tâches répétées; pas toujours stratégie par défaut.

## Comment le limiter ?

Calculer la stratégie optimale selon l’objectif et vérifier si les probabilités sont stables.

## Classement

- Nature scientifique : stratégie de prédiction proportionnelle
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Probability_matching
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Vulkan, N. (2000). An economist’s perspective on probability matching. *Journal of Economic Surveys*, 14(1), 101–118. https://doi.org/10.1111/1467-6419.00106

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
