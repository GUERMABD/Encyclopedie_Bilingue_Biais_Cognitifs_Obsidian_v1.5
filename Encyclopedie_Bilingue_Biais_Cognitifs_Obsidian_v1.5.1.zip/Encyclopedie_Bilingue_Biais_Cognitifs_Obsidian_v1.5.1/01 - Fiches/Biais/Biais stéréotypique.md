---
type: biais-cognitif
nom_fr: Biais stéréotypique
nom_en: Stereotype bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Inertia
codex: []
aliases: []
nature_scientifique: distorsion de mémoire ou de jugement conforme aux stéréotypes
robustesse: effets documentés mais dépendants de l’activation, de la motivation et du contrôle; catégorie large
---
# Biais stéréotypique

> **English:** Stereotype bias

## Définition — français

Tendance à coder, rappeler ou interpréter une information d’une manière plus conforme à un stéréotype social.

## Definition — English

The tendency to encode, remember, or interpret information in a way that is more consistent with a social stereotype.

## Exemple

Un comportement ambigu est rappelé comme plus agressif lorsqu’il est associé à un groupe stéréotypé comme agressif.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Activation associative, contrôle de source imparfait et reconstruction schématique.

## Mécanisme probable

Activation associative, contrôle de source imparfait et reconstruction schématique.

## Analyse critique

Cette entrée ne désigne pas tous les stéréotypes ni toutes les discriminations. Les informations inattendues peuvent parfois être mieux mémorisées en raison de leur distinctivité.

**Conclusion de l’audit :** effets documentés mais dépendants de l’activation, de la motivation et du contrôle; catégorie large.

## Comment le limiter ?

Consigner les faits observables, ralentir le jugement et comparer les mêmes comportements entre catégories.

## Classement

- Nature scientifique : distorsion de mémoire ou de jugement conforme aux stéréotypes
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Stereotype_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Payne, B. K., Jacoby, L. L., & Lambert, A. J. (2004). Memory monitoring and the control of stereotype distortion. *Journal of Experimental Social Psychology*, 40(1), 52–64. https://doi.org/10.1016/S0022-1031(03)00069-6

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
