---
type: aphorisme-heuristique
nom_fr: Loi de l'instrument
nom_en: Law of the instrument
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Self-perspective
codex: []
aliases: []
nature_scientifique: tendance ou aphorisme décrivant la surutilisation d’un outil familier
robustesse: idée plausible reliée à la fixation fonctionnelle, mais non effet unique doté d’une mesure standard
---
# Loi de l'instrument

> **English:** Law of the instrument

## Définition — français

Tendance à appliquer son outil ou sa méthode habituelle à des problèmes pour lesquels elle n’est pas adaptée.

## Definition — English

The tendency to apply a familiar tool or method to problems for which it is poorly suited.

## Exemple

Une équipe habituée aux tableaux de bord répond à chaque difficulté organisationnelle en créant un nouvel indicateur, même lorsque le problème est humain.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Expertise locale, accessibilité de la solution et coût d’apprentissage d’alternatives.

## Mécanisme probable

Expertise locale, accessibilité de la solution et coût d’apprentissage d’alternatives.

## Analyse critique

Réutiliser un outil connu peut être rationnel. L’erreur se situe dans l’absence de comparaison avec d’autres méthodes.

**Conclusion de l’audit :** idée plausible reliée à la fixation fonctionnelle, mais non effet unique doté d’une mesure standard.

## Comment le limiter ?

Définir le problème avant l’outil et imposer au moins une solution alternative.

## Classement

- Nature scientifique : tendance ou aphorisme décrivant la surutilisation d’un outil familier
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : absent
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Law_of_the_instrument
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kaplan, A. (1964). *The Conduct of Inquiry*. Chandler.
- Maslow, A. H. (1966). *The Psychology of Science*. Harper & Row.

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
