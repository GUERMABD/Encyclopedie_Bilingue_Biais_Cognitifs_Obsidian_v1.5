---
type: biais-cognitif
nom_fr: Effet de dotation
nom_en: Endowment effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Inertia
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: effet de décision et de valorisation
robustesse: établie mais contextuelle
---
# Effet de dotation

> **English:** Endowment effect

## Définition — français

Tendance à demander davantage pour céder un bien que ce que l’on aurait accepté de payer pour l’acquérir, toutes choses comparables par ailleurs.

## Definition — English

The tendency to value an owned item more highly than the same item before ownership, often observed as a gap between willingness to accept and willingness to pay.

## Exemple

Après avoir reçu une tasse, une personne exige un prix de vente supérieur au montant qu’elle aurait accepté de payer quelques minutes auparavant.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : La possession peut créer un point de référence et transformer la cession en perte perçue. L’attachement, l’incertitude sur la valeur et les règles de l’échange peuvent aussi intervenir.

## Mécanisme probable

La possession peut créer un point de référence et transformer la cession en perte perçue. L’attachement, l’incertitude sur la valeur et les règles de l’échange peuvent aussi intervenir.

## Analyse critique

L’effet est bien documenté, mais il n’est ni automatique ni de taille constante. L’expérience du marché, la nature du bien et la procédure de mesure peuvent fortement le réduire.

**Conclusion de l’audit :** établie mais contextuelle.

## Comment le limiter ?

Comparer la valeur du bien à des alternatives réelles, raisonner avant l’attribution de propriété et utiliser une procédure d’évaluation identique pour l’achat et la vente.

## Classement

- Nature scientifique : effet de décision et de valorisation
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Endowment_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kahneman, D., Knetsch, J. L., & Thaler, R. H. (1990). Experimental Tests of the Endowment Effect and the Coase Theorem. *Journal of Political Economy*, 98(6), 1325–1348. https://doi.org/10.1086/261737

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
