---
type: biais-cognitif
nom_fr: Biais de croyance
nom_en: Belief bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de raisonnement logique
robustesse: robuste dans les tâches syllogistiques; interaction complexe entre logique, croyance et compréhension
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Biais de croyance

> **English:** Belief bias

## Définition — français

Tendance à juger la validité d’un raisonnement selon la plausibilité de sa conclusion plutôt que selon sa structure logique.

## Definition — English

The tendency to judge an argument’s validity from the believability of its conclusion rather than its logical form.

## Exemple

Un syllogisme invalide est accepté parce que sa conclusion est vraie dans la vie courante.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Conflit entre réponse fondée sur les connaissances et analyse formelle des prémisses.

## Mécanisme probable

Conflit entre réponse fondée sur les connaissances et analyse formelle des prémisses.

## Analyse critique

Une conclusion crédible peut être vraie tout en étant mal déduite. Les performances dépendent aussi de la compréhension des quantificateurs et de la charge cognitive.

**Conclusion de l’audit :** robuste dans les tâches syllogistiques; interaction complexe entre logique, croyance et compréhension.

## Comment le limiter ?

Évaluer séparément : « la conclusion est-elle plausible ? » et « découle-t-elle nécessairement des prémisses ? ».

## Classement

- Nature scientifique : biais de raisonnement logique
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Belief_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Evans, J. St. B. T., Barston, J. L., & Pollard, P. (1983). On the conflict between logic and belief in syllogistic reasoning. *Memory & Cognition*, 11, 295–306. https://doi.org/10.3758/BF03196976

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
