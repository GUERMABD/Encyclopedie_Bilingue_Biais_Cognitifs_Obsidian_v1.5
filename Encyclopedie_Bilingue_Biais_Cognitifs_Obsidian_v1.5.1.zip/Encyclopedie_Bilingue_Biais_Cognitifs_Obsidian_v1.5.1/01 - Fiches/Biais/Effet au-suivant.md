---
type: biais-cognitif
nom_fr: Effet au-suivant
nom_en: Next-in-line effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases:
- Next–in–line effect
nature_scientifique: déficit de mémoire avant une prise de parole attendue
robustesse: effet de laboratoire répliqué dans plusieurs études anciennes; dépend de l’anxiété, de l’anticipation et du matériel
---
# Effet au-suivant

> **English:** Next-in-line effect

## Définition — français

Baisse du rappel des informations présentées juste avant son tour de parler ou d’effectuer une tâche attendue.

## Definition — English

Reduced recall for information presented just before one’s anticipated turn to speak or perform.

## Exemple

Dans un tour de table, une personne se souvient moins bien de l’intervention qui précède la sienne.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attention mobilisée par la préparation de sa propre performance et encodage élaboratif réduit.

## Mécanisme probable

Attention mobilisée par la préparation de sa propre performance et encodage élaboratif réduit.

## Analyse critique

L’effet n’est pas une amnésie générale et peut disparaître avec un matériel structuré ou une élaboration suffisante.

**Conclusion de l’audit :** effet de laboratoire répliqué dans plusieurs études anciennes; dépend de l’anxiété, de l’anticipation et du matériel.

## Comment le limiter ?

Préparer sa prise de parole à l’avance, prendre des notes et réserver un temps de reformulation avant d’intervenir.

## Classement

- Nature scientifique : déficit de mémoire avant une prise de parole attendue
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Next-in-line_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Brenner, M. (1973). The next-in-line effect. *Journal of Verbal Learning and Verbal Behavior*, 12(3), 320–323. https://doi.org/10.1016/S0022-5371(73)80076-3
- Bond, C. F., Pitre, U., & van Leeuwen, M. D. (1991). Encoding operations and the next-in-line effect. *Personality and Social Psychology Bulletin*, 17(4), 435–441. https://doi.org/10.1177/0146167291174012

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
