---
type: biais-cognitif
nom_fr: Favoritisme intragroupe
nom_en: In-group favoritism
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases:
- Ingroup bias
- In–group favoritism
- Biais intragroupe
nature_scientifique: effet de catégorisation sociale
robustesse: établie mais contextuelle
---
# Favoritisme intragroupe

> **English:** In-group favoritism

## Définition — français

Tendance à favoriser les membres de son propre groupe dans certaines évaluations ou allocations de ressources.

## Definition — English

The tendency to favor members of one’s own group in some evaluations or allocations of resources.

## Exemple

Dans une tâche d’allocation, une personne attribue davantage à un membre de son groupe, même lorsque les groupes ont été formés sur un critère arbitraire.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : La simple catégorisation peut rendre l’appartenance au groupe pertinente et favoriser la différenciation positive de l’endogroupe.

## Mécanisme probable

La simple catégorisation peut rendre l’appartenance au groupe pertinente et favoriser la différenciation positive de l’endogroupe.

## Analyse critique

Les expériences de groupes minimaux montrent qu’une catégorisation faible peut suffire, mais l’effet n’est pas universel et ne se confond pas avec l’hostilité envers l’exogroupe.

**Conclusion de l’audit :** établie mais contextuelle.

## Comment le limiter ?

Anonymiser l’appartenance au groupe lorsqu’elle est non pertinente, appliquer des critères explicites et vérifier les décisions par groupe.

## Classement

- Nature scientifique : effet de catégorisation sociale
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/In-group_favoritism
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tajfel, H., Billig, M. G., Bundy, R. P., & Flament, C. (1971). Social categorization and intergroup behaviour. *European Journal of Social Psychology*, 1(2), 149–178. https://doi.org/10.1002/ejsp.2420010202

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
