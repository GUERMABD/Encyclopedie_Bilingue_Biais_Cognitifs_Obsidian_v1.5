---
type: biais-cognitif
nom_fr: Illusion monétaire
nom_en: Money illusion
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais vers les valeurs monétaires nominales
robustesse: documenté expérimentalement; dépendant du contexte économique et des connaissances
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex:
- Trop d'informations
aliases: []
---
# Illusion monétaire

> **English:** Money illusion

## Définition — français

Tendance à raisonner en montants nominaux plutôt qu’en pouvoir d’achat réel.

## Definition — English

The tendency to reason in nominal monetary amounts rather than real purchasing power.

## Exemple

Une hausse de salaire inférieure à l’inflation est perçue comme un gain parce que le nombre d’euros augmente.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Saillance des nombres nominaux et calcul coûteux de l’inflation.

## Mécanisme probable

Saillance des nombres nominaux et calcul coûteux de l’inflation.

## Analyse critique

Les personnes peuvent utiliser simultanément les représentations nominales et réelles. Une référence nominale n’est pas toujours une erreur selon le contrat ou l’objectif.

**Conclusion de l’audit :** documenté expérimentalement; dépendant du contexte économique et des connaissances.

## Comment le limiter ?

Comparer les montants en euros constants et expliciter l’inflation, les taxes et les prix pertinents.

## Classement

- Nature scientifique : biais vers les valeurs monétaires nominales
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Trop d'informations
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Money_illusion
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Shafir, E., Diamond, P., & Tversky, A. (1997). Money illusion. *Quarterly Journal of Economics*, 112(2), 341–374. https://doi.org/10.1162/003355397555208

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
