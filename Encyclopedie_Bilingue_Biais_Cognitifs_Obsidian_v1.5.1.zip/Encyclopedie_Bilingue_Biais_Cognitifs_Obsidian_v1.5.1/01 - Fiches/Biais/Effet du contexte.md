---
type: famille-effets
nom_fr: Effet du contexte
nom_en: Context effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Trop d'informations
aliases: []
nature_scientifique: famille d’effets de dépendance au contexte en perception et mémoire
robustesse: nombreux effets robustes, mais le terme est trop large pour désigner un mécanisme unique
---
# Effet du contexte

> **English:** Context effect

## Définition — français

Modification de la perception, de la reconnaissance ou du jugement selon les informations et l’environnement qui entourent la cible.

## Definition — English

A change in perception, recognition, or judgment caused by the information and environment surrounding the target.

## Exemple

Un mot est mieux reconnu lorsque le contexte de test ressemble au contexte d’apprentissage.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Encodage relationnel, indices de récupération et comparaison locale.

## Mécanisme probable

Encodage relationnel, indices de récupération et comparaison locale.

## Analyse critique

Le contexte peut améliorer ou détériorer la performance. Cette fiche désigne une famille, pas une loi unique.

**Conclusion de l’audit :** nombreux effets robustes, mais le terme est trop large pour désigner un mécanisme unique.

## Comment le limiter ?

Tester les décisions dans plusieurs contextes et isoler la variable contextuelle pertinente.

## Classement

- Nature scientifique : famille d’effets de dépendance au contexte en perception et mémoire
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Context_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Humphreys, M. S. (1976). Relational information and the context effect in recognition memory. *Memory & Cognition*, 4(2), 221–232. https://doi.org/10.3758/BF03213167

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
