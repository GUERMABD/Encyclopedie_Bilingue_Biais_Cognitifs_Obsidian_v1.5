---
type: concept-social-recent
nom_fr: Motonormativité
nom_en: Motonormativity
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: normalisation sociale de l’automobile produisant des jugements asymétriques
robustesse: concept introduit récemment sur un grand échantillon britannique; réplications et comparaisons interculturelles encore nécessaires
---
# Motonormativité

> **English:** Motonormativity

## Définition — français

Tendance à accepter pour l’automobile des risques ou restrictions que l’on jugerait inacceptables dans un contexte non automobile équivalent.

## Definition — English

A tendency to accept automobile-related risks or restrictions that would be judged unacceptable in an equivalent non-motoring context.

## Exemple

Une contrainte imposée par la circulation est jugée normale alors que la même contrainte causée par une autre activité est rejetée.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Normes sociales, exposition répétée et cadrage implicite de la mobilité motorisée.

## Mécanisme probable

Normes sociales, exposition répétée et cadrage implicite de la mobilité motorisée.

## Analyse critique

Il s’agit d’un concept de 2023, initialement étudié au Royaume-Uni; il ne faut pas le présenter comme un biais universel déjà stabilisé.

**Conclusion de l’audit :** concept introduit récemment sur un grand échantillon britannique; réplications et comparaisons interculturelles encore nécessaires.

## Comment le limiter ?

Comparer des scénarios strictement équivalents avec et sans automobile et examiner les données de risque.

## Classement

- Nature scientifique : normalisation sociale de l’automobile produisant des jugements asymétriques
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Motonormativity
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Walker, I., Tapp, A., & Davis, A. (2023). Motonormativity: How social norms hide a major public health hazard. *International Journal of Environment and Health*, 11(1), 21–33. https://doi.org/10.1504/IJENVH.2023.135446

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
