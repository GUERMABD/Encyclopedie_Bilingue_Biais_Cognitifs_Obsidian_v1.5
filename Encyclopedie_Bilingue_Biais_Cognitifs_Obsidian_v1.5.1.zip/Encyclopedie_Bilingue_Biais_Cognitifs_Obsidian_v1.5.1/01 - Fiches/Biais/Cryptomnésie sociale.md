---
type: biais-cognitif
nom_fr: Cryptomnésie sociale
nom_en: Social cryptomnesia
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: concept de mémoire collective et d’influence minoritaire
robustesse: concept documenté dans un courant de psychologie sociale; corpus plus limité que les biais de mémoire individuels
---
# Cryptomnésie sociale

> **English:** Social cryptomnesia

## Définition — français

Adoption sociale d’idées portées par une minorité accompagnée de l’oubli ou du déni du rôle joué par cette minorité.

## Definition — English

Social adoption of ideas promoted by a minority while forgetting or denying that minority’s role in producing the change.

## Exemple

Des droits obtenus par un mouvement sont approuvés, mais le mouvement reste discrédité et n’est plus reconnu comme leur source.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Dissociation entre contenu devenu normatif et source minoritaire toujours stigmatisée.

## Mécanisme probable

Dissociation entre contenu devenu normatif et source minoritaire toujours stigmatisée.

## Analyse critique

Il s’agit d’un processus sociohistorique, pas d’un simple oubli individuel. L’attribution causale d’un changement social exige des sources historiques et peut rester débattue.

**Conclusion de l’audit :** concept documenté dans un courant de psychologie sociale; corpus plus limité que les biais de mémoire individuels.

## Comment le limiter ?

Documenter les acteurs et étapes du changement, citer les sources historiques et évaluer séparément l’idée et le groupe qui l’a portée.

## Classement

- Nature scientifique : concept de mémoire collective et d’influence minoritaire
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Social_cryptomnesia
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Vernet, J.-P., & Butera, F. (2005). Women, women’s rights and feminist movements. *Social Science Information*, 44(1), 175–188. https://doi.org/10.1177/0539018405050465
- Butera, F., Mugny, G., Legrenzi, P., & Pérez, J. A. (2010). Influence without credit: How successful minorities respond to social cryptomnesia. In *Coping with Minority Status*. Cambridge University Press.

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
