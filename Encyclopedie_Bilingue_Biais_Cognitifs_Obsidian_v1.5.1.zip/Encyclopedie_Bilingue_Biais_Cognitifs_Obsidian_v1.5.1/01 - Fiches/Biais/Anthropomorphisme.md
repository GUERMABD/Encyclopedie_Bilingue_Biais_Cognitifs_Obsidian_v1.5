---
type: biais-cognitif
nom_fr: Anthropomorphisme
nom_en: Anthropomorphism
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases: []
nature_scientifique: processus d’attribution de caractéristiques humaines
robustesse: bien documenté comme tendance contextuelle; ni constant ni nécessairement erroné
---
# Anthropomorphisme

> **English:** Anthropomorphism

## Définition — français

Attribution d’intentions, d’émotions ou de capacités humaines à des animaux, objets, systèmes ou phénomènes non humains.

## Definition — English

Attributing human intentions, emotions, or capacities to nonhuman animals, objects, systems, or events.

## Exemple

Un utilisateur interprète l’erreur d’un logiciel comme de la mauvaise volonté.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Connaissances centrées sur soi, motivation à comprendre l’agent et besoin de lien social.

## Mécanisme probable

Connaissances centrées sur soi, motivation à comprendre l’agent et besoin de lien social.

## Analyse critique

L’anthropomorphisme peut faciliter l’interaction et certaines prédictions. Il devient biaisant lorsque les propriétés attribuées ne sont pas soutenues par le fonctionnement réel du système.

**Conclusion de l’audit :** bien documenté comme tendance contextuelle; ni constant ni nécessairement erroné.

## Comment le limiter ?

Décrire les mécanismes observables, distinguer métaphore et propriété réelle, puis vérifier les prédictions produites par l’attribution.

## Classement

- Nature scientifique : processus d’attribution de caractéristiques humaines
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Anthropomorphism#Psychology
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Epley, N., Waytz, A., & Cacioppo, J. T. (2007). On seeing human: A three-factor theory of anthropomorphism. *Psychological Review*, 114(4), 864–886. https://doi.org/10.1037/0033-295X.114.4.864

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
