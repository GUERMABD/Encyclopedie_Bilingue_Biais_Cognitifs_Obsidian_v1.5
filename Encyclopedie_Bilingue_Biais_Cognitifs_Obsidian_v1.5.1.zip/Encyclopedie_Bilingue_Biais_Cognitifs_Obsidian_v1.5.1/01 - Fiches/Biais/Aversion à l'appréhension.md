---
type: biais-cognitif
nom_fr: Aversion à l'appréhension
nom_en: Dread aversion
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: préférence intertemporelle liée à l’anticipation négative
robustesse: anticipation de la douleur ou de l’inconfort documentée; étiquette et ampleur dépendantes du domaine
---
# Aversion à l'appréhension

> **English:** Dread aversion

## Définition — français

Préférence pour subir plus tôt une expérience négative afin d’éviter une période prolongée d’anticipation anxieuse.

## Definition — English

A preference to undergo an unpleasant experience sooner in order to avoid a prolonged period of anxious anticipation.

## Exemple

Une personne préfère un soin douloureux demain plutôt que dans un mois, malgré l’avantage habituel du report des coûts.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Coût psychologique de l’anticipation et accumulation de la crainte avant l’événement.

## Mécanisme probable

Coût psychologique de l’anticipation et accumulation de la crainte avant l’événement.

## Analyse critique

Cette préférence peut être rationnelle si l’attente elle-même a un coût réel. Elle ne constitue pas une aversion universelle au délai.

**Conclusion de l’audit :** anticipation de la douleur ou de l’inconfort documentée; étiquette et ampleur dépendantes du domaine.

## Comment le limiter ?

Inclure explicitement le coût de l’attente, distinguer douleur attendue et douleur réelle, puis comparer les options complètes.

## Classement

- Nature scientifique : préférence intertemporelle liée à l’anticipation négative
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Dread_aversion
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Loewenstein, G. (1987). Anticipation and the valuation of delayed consumption. *The Economic Journal*, 97(387), 666–684. https://doi.org/10.2307/2232929

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
