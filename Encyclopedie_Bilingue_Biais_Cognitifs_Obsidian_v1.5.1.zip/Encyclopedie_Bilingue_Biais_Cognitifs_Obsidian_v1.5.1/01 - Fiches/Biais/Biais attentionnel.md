---
type: biais-cognitif
nom_fr: Biais attentionnel
nom_en: Attentional bias
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: famille d’asymétries de sélection attentionnelle
robustesse: effets documentés, mais mesures parfois peu fiables et fortement dépendantes du stimulus
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Inertia
codex:
- Trop d'informations
aliases: []
---
# Biais attentionnel

> **English:** Attentional bias

## Définition — français

Orientation préférentielle de l’attention vers certains types d’informations.

## Definition — English

Preferential allocation of attention toward particular kinds of information.

## Exemple

Une personne anxieuse détecte plus rapidement certains signaux de menace que des signaux neutres.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Capture attentionnelle, vigilance, difficulté de désengagement et objectifs actifs.

## Mécanisme probable

Capture attentionnelle, vigilance, difficulté de désengagement et objectifs actifs.

## Analyse critique

Le terme regroupe plusieurs mécanismes et tâches. Un score ponctuel, notamment à un test informatisé, n’est pas un diagnostic individuel stable.

**Conclusion de l’audit :** effets documentés, mais mesures parfois peu fiables et fortement dépendantes du stimulus.

## Comment le limiter ?

Multiplier les mesures, contrôler les stimuli et rechercher activement les informations négligées.

## Classement

- Nature scientifique : famille d’asymétries de sélection attentionnelle
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Trop d'informations
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Attentional_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Bar-Haim, Y., Lamy, D., Pergamin, L., Bakermans-Kranenburg, M. J., & van IJzendoorn, M. H. (2007). Threat-related attentional bias in anxious and nonanxious individuals: A meta-analytic study. *Psychological Bulletin*, 133(1), 1–24. https://doi.org/10.1037/0033-2909.133.1.1

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
