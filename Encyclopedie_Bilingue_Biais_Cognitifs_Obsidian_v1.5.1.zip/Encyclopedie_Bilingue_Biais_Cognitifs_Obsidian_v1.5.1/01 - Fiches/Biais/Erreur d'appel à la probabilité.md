---
type: sophisme-logique
nom_fr: Erreur d'appel à la probabilité
nom_en: Appeal to probability fallacy
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Manque de sens
aliases: []
nature_scientifique: sophisme informel confondant possibilité ou probabilité avec réalisation certaine
robustesse: catégorie logique utile, non effet psychologique mesuré de manière autonome
---
# Erreur d'appel à la probabilité

> **English:** Appeal to probability fallacy

## Définition — français

Raisonnement concluant qu’un événement doit se produire simplement parce qu’il est possible ou probable.

## Definition — English

A fallacy that concludes an event must occur merely because it is possible or probable.

## Exemple

Un collègue affirme : « Une panne est possible sur cette machine ; elle arrivera donc nécessairement aujourd’hui. » La possibilité est transformée en certitude.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Confusion entre modalités, probabilités et certitude.

## Mécanisme probable

Confusion entre modalités, probabilités et certitude.

## Analyse critique

Cette entrée décrit une erreur argumentative, pas une tendance cognitive dotée d’une taille d’effet stable.

**Conclusion de l’audit :** catégorie logique utile, non effet psychologique mesuré de manière autonome.

## Comment le limiter ?

Quantifier la probabilité et distinguer possible, probable et certain.

## Classement

- Nature scientifique : sophisme informel confondant possibilité ou probabilité avec réalisation certaine
- Tâche(s) du classement Wikipédia : non repris dans la liste anglaise contrôlée
- Sous-catégorie(s) (« flavors ») : non applicable
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Appeal_to_probability
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Tindale, C. W. (2007). *Fallacies and Argument Appraisal*. Cambridge University Press. https://doi.org/10.1017/CBO9780511806544

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
