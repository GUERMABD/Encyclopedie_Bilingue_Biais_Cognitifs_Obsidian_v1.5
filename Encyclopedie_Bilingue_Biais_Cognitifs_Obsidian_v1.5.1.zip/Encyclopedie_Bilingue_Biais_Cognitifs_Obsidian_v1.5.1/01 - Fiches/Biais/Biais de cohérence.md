---
type: biais-cognitif
nom_fr: Biais de cohérence
nom_en: Consistency bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Manque de sens
aliases:
- Biais de cohérence avec soi
- Self-consistency bias
- Self–consistency bias
nature_scientifique: biais reconstructif de mémoire autobiographique et d’attitudes
robustesse: bien documenté dans les rappels rétrospectifs; amplitude variable selon changement réel et mesure
---
# Biais de cohérence

> **English:** Consistency bias

## Définition — français

Tendance à se souvenir de ses attitudes ou comportements passés comme plus proches de ceux du présent qu’ils ne l’étaient réellement.

## Definition — English

The tendency to remember past attitudes or behavior as more similar to present ones than they actually were.

## Exemple

Après avoir changé d’opinion politique, une personne affirme avoir toujours pensé ainsi.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Reconstruction du passé à partir du concept de soi et des croyances actuelles.

## Mécanisme probable

Reconstruction du passé à partir du concept de soi et des croyances actuelles.

## Analyse critique

Le biais de cohérence et le biais de cohérence avec soi sont deux noms du même phénomène dans ce corpus. Une stabilité réelle ne doit pas être interprétée comme une distorsion.

**Conclusion de l’audit :** bien documenté dans les rappels rétrospectifs; amplitude variable selon changement réel et mesure.

## Comment le limiter ?

Conserver des traces datées des décisions et comparer le souvenir rétrospectif aux réponses enregistrées à l’époque.

## Classement

- Nature scientifique : biais reconstructif de mémoire autobiographique et d’attitudes
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Manque de sens
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Consistency_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Goethals, G. R., & Reckman, R. F. (1973). The perception of consistency in attitudes. *Journal of Experimental Social Psychology*, 9(6), 491–501. https://doi.org/10.1016/0022-1031(73)90030-9
- Zandvliet, R., Kalmijn, M., & Verbakel, E. (2008). Measuring once twice: An evaluation of recalling attitudes in survey research. *European Sociological Review*, 24(5), 563–577. https://doi.org/10.1093/esr/jcn048

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
