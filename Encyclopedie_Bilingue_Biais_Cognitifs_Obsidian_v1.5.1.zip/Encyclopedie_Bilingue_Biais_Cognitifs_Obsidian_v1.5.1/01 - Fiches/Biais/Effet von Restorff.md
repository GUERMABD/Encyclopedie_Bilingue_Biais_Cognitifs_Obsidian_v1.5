---
type: biais-cognitif
nom_fr: Effet von Restorff
nom_en: Von Restorff effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: avantage mnésique d’un élément distinctif
robustesse: effet établi, mécanismes dépendant de la distinctivité et de la tâche
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Baseline
codex:
- Trop d'informations
aliases: []
---
# Effet von Restorff

> **English:** Von Restorff effect

## Définition — français

Meilleure mémorisation d’un élément qui se distingue nettement de son contexte.

## Definition — English

Better memory for an item that clearly stands out from its context.

## Exemple

Un mot imprimé dans un format unique est mieux rappelé que les autres mots d’une liste homogène.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attention accrue, encodage distinctif et récupération facilitée.

## Mécanisme probable

Attention accrue, encodage distinctif et récupération facilitée.

## Analyse critique

La distinctivité doit être pertinente et rare; multiplier les éléments saillants supprime leur avantage.

**Conclusion de l’audit :** effet établi, mécanismes dépendant de la distinctivité et de la tâche.

## Comment le limiter ?

Réserver la mise en évidence aux informations réellement prioritaires.

## Classement

- Nature scientifique : avantage mnésique d’un élément distinctif
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Von_Restorff_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Schmidt, S. R., & Schmidt, C. R. (2017). Revisiting von Restorff’s early isolation effect. *Memory & Cognition*, 45(2), 194–207. https://doi.org/10.3758/s13421-016-0651-6

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
