---
type: biais-cognitif
nom_fr: Effet pom-pom girl
nom_en: Cheerleader effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet perceptif d’attractivité en groupe
robustesse: effet expérimental initial documenté; portée quotidienne encore limitée
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex:
- Manque de sens
aliases: []
---
# Effet pom-pom girl

> **English:** Cheerleader effect

## Définition — français

Légère augmentation de l’attractivité perçue d’un visage lorsqu’il est présenté dans un groupe plutôt qu’isolément.

## Definition — English

A slight increase in perceived facial attractiveness when a face is shown in a group rather than alone.

## Exemple

Un même portrait reçoit une note un peu plus élevée au sein d’un ensemble de visages.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Encodage de la moyenne du groupe et rapprochement perceptif vers cette moyenne.

## Mécanisme probable

Encodage de la moyenne du groupe et rapprochement perceptif vers cette moyenne.

## Analyse critique

L’effet observé est modeste et dépend de la présentation. Il ne constitue pas une règle générale sur les relations ou la valeur sociale.

**Conclusion de l’audit :** effet expérimental initial documenté; portée quotidienne encore limitée.

## Comment le limiter ?

Évaluer les personnes individuellement lorsque le jugement doit être précis.

## Classement

- Nature scientifique : effet perceptif d’attractivité en groupe
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Cheerleader_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Walker, D., & Vul, E. (2014). Hierarchical encoding makes individuals in a group seem more attractive. *Psychological Science*, 25(1), 230–235. https://doi.org/10.1177/0956797613497969

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
