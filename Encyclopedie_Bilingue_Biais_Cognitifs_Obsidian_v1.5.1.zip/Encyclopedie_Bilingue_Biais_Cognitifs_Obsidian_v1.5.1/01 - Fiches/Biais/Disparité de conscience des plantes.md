---
type: construit-attentionnel-educatif
nom_fr: Disparité de conscience des plantes
nom_en: Plant awareness disparity
statut_fr: traduction scientifique proposée; aucune page française individuelle validée dans cette édition
traduction: appellation descriptive privilégiée; ancien terme conservé comme alias
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases:
- Cécité aux plantes
- Plant blindness
nature_scientifique: disparité d’attention, de connaissance et de valorisation des plantes
robustesse: phénomène descriptif plausible; mesure et contours non standardisés
---
# Disparité de conscience des plantes

> **English:** Plant awareness disparity

## Définition — français

Tendance collective ou individuelle à moins remarquer, connaître et valoriser les plantes que les animaux dans l’environnement, l’éducation et la culture.

## Definition — English

An individual or societal tendency to notice, know, and value plants less than animals in the environment, education, and culture.

## Exemple

Dans une scène naturelle riche en végétation, les participants décrivent surtout les animaux et ignorent une grande partie des plantes présentes.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Saillance visuelle, mobilité animale, connaissances disponibles, pratiques éducatives et représentations culturelles peuvent contribuer à la disparité.

## Mécanisme probable

Saillance visuelle, mobilité animale, connaissances disponibles, pratiques éducatives et représentations culturelles peuvent contribuer à la disparité.

## Analyse critique

Ce n’est pas un biais cognitif unique et précisément délimité. L’expression historique « plant blindness » a été critiquée pour sa métaphore validiste et pour l’amalgame de plusieurs phénomènes ; « plant awareness disparity » est une appellation plus descriptive, sans résoudre à elle seule les problèmes de mesure.

**Conclusion de l’audit :** concept éducatif utile, terminologie et mesure encore en développement.

## Comment le limiter ou l’étudier correctement ?

Mesurer séparément attention, reconnaissance, connaissances et valorisation, et éviter d’inférer une cause cognitive unique.

## Classement

- Nature scientifique : disparité d’attention, de connaissance et de valorisation des plantes
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : traduction scientifique proposée; aucune page française individuelle validée dans cette édition

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Plant_blindness
- Français : aucune page individuelle équivalente validée dans cette édition ; résolution complémentaire prévue via Wikidata.

## Références scientifiques contrôlées

- Parsley, K. M. (2020). Plant awareness disparity: A case for renaming plant blindness. *Plants, People, Planet*, 2(6), 598–601. https://doi.org/10.1002/ppp3.10153

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
