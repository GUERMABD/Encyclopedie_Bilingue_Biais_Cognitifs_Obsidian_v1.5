---
type: biais-attentionnel
nom_fr: Effet de l'autruche
nom_en: Ostrich effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Trop d'informations
aliases: []
nature_scientifique: évitement sélectif d’informations jugées désagréables ou menaçantes
robustesse: documenté dans plusieurs domaines, avec une intensité fortement dépendante des enjeux, du contrôle perçu et des coûts
---
# Effet de l'autruche

> **English:** Ostrich effect

## Définition — français

Tendance à éviter ou retarder la consultation d’une information susceptible d’être mauvaise.

## Definition — English

The tendency to avoid or delay looking at information that may be unpleasant.

## Exemple

Lorsque le marché baisse fortement, un investisseur évite d’ouvrir son application bancaire afin de ne pas voir la diminution de son portefeuille.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Régulation émotionnelle à court terme et évitement de l’anticipation négative.

## Mécanisme probable

Régulation émotionnelle à court terme et évitement de l’anticipation négative.

## Analyse critique

L’évitement peut parfois être rationnel si l’information est inutile ou coûteuse. Le concept ne doit pas être appliqué à toute absence de consultation.

**Conclusion de l’audit :** documenté dans plusieurs domaines, avec une intensité fortement dépendante des enjeux, du contrôle perçu et des coûts.

## Comment le limiter ?

Planifier à l’avance des points de contrôle et séparer la collecte de l’information de la décision.

## Classement

- Nature scientifique : évitement sélectif d’informations jugées désagréables ou menaçantes
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Ostrich_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Karlsson, N., Loewenstein, G., & Seppi, D. (2009). The ostrich effect: Selective attention to information. *Journal of Risk and Uncertainty*, 38(2), 95–115. https://doi.org/10.1007/s11166-009-9060-6

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
