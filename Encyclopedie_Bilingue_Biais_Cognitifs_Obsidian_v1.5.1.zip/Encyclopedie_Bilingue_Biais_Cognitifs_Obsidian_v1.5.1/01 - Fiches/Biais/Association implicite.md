---
type: construit-de-cognition-sociale
nom_fr: Association implicite
nom_en: Implicit association
statut_fr: concept relié à l’article français sur le test d’association implicite; correspondance indirecte
traduction: terme français attesté dans le Codex; portée précisée
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
nature_scientifique: association automatique mesurée indirectement
robustesse: mesurable au niveau agrégé; interprétation individuelle limitée
url_fr_verifiee: https://fr.wikipedia.org/wiki/Test_d%27association_implicite
---
# Association implicite

> **English:** Implicit association

## Définition — français

Force relative d’une association mentale pouvant influencer la rapidité ou l’exactitude d’une réponse sans nécessiter un rapport verbal conscient.

## Definition — English

The relative strength of a mental association that can affect response speed or accuracy without requiring conscious verbal report.

## Exemple

Dans un test d’association implicite, une catégorisation est plus rapide lorsque deux concepts partageant une touche sont plus fortement associés en mémoire.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Activation associative et compatibilité des réponses influencent les temps de réaction ; plusieurs processus de contrôle et de tâche interviennent aussi.

## Mécanisme probable

Activation associative et compatibilité des réponses influencent les temps de réaction ; plusieurs processus de contrôle et de tâche interviennent aussi.

## Analyse critique

Une association implicite n’est pas, en elle-même, un biais ni une croyance cachée. Le test d’association implicite mesure des associations relatives dépendantes de la tâche. Ses scores ont une validité prédictive moyenne mais modeste et ne permettent pas de diagnostiquer avec certitude le comportement d’un individu.

**Conclusion de l’audit :** construit mesurable, mais interprétation individuelle à limiter.

## Comment le limiter ou l’étudier correctement ?

Employer plusieurs mesures, interpréter les scores relativement aux catégories comparées et éviter de transformer un résultat ponctuel en diagnostic moral ou comportemental.

## Classement

- Nature scientifique : association automatique mesurée indirectement
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : concept relié à l’article français sur le test d’association implicite; correspondance indirecte

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Implicit-association_test
- Français — article contrôlé : https://fr.wikipedia.org/wiki/Test_d%27association_implicite

## Références scientifiques contrôlées

- Greenwald, A. G., McGhee, D. E., & Schwartz, J. L. K. (1998). Measuring individual differences in implicit cognition: The Implicit Association Test. *Journal of Personality and Social Psychology*, 74(6), 1464–1480. https://doi.org/10.1037/0022-3514.74.6.1464
- Greenwald, A. G., Poehlman, T. A., Uhlmann, E. L., & Banaji, M. R. (2009). Understanding and using the Implicit Association Test: III. Meta-analysis of predictive validity. *Journal of Personality and Social Psychology*, 97(1), 17–41. https://doi.org/10.1037/a0015575

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
