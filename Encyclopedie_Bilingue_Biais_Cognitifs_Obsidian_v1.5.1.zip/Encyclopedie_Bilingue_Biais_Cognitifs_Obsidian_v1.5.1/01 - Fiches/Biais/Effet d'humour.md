---
type: biais-cognitif
nom_fr: Effet d'humour
nom_en: Humor effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: avantage mnésique conditionnel des contenus humoristiques
robustesse: documenté, mais dépendant du matériel et des comparaisons
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Trop d'informations
aliases: []
---
# Effet d'humour

> **English:** Humor effect

## Définition — français

Avantage de mémorisation observé pour certains contenus humoristiques par rapport à des contenus neutres.

## Definition — English

A memory advantage for some humorous material compared with neutral material.

## Exemple

Une phrase humoristique distinctive est mieux rappelée qu’une phrase neutre de structure comparable.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attention accrue, distinctivité et élaboration.

## Mécanisme probable

Attention accrue, distinctivité et élaboration.

## Analyse critique

L’humour peut aussi distraire du message central. L’effet n’autorise pas à conclure que toute présentation amusante améliore tout apprentissage.

**Conclusion de l’audit :** documenté, mais dépendant du matériel et des comparaisons.

## Comment le limiter ?

Relier l’humour au concept à mémoriser et tester le rappel du contenu central.

## Classement

- Nature scientifique : avantage mnésique conditionnel des contenus humoristiques
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/List_of_cognitive_biases#Humor_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Schmidt, S. R. (1994). Effects of humor on sentence memory. *Journal of Experimental Psychology: Learning, Memory, and Cognition*, 20(4), 953–967. https://doi.org/10.1037/0278-7393.20.4.953

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
