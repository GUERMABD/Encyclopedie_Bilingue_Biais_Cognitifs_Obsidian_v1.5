---
type: biais-cognitif
nom_fr: Biais de rappel hédonique
nom_en: Hedonic recall bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: biais de mémoire affective appliqué aux revenus et expériences
robustesse: effet publié mais base encore restreinte; dépend du délai et du contexte
---
# Biais de rappel hédonique

> **English:** Hedonic recall bias

## Définition — français

Tendance à reconstruire le souvenir d’une valeur ou expérience en fonction de son évaluation affective actuelle.

## Definition — English

The tendency to reconstruct a remembered value or experience in line with its current affective evaluation.

## Exemple

Des revenus passés sont rappelés comme plus élevés ou plus faibles selon la satisfaction associée à la période.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Reconstruction mnésique guidée par la valence et l’évaluation présente.

## Mécanisme probable

Reconstruction mnésique guidée par la valence et l’évaluation présente.

## Analyse critique

Le concept ne doit pas être étendu à toute erreur de rappel. Les mesures contemporaines et les données administratives sont nécessaires pour établir la direction du biais.

**Conclusion de l’audit :** effet publié mais base encore restreinte; dépend du délai et du contexte.

## Comment le limiter ?

Conserver des données au moment de l’expérience et distinguer souvenir factuel, satisfaction passée et satisfaction actuelle.

## Classement

- Nature scientifique : biais de mémoire affective appliqué aux revenus et expériences
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Hedonic_recall_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Prati, A. (2017). Hedonic recall bias: Why you should not ask people how much they earn. *Journal of Economic Behavior & Organization*, 143, 78–97. https://doi.org/10.1016/j.jebo.2017.09.002

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
