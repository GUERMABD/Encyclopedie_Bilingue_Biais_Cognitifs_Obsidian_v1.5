---
type: effet-de-decision
nom_fr: Aversion à la perte
nom_en: Loss aversion
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: asymétrie de décision autour d’un point de référence
robustesse: effet moyen soutenu, mais fortement hétérogène et non universel
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Aversion à la perte

> **English:** Loss aversion

## Définition — français

Tendance, observée dans certaines décisions, à accorder plus de poids à une perte qu’à un gain comparable.

## Definition — English

The tendency to experience a loss more strongly than a comparable gain.

## Exemple

Refuser un pari pourtant favorable parce que la perte possible paraît plus marquante que le gain équivalent.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Évaluation asymétrique des changements autour d'un point de référence.

## Mécanisme probable

Évaluation asymétrique des changements autour d'un point de référence.

## Analyse critique

L’aversion à la perte n’est ni constante ni universelle. La méta-analyse contrôlée retrouve une asymétrie moyenne, mais sa taille dépend des enjeux, du point de référence, de l’expérience et de la méthode de mesure.

**Conclusion de l’audit :** effet documenté, à ne pas présenter comme une loi générale du comportement.

## Comment le limiter ?

Comparer les scénarios en valeur attendue, expliciter le point de référence et reformuler symétriquement gains et pertes.

## Classement

- Nature scientifique : asymétrie de décision autour d’un point de référence
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Loss_aversion
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Brown, A. L., Imai, T., Vieider, F. M., & Camerer, C. F. (2024). Meta-analysis of empirical estimates of loss aversion. *Journal of Economic Literature*, 62(2), 485–516. https://doi.org/10.1257/jel.20221698

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
