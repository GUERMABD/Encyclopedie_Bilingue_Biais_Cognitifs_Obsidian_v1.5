---
type: biais-cognitif
nom_fr: Biais d'excès de confiance
nom_en: Overconfidence effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: famille d’erreurs métacognitives de confiance
robustesse: bien documenté, mais direction et taille dépendent de la difficulté et de la mesure
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Biais d'excès de confiance

> **English:** Overconfidence effect

## Définition — français

Confiance supérieure à ce que justifient l’exactitude, la position réelle ou la précision des connaissances.

## Definition — English

Confidence exceeding what is warranted by accuracy, actual standing, or knowledge precision.

## Exemple

Une personne attribue 90 % de certitude à des réponses qui ne sont correctes que dans 65 % des cas.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Calibrage imparfait, information limitée et confusion entre facilité subjective et exactitude.

## Mécanisme probable

Calibrage imparfait, information limitée et confusion entre facilité subjective et exactitude.

## Analyse critique

Il faut distinguer surestimation, surplacement et surprécision : elles ne varient pas toujours ensemble. Les tâches difficiles peuvent produire d’autres profils.

**Conclusion de l’audit :** bien documenté, mais direction et taille dépendent de la difficulté et de la mesure.

## Comment le limiter ?

Mesurer le calibrage sur plusieurs décisions et utiliser des intervalles de confiance explicites.

## Classement

- Nature scientifique : famille d’erreurs métacognitives de confiance
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Overconfidence_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Moore, D. A., & Healy, P. J. (2008). The trouble with overconfidence. *Psychological Review*, 115(2), 502–517. https://doi.org/10.1037/0033-295X.115.2.502

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
