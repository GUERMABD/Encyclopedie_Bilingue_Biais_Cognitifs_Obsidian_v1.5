---
type: concept-clinique-mnesique
nom_fr: Rappel euphorique
nom_en: Euphoric recall
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: rappel sélectif des aspects plaisants d’une consommation ou expérience au détriment de ses conséquences négatives
robustesse: concept clinique utile, mais peu standardisé comme biais expérimental autonome; recoupe mémoire autobiographique positive et fading affect bias
---
# Rappel euphorique

> **English:** Euphoric recall

## Définition — français

Rappel surtout positif d’une consommation passée, avec minimisation des dommages, pouvant contribuer au craving et à la rechute.

## Definition — English

Predominantly positive recall of past substance use while minimizing harms, potentially contributing to craving and relapse.

## Exemple

Une personne se remémore l’euphorie d’une soirée mais pas les conflits, pertes ou symptômes qui ont suivi.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Mémoire sélective, état motivationnel et diminution plus rapide de l’affect négatif.

## Mécanisme probable

Mémoire sélective, état motivationnel et diminution plus rapide de l’affect négatif.

## Analyse critique

Le terme est surtout employé en addictologie. Il ne doit pas être présenté comme une loi universelle de la mémoire ni confondu avec tout souvenir positif.

**Conclusion de l’audit :** concept clinique utile, mais peu standardisé comme biais expérimental autonome; recoupe mémoire autobiographique positive et fading affect bias.

## Comment le limiter ?

Consigner simultanément bénéfices perçus et conséquences, utiliser un plan de prévention de rechute et demander un avis clinique.

## Classement

- Nature scientifique : rappel sélectif des aspects plaisants d’une consommation ou expérience au détriment de ses conséquences négatives
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Euphoric_recall
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Substance Abuse and Mental Health Services Administration. (2021). *Treatment for Stimulant Use Disorders*, Chapter 5: Practical Application of Treatment Strategies. NCBI Bookshelf.
- Walker, W. R., Skowronski, J. J., & Thompson, C. P. (2003). Life is pleasant—and memory helps to keep it that way. *Review of General Psychology*, 7(2), 203–210. https://doi.org/10.1037/1089-2680.7.2.203

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
