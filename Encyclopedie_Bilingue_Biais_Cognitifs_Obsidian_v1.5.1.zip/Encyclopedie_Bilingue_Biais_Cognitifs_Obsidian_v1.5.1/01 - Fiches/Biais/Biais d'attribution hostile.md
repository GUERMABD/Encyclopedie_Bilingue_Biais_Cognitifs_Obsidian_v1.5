---
type: biais-cognitif
nom_fr: Biais d'attribution hostile
nom_en: Hostile attribution bias
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais d’interprétation sociale associé à l’agression
robustesse: bien documenté, notamment en psychologie du développement; relation probabiliste et non diagnostique
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
---
# Biais d'attribution hostile

> **English:** Hostile attribution bias

## Définition — français

Tendance à interpréter comme hostiles des actions ambiguës d’autrui.

## Definition — English

The tendency to interpret ambiguous actions by others as hostile.

## Exemple

Dans un couloir bondé, une personne est bousculée accidentellement mais interprète immédiatement le geste comme une provocation volontaire.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attentes de menace, expérience antérieure et traitement rapide des indices sociaux.

## Mécanisme probable

Attentes de menace, expérience antérieure et traitement rapide des indices sociaux.

## Analyse critique

L’association avec l’agressivité ne signifie pas que toute méfiance est pathologique ni qu’un score prédit à lui seul un comportement. Le contexte réel de menace compte.

**Conclusion de l’audit :** bien documenté, notamment en psychologie du développement; relation probabiliste et non diagnostique.

## Comment le limiter ?

Chercher des explications alternatives, vérifier l’intention et différer la réponse lorsque la situation est ambiguë.

## Classement

- Nature scientifique : biais d’interprétation sociale associé à l’agression
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Hostile_attribution_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Dodge, K. A. (1980). Social cognition and children’s aggressive behavior. *Child Development*, 51(1), 162–170. https://doi.org/10.1111/j.1467-8624.1980.tb02522.x

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
