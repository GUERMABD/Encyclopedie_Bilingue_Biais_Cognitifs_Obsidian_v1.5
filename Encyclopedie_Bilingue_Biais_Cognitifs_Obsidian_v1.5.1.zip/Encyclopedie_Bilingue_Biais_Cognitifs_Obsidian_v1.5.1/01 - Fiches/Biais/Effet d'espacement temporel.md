---
type: biais-cognitif
nom_fr: Effet d'espacement temporel
nom_en: Lag effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: interaction entre intervalle d’apprentissage et délai de rétention
robustesse: robuste, mais intervalle optimal dépendant du délai final
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Effet d'espacement temporel

> **English:** Lag effect

## Définition — français

Variation du bénéfice de l’espacement selon la durée séparant les répétitions et le délai avant le test.

## Definition — English

The variation in spacing benefits as a function of the gap between repetitions and the final retention interval.

## Exemple

Pour un examen lointain, des révisions davantage espacées peuvent être préférables à des répétitions rapprochées.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Récupération avec effort, variabilité contextuelle et consolidation.

## Mécanisme probable

Récupération avec effort, variabilité contextuelle et consolidation.

## Analyse critique

Il n’existe pas un intervalle optimal unique. Un espacement trop court ou trop long peut réduire les performances selon le délai de rétention visé.

**Conclusion de l’audit :** robuste, mais intervalle optimal dépendant du délai final.

## Comment le limiter ?

Planifier l’intervalle entre révisions en fonction de la date d’utilisation des connaissances.

## Classement

- Nature scientifique : interaction entre intervalle d’apprentissage et délai de rétention
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Lag_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Cepeda, N. J., Pashler, H., Vul, E., Wixted, J. T., & Rohrer, D. (2006). Distributed practice in verbal recall tasks: A review and quantitative synthesis. *Psychological Bulletin*, 132(3), 354–380. https://doi.org/10.1037/0033-2909.132.3.354

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
