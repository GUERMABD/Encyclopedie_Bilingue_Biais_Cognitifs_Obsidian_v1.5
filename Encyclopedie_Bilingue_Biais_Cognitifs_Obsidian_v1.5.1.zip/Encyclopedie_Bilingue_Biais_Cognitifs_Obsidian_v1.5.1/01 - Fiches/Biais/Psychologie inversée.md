---
type: technique-influence
nom_fr: Psychologie inversée
nom_en: Reverse psychology
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: technique de persuasion cherchant à provoquer la réactance en recommandant l’opposé
robustesse: la réactance est bien documentée; l’efficacité de la technique dite psychologie inversée est variable et peu standardisée
---
# Psychologie inversée

> **English:** Reverse psychology

## Définition — français

Technique consistant à défendre l’action opposée à celle souhaitée afin que la personne réaffirme son autonomie.

## Definition — English

A persuasion tactic that advocates the opposite of the desired action in order to trigger autonomy-restoring resistance.

## Exemple

Dire à quelqu’un qu’il ne devrait surtout pas essayer une activité dans l’espoir qu’il veuille la faire.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Réactance psychologique face à une menace perçue sur la liberté.

## Mécanisme probable

Réactance psychologique face à une menace perçue sur la liberté.

## Analyse critique

Ce n’est pas un biais autonome et la stratégie peut échouer, manipuler ou endommager la confiance.

**Conclusion de l’audit :** la réactance est bien documentée; l’efficacité de la technique dite psychologie inversée est variable et peu standardisée.

## Comment le limiter ?

Privilégier une demande transparente et laisser un choix réel plutôt que tenter une manipulation indirecte.

## Classement

- Nature scientifique : technique de persuasion cherchant à provoquer la réactance en recommandant l’opposé
- Tâche(s) du classement Wikipédia : non repris dans la liste anglaise contrôlée
- Sous-catégorie(s) (« flavors ») : non applicable
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Reverse_psychology
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Rains, S. A. (2013). The nature of psychological reactance revisited: A meta-analytic review. *Human Communication Research*, 39(1), 47–73. https://doi.org/10.1111/j.1468-2958.2012.01443.x

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
