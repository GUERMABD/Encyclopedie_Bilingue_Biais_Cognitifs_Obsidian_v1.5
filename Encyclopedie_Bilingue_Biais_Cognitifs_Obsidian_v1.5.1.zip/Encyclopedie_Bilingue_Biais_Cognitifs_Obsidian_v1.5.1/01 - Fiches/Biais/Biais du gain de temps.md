---
type: biais-cognitif
nom_fr: Biais du gain de temps
nom_en: Time-saving bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Association
codex:
- Manque de sens
aliases:
- Time–saving bias
nature_scientifique: biais d’estimation non linéaire des temps de trajet
robustesse: bien documenté dans des tâches de vitesse; domaine spécifique
---
# Biais du gain de temps

> **English:** Time-saving bias

## Définition — français

Erreur dans l’estimation du temps gagné par une augmentation de vitesse, notamment sous-estimer le gain aux faibles vitesses et le surestimer aux vitesses élevées.

## Definition — English

An error in estimating time saved by increasing speed, often underestimating gains at low speeds and overestimating them at high speeds.

## Exemple

Passer de 30 à 40 km/h paraît moins utile que de 100 à 110 km/h, alors que le premier changement économise davantage de temps sur une même distance.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Utilisation intuitive de la différence de vitesse plutôt que de la relation inverse entre vitesse et temps.

## Mécanisme probable

Utilisation intuitive de la différence de vitesse plutôt que de la relation inverse entre vitesse et temps.

## Analyse critique

Le biais suppose une distance fixe et des vitesses constantes. Dans la circulation réelle, sécurité, congestion et arrêts modifient le calcul.

**Conclusion de l’audit :** bien documenté dans des tâches de vitesse; domaine spécifique.

## Comment le limiter ?

Calculer le temps par distance, par exemple minutes pour 100 km, plutôt que comparer seulement les km/h.

## Classement

- Nature scientifique : biais d’estimation non linéaire des temps de trajet
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Time-saving_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Svenson, O. (2008). Decisions among time saving options: When intuition is strong and wrong. *Acta Psychologica*, 127(2), 501–509. https://doi.org/10.1016/j.actpsy.2007.09.003

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
