---
type: biais-cognitif
nom_fr: Effet d'hypocrisie morale
nom_en: Moral credential effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet de licence ou de crédentialisation morale
robustesse: effets observés mais hétérogènes; coexistence possible avec la cohérence morale
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Association
codex:
- Manque de sens
aliases: []
---
# Effet d'hypocrisie morale

> **English:** Moral credential effect

## Définition — français

Après une action ou une affirmation morale, certaines personnes peuvent se sentir autorisées à adopter ensuite un comportement moins conforme à cette norme.

## Definition — English

After a moral action or statement, some people may feel licensed to behave less consistently with that standard.

## Exemple

Après avoir rappelé une décision non discriminatoire, une personne exprime plus librement une préférence ambiguë défavorable à un groupe.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Crédit moral perçu et protection de l’image de soi.

## Mécanisme probable

Crédit moral perçu et protection de l’image de soi.

## Analyse critique

La littérature distingue licence morale, crédentialisation et cohérence morale; l’action initiale peut aussi renforcer le comportement vertueux. L’effet n’est pas automatique.

**Conclusion de l’audit :** effets observés mais hétérogènes; coexistence possible avec la cohérence morale.

## Comment le limiter ?

Évaluer chaque décision selon ses conséquences et critères propres, sans comptabilité morale compensatoire.

## Classement

- Nature scientifique : effet de licence ou de crédentialisation morale
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Self-licensing
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Monin, B., & Miller, D. T. (2001). Moral credentials and the expression of prejudice. *Journal of Personality and Social Psychology*, 81(1), 33–43. https://doi.org/10.1037/0022-3514.81.1.33

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
