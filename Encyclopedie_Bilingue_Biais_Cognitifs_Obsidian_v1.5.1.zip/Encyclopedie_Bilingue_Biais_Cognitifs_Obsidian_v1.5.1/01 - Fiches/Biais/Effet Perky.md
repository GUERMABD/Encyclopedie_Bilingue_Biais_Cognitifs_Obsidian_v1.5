---
type: effet-perceptif
nom_fr: Effet Perky
nom_en: Perky effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: interaction entre imagerie mentale et perception visuelle
robustesse: effet expérimental documenté, mais dépendant du stimulus, de la tâche et de la force de l’imagerie
---
# Effet Perky

> **English:** Perky effect

## Définition — français

Interférence par laquelle une image mentale réduit la détection ou la précision d’un stimulus visuel réel qui lui ressemble.

## Definition — English

Interference in which visual imagery reduces the detection or accuracy of a similar real visual stimulus.

## Exemple

Imaginer un objet sur une zone de l’écran peut rendre un faible signal réel plus difficile à détecter.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Chevauchement partiel des ressources et représentations mobilisées par l’imagerie et la perception.

## Mécanisme probable

Chevauchement partiel des ressources et représentations mobilisées par l’imagerie et la perception.

## Analyse critique

Il s’agit d’un effet perceptif, non d’une tendance générale au mauvais jugement. Sa taille varie avec la superposition spatiale, la modalité et les instructions.

**Conclusion de l’audit :** effet expérimental documenté, mais dépendant du stimulus, de la tâche et de la force de l’imagerie.

## Comment le limiter ?

Séparer imagination et observation, augmenter le contraste du signal et utiliser des mesures objectives.

## Classement

- Nature scientifique : interaction entre imagerie mentale et perception visuelle
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Perky_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Segal, S. J., & Gordon, P. E. (1969). The Perky effect revisited: Blocking of visual signals by imagery. *Perceptual and Motor Skills*, 28(3), 791–797. https://doi.org/10.2466/pms.1969.28.3.791
- Reeves, A., & Craver-Lemley, C. (2012). Unmasking the Perky effect: Spatial extent of image interference on visual acuity. *Frontiers in Psychology*, 3, 296. https://doi.org/10.3389/fpsyg.2012.00296

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
