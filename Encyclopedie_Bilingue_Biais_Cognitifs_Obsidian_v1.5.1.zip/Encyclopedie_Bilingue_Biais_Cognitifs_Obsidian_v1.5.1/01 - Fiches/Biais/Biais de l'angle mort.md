---
type: biais-metacognitif
nom_fr: Biais de l'angle mort
nom_en: Bias blind spot
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: asymétrie dans l’évaluation des biais de soi et d’autrui
robustesse: effet reproduit, sensible aux mesures et aux formulations utilisées
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Trop d'informations
aliases: []
---
# Biais de l'angle mort

> **English:** Bias blind spot

## Définition — français

Tendance à reconnaître plus facilement les biais chez les autres que dans son propre raisonnement.

## Definition — English

The tendency to identify biases more readily in others than in one's own reasoning.

## Exemple

Se considérer objectif tout en attribuant le désaccord des autres à leurs préjugés.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Accès privilégié à ses intentions, mais pas aux processus automatiques qui influencent son propre jugement.

## Mécanisme probable

Accès privilégié à ses intentions, mais pas aux processus automatiques qui influencent son propre jugement.

## Analyse critique

L’effet décrit une asymétrie entre la facilité à diagnostiquer les biais d’autrui et celle à reconnaître ses propres biais. Connaître le nom d’un biais ne protège pas automatiquement contre lui ; l’ampleur observée dépend toutefois des mesures d’autoévaluation et des scénarios employés.

**Conclusion de l’audit :** biais métacognitif documenté, avec prudence sur sa mesure.

## Comment le limiter ?

Évaluer les procédures de décision plutôt que la seule introspection et rechercher un contradicteur indépendant.

## Classement

- Nature scientifique : asymétrie dans l’évaluation des biais de soi et d’autrui
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Bias_blind_spot
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Pronin, E., Lin, D. Y., & Ross, L. (2002). The bias blind spot: Perceptions of bias in self versus others. *Personality and Social Psychology Bulletin*, 28(3), 369–381. https://doi.org/10.1177/0146167202286008

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
