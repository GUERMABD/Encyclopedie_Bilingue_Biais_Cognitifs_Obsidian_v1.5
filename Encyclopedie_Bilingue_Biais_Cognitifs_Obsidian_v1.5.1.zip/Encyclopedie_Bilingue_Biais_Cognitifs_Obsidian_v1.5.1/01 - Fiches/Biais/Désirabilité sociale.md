---
type: biais-cognitif
nom_fr: Désirabilité sociale
nom_en: Social desirability bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de réponse et de mesure en enquête
robustesse: bien documenté; amplitude très variable selon sensibilité et mode de collecte
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Outcome
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Désirabilité sociale

> **English:** Social desirability bias

## Définition — français

Tendance à fournir des réponses perçues comme socialement acceptables plutôt que totalement fidèles.

## Definition — English

The tendency to give socially acceptable answers rather than fully accurate ones.

## Exemple

Un répondant sous-déclare un comportement stigmatisé dans un entretien en face à face.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Gestion de l’image, peur du jugement et normes perçues.

## Mécanisme probable

Gestion de l’image, peur du jugement et normes perçues.

## Analyse critique

Ce biais concerne principalement la mesure déclarative; il ne prouve pas qu’une réponse particulière est mensongère. Les méthodes indirectes ont aussi leurs limites.

**Conclusion de l’audit :** bien documenté; amplitude très variable selon sensibilité et mode de collecte.

## Comment le limiter ?

Garantir l’anonymat, employer un vocabulaire neutre et comparer plusieurs sources de données.

## Classement

- Nature scientifique : biais de réponse et de mesure en enquête
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Social_desirability_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Krumpal, I. (2013). Determinants of social desirability bias in sensitive surveys: A literature review. *Quality & Quantity*, 47, 2025–2047. https://doi.org/10.1007/s11135-011-9640-9

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
