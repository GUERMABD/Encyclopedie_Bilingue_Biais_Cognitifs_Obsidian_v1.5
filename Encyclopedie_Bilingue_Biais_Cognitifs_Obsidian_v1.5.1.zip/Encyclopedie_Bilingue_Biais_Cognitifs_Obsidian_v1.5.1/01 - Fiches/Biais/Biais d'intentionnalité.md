---
type: biais-cognitif
nom_fr: Biais d'intentionnalité
nom_en: Intentionality bias
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: biais d’attribution causale
robustesse: documenté dans plusieurs tâches; dépend du contexte et de l’ambiguïté
---
# Biais d'intentionnalité

> **English:** Intentionality bias

## Définition — français

Tendance à privilégier une explication intentionnelle pour un comportement ou un événement ambigu, même lorsqu’une cause accidentelle est plausible.

## Definition — English

The tendency to favor an intentional explanation for ambiguous behavior or events even when an accidental cause is plausible.

## Exemple

Une personne qui renverse un objet est jugée l’avoir fait exprès avant que le contexte soit examiné.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Traitement rapide des intentions et correction ultérieure insuffisante.

## Mécanisme probable

Traitement rapide des intentions et correction ultérieure insuffisante.

## Analyse critique

Les actions humaines sont souvent intentionnelles; le biais concerne une sur-attribution, non toute inférence d’intention. Les formulations et le temps de réponse influencent l’effet.

**Conclusion de l’audit :** documenté dans plusieurs tâches; dépend du contexte et de l’ambiguïté.

## Comment le limiter ?

Lister une cause intentionnelle et une cause accidentelle, puis rechercher les indices qui les différencient.

## Classement

- Nature scientifique : biais d’attribution causale
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Intentionality_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Rosset, E. (2008). It’s no accident: Our bias for intentional explanations. *Cognition*, 108(3), 771–780. https://doi.org/10.1016/j.cognition.2008.07.001

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
