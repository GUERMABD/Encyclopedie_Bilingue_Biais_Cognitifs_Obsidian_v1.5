---
type: biais-cognitif
nom_fr: Justification du système
nom_en: System justification
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: théorie motivationnelle et famille d’effets sociaux
robustesse: corpus important mais construit et interprétations causales débattus
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex:
- Nécessité d'agir rapidement
aliases: []
---
# Justification du système

> **English:** System justification

## Définition — français

Tendance proposée à défendre ou rationaliser l’ordre social existant, y compris lorsqu’il désavantage certaines personnes.

## Definition — English

A proposed tendency to defend or rationalize existing social arrangements, sometimes even when they are personally disadvantageous.

## Exemple

Une inégalité durable est expliquée comme nécessaire ou méritée simplement parce qu’elle fait partie du système établi.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Besoin de prévisibilité, réduction de la dissonance et légitimation des institutions.

## Mécanisme probable

Besoin de prévisibilité, réduction de la dissonance et légitimation des institutions.

## Analyse critique

La théorie regroupe plusieurs processus et ne permet pas d’inférer la motivation d’une personne à partir d’une opinion isolée. Les effets varient avec l’idéologie, le contexte et la menace.

**Conclusion de l’audit :** corpus important mais construit et interprétations causales débattus.

## Comment le limiter ?

Séparer description, justification morale et intérêt personnel; comparer l’ordre actuel à des alternatives concrètes.

## Classement

- Nature scientifique : théorie motivationnelle et famille d’effets sociaux
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/System_justification
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Jost, J. T., & Banaji, M. R. (1994). The role of stereotyping in system-justification and the production of false consciousness. *British Journal of Social Psychology*, 33(1), 1–27. https://doi.org/10.1111/j.2044-8309.1994.tb01008.x

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
