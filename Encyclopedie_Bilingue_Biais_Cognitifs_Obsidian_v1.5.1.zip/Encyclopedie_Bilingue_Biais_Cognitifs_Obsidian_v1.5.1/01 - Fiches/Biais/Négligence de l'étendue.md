---
type: biais-cognitif
nom_fr: Négligence de l'étendue
nom_en: Scope neglect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: insensibilité quantitative dans l’évaluation
robustesse: répliquée dans plusieurs paradigmes; non universelle et sensible au mode de présentation
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex: []
aliases: []
---
# Négligence de l'étendue

> **English:** Scope neglect

## Définition — français

Faible variation d’une évaluation ou d’un consentement à payer lorsque l’étendue du bénéfice change fortement.

## Definition — English

A weak change in valuation or willingness to pay when the scale of the benefit changes substantially.

## Exemple

Des personnes proposent des montants proches pour protéger deux mille ou deux cent mille animaux.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Évaluation affective du bien moral, représentation imprécise des quantités et faible évaluabilité séparée.

## Mécanisme probable

Évaluation affective du bien moral, représentation imprécise des quantités et faible évaluabilité séparée.

## Analyse critique

L’insensibilité n’est pas toujours complète et peut diminuer lorsque les quantités sont comparées directement ou rendues concrètes.

**Conclusion de l’audit :** répliquée dans plusieurs paradigmes; non universelle et sensible au mode de présentation.

## Comment le limiter ?

Présenter les ordres de grandeur côte à côte et calculer une valeur par unité lorsque cela a du sens.

## Classement

- Nature scientifique : insensibilité quantitative dans l’évaluation
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Scope_neglect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kahneman, D., & Knetsch, J. L. (1992). Valuing public goods: The purchase of moral satisfaction. *Journal of Environmental Economics and Management*, 22(1), 57–70. https://doi.org/10.1016/0095-0696(92)90019-S

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
