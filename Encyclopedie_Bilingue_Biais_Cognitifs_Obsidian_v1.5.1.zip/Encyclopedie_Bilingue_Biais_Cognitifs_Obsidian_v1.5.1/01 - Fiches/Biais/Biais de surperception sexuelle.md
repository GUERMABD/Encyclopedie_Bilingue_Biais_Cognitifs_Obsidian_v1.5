---
type: biais-cognitif
nom_fr: Biais de surperception sexuelle
nom_en: Sexual overperception bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais d’inférence d’intérêt sexuel étudié dans les interactions hétérosexuelles
robustesse: preuves d’un écart moyen dans certains échantillons; forte dépendance culturelle, méthodologique et situationnelle
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
---
# Biais de surperception sexuelle

> **English:** Sexual overperception bias

## Définition — français

Tendance proposée, surtout chez certains hommes, à surestimer l’intérêt sexuel exprimé par une femme à partir de signaux ambigus.

## Definition — English

A proposed tendency, especially among some men, to overestimate a woman’s sexual interest from ambiguous cues.

## Exemple

Lors d’une conversation amicale, une personne interprète un sourire et une attention polie comme une invitation sexuelle, sans autre élément concordant.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Ambiguïté des signaux, attentes, motivation et seuil de détection.

## Mécanisme probable

Ambiguïté des signaux, attentes, motivation et seuil de détection.

## Analyse critique

Le résultat moyen ne s’applique pas à chaque personne et ne valide pas automatiquement une explication évolutionnaire. Les mesures reposent souvent sur des scénarios ou auto-évaluations.

**Conclusion de l’audit :** preuves d’un écart moyen dans certains échantillons; forte dépendance culturelle, méthodologique et situationnelle.

## Comment le limiter ?

Privilégier une communication explicite et ne jamais traiter une interprétation comme un consentement.

## Classement

- Nature scientifique : biais d’inférence d’intérêt sexuel étudié dans les interactions hétérosexuelles
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Sexual_overperception_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Haselton, M. G. (2003). The sexual overperception bias: Evidence of a systematic bias in men from a survey of naturally occurring events. *Journal of Personality and Social Psychology*, 85(1), 34–47. https://doi.org/10.1037/0022-3514.85.1.34

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
