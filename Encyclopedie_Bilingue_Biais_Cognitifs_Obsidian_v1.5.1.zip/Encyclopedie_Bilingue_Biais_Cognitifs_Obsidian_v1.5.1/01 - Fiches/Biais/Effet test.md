---
type: biais-cognitif
nom_fr: Effet test
nom_en: Testing effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: bénéfice d’apprentissage par récupération
robustesse: robuste pour la rétention différée, sous conditions de correction et de difficulté adaptées
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Effet test

> **English:** Testing effect

## Définition — français

Amélioration de la rétention à long terme produite par le fait de récupérer activement l’information.

## Definition — English

Improved long-term retention produced by actively retrieving information.

## Exemple

Se tester sans regarder ses notes améliore davantage la mémoire différée qu’une relecture équivalente.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Renforcement des voies de récupération et diagnostic des lacunes.

## Mécanisme probable

Renforcement des voies de récupération et diagnostic des lacunes.

## Analyse critique

Un test sans retour peut consolider des erreurs. Les bénéfices dépendent du délai, du format et du niveau de réussite.

**Conclusion de l’audit :** robuste pour la rétention différée, sous conditions de correction et de difficulté adaptées.

## Comment le limiter ?

Utiliser des tests de rappel avec correction immédiate et répétition espacée.

## Classement

- Nature scientifique : bénéfice d’apprentissage par récupération
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Testing_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Roediger, H. L., & Karpicke, J. D. (2006). Test-enhanced learning: Taking memory tests improves long-term retention. *Psychological Science*, 17(3), 249–255. https://doi.org/10.1111/j.1467-9280.2006.01693.x

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
