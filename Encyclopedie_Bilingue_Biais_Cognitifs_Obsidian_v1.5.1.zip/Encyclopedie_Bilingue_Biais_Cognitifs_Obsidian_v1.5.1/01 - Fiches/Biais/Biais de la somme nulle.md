---
type: biais-cognitif
nom_fr: Biais de la somme nulle
nom_en: Zero-sum bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais de représentation des gains et ressources
robustesse: documenté expérimentalement mais base plus étroite que les croyances politiques générales à somme nulle
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases:
- Zero sum bias
---
# Biais de la somme nulle

> **English:** Zero-sum bias

## Définition — français

Tendance à percevoir une situation comme une compétition où le gain de l’un implique nécessairement une perte équivalente pour l’autre, même lorsque les ressources ne sont pas fixes.

## Definition — English

The tendency to perceive a situation as zero-sum even when one party’s gain need not require an equivalent loss for another.

## Exemple

Deux équipes refusent un échange mutuellement avantageux parce que chacune suppose que l’avantage de l’autre lui coûte forcément autant.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Modèle mental de compétition et omission des gains communs ou de la création de valeur.

## Mécanisme probable

Modèle mental de compétition et omission des gains communs ou de la création de valeur.

## Analyse critique

Certaines situations sont réellement à somme nulle. Le biais ne peut être affirmé qu’après examen des contraintes et des externalités.

**Conclusion de l’audit :** documenté expérimentalement mais base plus étroite que les croyances politiques générales à somme nulle.

## Comment le limiter ?

Écrire explicitement les gains, pertes, ressources créées et effets sur les tiers pour chaque option.

## Classement

- Nature scientifique : biais de représentation des gains et ressources
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Zero-sum_thinking
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Meegan, D. V. (2010). Zero-sum bias: Perceived competition despite unlimited resources. *Frontiers in Psychology*, 1, 191. https://doi.org/10.3389/fpsyg.2010.00191

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
