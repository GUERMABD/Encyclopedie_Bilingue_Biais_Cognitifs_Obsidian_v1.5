---
type: biais-cognitif
nom_fr: Polarisation de groupe
nom_en: Groupshift
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: phénomène de décision et d’opinion au niveau du groupe
robustesse: solidement documenté; direction et ampleur dépendent de la position initiale et de la dynamique de groupe
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Polarisation de groupe

> **English:** Groupshift

## Définition — français

Après discussion, un groupe peut adopter une position plus extrême dans la direction déjà favorisée par ses membres.

## Definition — English

After discussion, a group may move toward a more extreme version of its members’ initially favored position.

## Exemple

Un groupe légèrement favorable à une mesure devient nettement plus favorable après un débat entre personnes partageant cette orientation.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Arguments persuasifs, comparaison sociale et renforcement d’une identité commune.

## Mécanisme probable

Arguments persuasifs, comparaison sociale et renforcement d’une identité commune.

## Analyse critique

La discussion ne polarise pas toujours : désaccord interne, règles délibératives et informations nouvelles peuvent modérer ou inverser le déplacement.

**Conclusion de l’audit :** solidement documenté; direction et ampleur dépendent de la position initiale et de la dynamique de groupe.

## Comment le limiter ?

Introduire des opinions indépendantes, nommer un contradicteur et recueillir les jugements avant et après discussion.

## Classement

- Nature scientifique : phénomène de décision et d’opinion au niveau du groupe
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Groupshift
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Isenberg, D. J. (1986). Group polarization: A critical review and meta-analysis. *Journal of Personality and Social Psychology*, 50(6), 1141–1151. https://doi.org/10.1037/0022-3514.50.6.1141

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
