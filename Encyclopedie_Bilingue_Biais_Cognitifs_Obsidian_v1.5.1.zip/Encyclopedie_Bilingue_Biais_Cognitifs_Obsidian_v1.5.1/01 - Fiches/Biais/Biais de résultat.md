---
type: biais-cognitif
nom_fr: Biais de résultat
nom_en: Outcome bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: biais rétrospectif dans l’évaluation d’une décision
robustesse: robuste dans de nombreux jugements; dépendant de la connaissance du résultat et du domaine
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Outcome
codex:
- Manque de sens
aliases: []
---
# Biais de résultat

> **English:** Outcome bias

## Définition — français

Évaluer la qualité d’une décision passée à partir de son résultat plutôt qu’à partir des informations disponibles au moment du choix.

## Definition — English

Evaluating a past decision by its outcome rather than by the information available when it was made.

## Exemple

Une décision prudente est qualifiée de mauvaise parce qu’un événement improbable s’est produit.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Substitution du résultat observable à la qualité ex ante du processus.

## Mécanisme probable

Substitution du résultat observable à la qualité ex ante du processus.

## Analyse critique

Le résultat reste une information utile pour apprendre. Le biais consiste à l’utiliser comme preuve suffisante de la qualité initiale sans tenir compte des probabilités.

**Conclusion de l’audit :** robuste dans de nombreux jugements; dépendant de la connaissance du résultat et du domaine.

## Comment le limiter ?

Conserver le raisonnement et les probabilités avant décision, puis auditer séparément processus et résultat.

## Classement

- Nature scientifique : biais rétrospectif dans l’évaluation d’une décision
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Outcome_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Baron, J., & Hershey, J. C. (1988). Outcome bias in decision evaluation. *Journal of Personality and Social Psychology*, 54(4), 569–579. https://doi.org/10.1037/0022-3514.54.4.569

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
