---
type: effet-mnesique
nom_fr: Effet du suffixe
nom_en: Suffix effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
nature_scientifique: dégradation du rappel sériel auditif par un élément terminal non pertinent
robustesse: effet classique robuste dans les conditions auditives appropriées, avec fortes contraintes de modalité et de similarité
---
# Effet du suffixe

> **English:** Suffix effect

## Définition — français

Diminution du rappel des derniers éléments d’une liste auditive lorsqu’un son ou mot non pertinent est ajouté à la fin.

## Definition — English

Reduced recall of the final items in an auditory list when an irrelevant sound or word is appended.

## Exemple

Après une série de chiffres, le mot « fin » réduit le rappel des derniers chiffres.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Interférence avec les représentations auditives récentes et avec l’organisation sérielle.

## Mécanisme probable

Interférence avec les représentations auditives récentes et avec l’organisation sérielle.

## Analyse critique

Il s’agit d’un effet de mémoire sensorielle et sérielle, non d’un biais de raisonnement.

**Conclusion de l’audit :** effet classique robuste dans les conditions auditives appropriées, avec fortes contraintes de modalité et de similarité.

## Comment le limiter ?

Éviter les signaux terminaux similaires aux items à mémoriser ou les séparer clairement.

## Classement

- Nature scientifique : dégradation du rappel sériel auditif par un élément terminal non pertinent
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/List_of_cognitive_biases#Suffix_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Crowder, R. G., & Morton, J. (1969). Precategorical acoustic storage (PAS). *Perception & Psychophysics*, 5(6), 365–373. https://doi.org/10.3758/BF03210660
- Morton, J., Crowder, R. G., & Prussin, H. A. (1971). Experiments with the stimulus suffix effect. *Journal of Experimental Psychology*, 91(1), 169–190. https://doi.org/10.1037/h0031844

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
