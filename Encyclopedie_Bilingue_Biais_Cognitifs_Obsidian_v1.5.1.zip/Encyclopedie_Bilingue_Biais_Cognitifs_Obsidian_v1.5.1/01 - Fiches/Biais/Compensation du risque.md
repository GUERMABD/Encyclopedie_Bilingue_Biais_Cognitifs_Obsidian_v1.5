---
type: biais-cognitif
nom_fr: Compensation du risque
nom_en: Risk compensation
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: adaptation comportementale à une modification du risque perçu
robustesse: preuves mixtes et très contextuelles; compensation complète rarement démontrée
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex:
- Nécessité d'agir rapidement
aliases:
- Effet Peltzman
- Peltzman effect
---
# Compensation du risque

> **English:** Risk compensation

## Définition — français

Modification du comportement après une mesure de sécurité, pouvant réduire une partie du bénéfice attendu si la personne se sent davantage protégée.

## Definition — English

A behavioral adjustment after a safety measure that may offset part of its expected benefit when people feel safer.

## Exemple

Un conducteur augmente légèrement sa vitesse après l’adoption d’un équipement de protection.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Risque cible, perception de sécurité et arbitrage entre performance et protection.

## Mécanisme probable

Risque cible, perception de sécurité et arbitrage entre performance et protection.

## Analyse critique

L’hypothèse ne permet pas de conclure qu’une mesure de sécurité est inutile. La compensation peut être absente, partielle ou varier entre populations.

**Conclusion de l’audit :** preuves mixtes et très contextuelles; compensation complète rarement démontrée.

## Comment le limiter ?

Mesurer les résultats nets et les comportements réels après l’intervention, plutôt que supposer une annulation automatique.

## Classement

- Nature scientifique : adaptation comportementale à une modification du risque perçu
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Risk_compensation
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Peltzman, S. (1975). The effects of automobile safety regulation. *Journal of Political Economy*, 83(4), 677–725. https://doi.org/10.1086/260352

- Hedlund, J. (2000). Risky business: Safety regulations, risk compensation, and individual behavior. *Injury Prevention*, 6(2), 82–90. https://doi.org/10.1136/ip.6.2.82

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
