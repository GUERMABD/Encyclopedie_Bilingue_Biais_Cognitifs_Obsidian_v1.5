---
type: etiquette-metacognitive
nom_fr: Sophisme G. I. Joe
nom_en: G. I. Joe fallacy
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: idée selon laquelle connaître un biais ne suffit généralement pas à l’éliminer
robustesse: conclusion générale plausible et soutenue par des échecs de sensibilisation, mais l’étiquette est récente et non un sophisme logique formalisé
---
# Sophisme G. I. Joe

> **English:** G. I. Joe fallacy

## Définition — français

Croyance que savoir qu’un biais existe suffit à empêcher son influence.

## Definition — English

The belief that knowing about a bias is sufficient to prevent it from influencing behavior.

## Exemple

Une formation explique le biais de confirmation, puis suppose sans mesure que les décisions seront désormais corrigées.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Écart entre connaissance déclarative, détection en situation et contrôle comportemental.

## Mécanisme probable

Écart entre connaissance déclarative, détection en situation et contrôle comportemental.

## Analyse critique

L’information peut aider lorsqu’elle est accompagnée de procédures, d’incitations et de retours. Le terme « sophisme » est ici métaphorique.

**Conclusion de l’audit :** conclusion générale plausible et soutenue par des échecs de sensibilisation, mais l’étiquette est récente et non un sophisme logique formalisé.

## Comment le limiter ?

Transformer la sensibilisation en checklist, changement de processus et mesure avant-après.

## Classement

- Nature scientifique : idée selon laquelle connaître un biais ne suffit généralement pas à l’éliminer
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/G._I._Joe_fallacy
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kristal, A. S., & Santos, L. R. (2021). *G.I. Joe phenomena: Understanding the limits of metacognitive awareness on debiasing*. Harvard Business School Working Paper 21-084.

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
