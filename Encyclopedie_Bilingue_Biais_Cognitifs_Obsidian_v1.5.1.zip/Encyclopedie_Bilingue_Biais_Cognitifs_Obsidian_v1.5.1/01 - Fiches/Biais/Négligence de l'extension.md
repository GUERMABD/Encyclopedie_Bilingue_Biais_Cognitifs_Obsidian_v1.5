---
type: famille-biais-evaluation
nom_fr: Négligence de l'extension
nom_en: Extension neglect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: insensibilité insuffisante à la quantité ou à l’étendue lors d’une évaluation
robustesse: famille d’effets bien documentée dans certains paradigmes affectifs; sensibilité retrouvée selon présentation et mode de calcul
---
# Négligence de l'extension

> **English:** Extension neglect

## Définition — français

Tendance à accorder trop peu de poids à la taille d’un ensemble ou à l’ampleur d’un résultat.

## Definition — English

The tendency to give too little weight to the size of a set or the magnitude of an outcome.

## Exemple

La volonté de donner change peu lorsqu’un programme sauve plusieurs fois plus d’animaux.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Évaluation affective d’un prototype, difficulté de représentation des nombres et substitution d’attribut.

## Mécanisme probable

Évaluation affective d’un prototype, difficulté de représentation des nombres et substitution d’attribut.

## Analyse critique

Il s’agit d’une catégorie englobante. La négligence de l’étendue est l’un de ses cas; elles ne sont pas strictement synonymes.

**Conclusion de l’audit :** famille d’effets bien documentée dans certains paradigmes affectifs; sensibilité retrouvée selon présentation et mode de calcul.

## Comment le limiter ?

Présenter les quantités côte à côte, calculer une valeur par unité et vérifier la proportionnalité.

## Classement

- Nature scientifique : insensibilité insuffisante à la quantité ou à l’étendue lors d’une évaluation
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Extension_neglect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Hsee, C. K., & Rottenstreich, Y. (2004). Music, pandas, and muggers: On the affective psychology of value. *Journal of Experimental Psychology: General*, 133(1), 23–30. https://doi.org/10.1037/0096-3445.133.1.23

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
