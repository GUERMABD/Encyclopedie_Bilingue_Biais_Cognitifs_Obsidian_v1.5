---
type: biais-cognitif
nom_fr: Biais d'autocomplaisance
nom_en: Self-serving bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases:
- Self–serving bias
nature_scientifique: biais attributionnel
robustesse: établie avec variations culturelles et contextuelles
---
# Biais d'autocomplaisance

> **English:** Self-serving bias

## Définition — français

Tendance à attribuer plus volontiers ses réussites à des causes internes et ses échecs à des causes externes.

## Definition — English

The tendency to attribute positive outcomes more to internal causes and negative outcomes more to external causes.

## Exemple

Une personne explique sa réussite par ses compétences, mais son échec par un sujet injuste ou de mauvaises circonstances.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Protection de l’image de soi, attentes préalables et traitement asymétrique des informations sur la réussite et l’échec.

## Mécanisme probable

Protection de l’image de soi, attentes préalables et traitement asymétrique des informations sur la réussite et l’échec.

## Analyse critique

La tendance moyenne est soutenue par une large méta-analyse, mais son ampleur varie selon l’âge, la culture, la santé psychologique et la situation. Elle ne prouve pas que l’attribution externe d’un échec est toujours fausse.

**Conclusion de l’audit :** établie avec variations culturelles et contextuelles.

## Comment le limiter ?

Définir avant le résultat les causes possibles, comparer plusieurs événements similaires et demander une évaluation indépendante.

## Classement

- Nature scientifique : biais attributionnel
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Self-serving_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Miller, D. T., & Ross, M. (1975). Self-serving biases in the attribution of causality: Fact or fiction? *Psychological Bulletin*, 82(2), 213–225. https://doi.org/10.1037/h0076486
- Mezulis, A. H., Abramson, L. Y., Hyde, J. S., & Hankin, B. L. (2004). Is there a universal positivity bias in attributions? *Psychological Bulletin*, 130(5), 711–747. https://doi.org/10.1037/0033-2909.130.5.711

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
