---
type: biais-cognitif
nom_fr: Effet de compromis
nom_en: Compromise effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex: []
aliases: []
nature_scientifique: effet de contexte dans le choix
robustesse: établie mais contextuelle
---
# Effet de compromis

> **English:** Compromise effect

## Définition — français

Augmentation de l’attractivité d’une option lorsqu’elle devient intermédiaire entre des alternatives plus extrêmes.

## Definition — English

An increase in an option’s attractiveness when it becomes the intermediate alternative between more extreme choices.

## Exemple

Une offre moyenne paraît plus raisonnable lorsqu’elle est encadrée par une offre très limitée et une offre très coûteuse.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : L’option intermédiaire est plus facile à justifier et réduit le risque de paraître choisir un extrême.

## Mécanisme probable

L’option intermédiaire est plus facile à justifier et réduit le risque de paraître choisir un extrême.

## Analyse critique

Il s’agit d’un effet de composition du choix, non d’une règle universelle. Il dépend des attributs, de l’incertitude sur les préférences et de la nécessité de justifier la décision.

**Conclusion de l’audit :** établie mais contextuelle.

## Comment le limiter ?

Définir les besoins et seuils avant d’afficher les options, comparer les valeurs absolues et tester le choix après retrait des alternatives extrêmes.

## Classement

- Nature scientifique : effet de contexte dans le choix
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : absent du Codex historique
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Compromise_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Simonson, I. (1989). Choice Based on Reasons: The Case of Attraction and Compromise Effects. *Journal of Consumer Research*, 16(2), 158–174. https://doi.org/10.1086/209205

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
