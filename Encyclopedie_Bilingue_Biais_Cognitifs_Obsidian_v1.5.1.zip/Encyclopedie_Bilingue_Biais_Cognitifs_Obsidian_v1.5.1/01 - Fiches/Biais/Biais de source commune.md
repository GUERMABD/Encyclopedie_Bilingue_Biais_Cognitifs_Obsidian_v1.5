---
type: biais-cognitif
nom_fr: Biais de source commune
nom_en: Common source bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: biais méthodologique de mesure
robustesse: problème reconnu mais souvent surestimé ou mal diagnostiqué; pas un biais cognitif individuel
---
# Biais de source commune

> **English:** Common source bias

## Définition — français

Corrélation artificiellement accrue lorsque prédicteurs et résultats sont mesurés auprès de la même source, au même moment ou avec une méthode commune.

## Definition — English

Artificially inflated associations when predictors and outcomes are measured from the same source, at the same time, or with a common method.

## Exemple

Un même questionnaire demande aux salariés d’évaluer le management et leur performance; le style de réponse influence les deux scores.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Variance de méthode partagée, désirabilité sociale, humeur et formulation commune.

## Mécanisme probable

Variance de méthode partagée, désirabilité sociale, humeur et formulation commune.

## Analyse critique

Il s’agit d’un risque de conception et non d’une explication automatique de toute corrélation auto-déclarée. Les tests statistiques après coup ne remplacent pas une meilleure collecte.

**Conclusion de l’audit :** problème reconnu mais souvent surestimé ou mal diagnostiqué; pas un biais cognitif individuel.

## Comment le limiter ?

Séparer les sources et les temps de mesure, utiliser des données objectives ou multi-évaluateurs et prévoir le risque dès le protocole.

## Classement

- Nature scientifique : biais méthodologique de mesure
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Common_source_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Favero, N., & Bullock, J. B. (2015). How (not) to solve the problem: An evaluation of scholarly responses to common source bias. *Journal of Public Administration Research and Theory*, 25(1), 285–308. https://doi.org/10.1093/jopart/muu020

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
