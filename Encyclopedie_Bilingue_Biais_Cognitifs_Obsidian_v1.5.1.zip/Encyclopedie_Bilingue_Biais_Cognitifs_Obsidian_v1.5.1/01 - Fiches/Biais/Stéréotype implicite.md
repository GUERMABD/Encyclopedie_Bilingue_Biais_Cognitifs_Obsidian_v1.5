---
type: construit-de-cognition-sociale
nom_fr: Stéréotype implicite
nom_en: Implicit stereotype
statut_fr: nom français attesté dans le Codex; aucune page française individuelle validée dans cette édition
traduction: traduction du Codex précisée scientifiquement
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Limites de la mémoire
aliases: []
nature_scientifique: stéréotype ou association sociale opérant sans rapport conscient direct
robustesse: famille de phénomènes documentée; mesure et portée comportementale variables
---
# Stéréotype implicite

> **English:** Implicit stereotype

## Définition — français

Association ou attribution stéréotypée concernant un groupe social qui peut être activée ou mesurée sans déclaration consciente équivalente.

## Definition — English

A stereotypic association or attribution concerning a social group that can be activated or measured without an equivalent conscious report.

## Exemple

Une association automatique entre un groupe et un domaine professionnel peut apparaître dans une tâche de temps de réaction malgré une déclaration explicite égalitaire.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Apprentissage associatif, exposition culturelle, catégorisation sociale et contexte d’activation peuvent contribuer aux réponses implicites.

## Mécanisme probable

Apprentissage associatif, exposition culturelle, catégorisation sociale et contexte d’activation peuvent contribuer aux réponses implicites.

## Analyse critique

Il s’agit d’un construit large, non d’un effet unique. Les mesures implicites ne sont pas des lectures directes d’une croyance inconsciente stable et leur lien avec le comportement varie selon les domaines, les critères et les situations.

**Conclusion de l’audit :** construit documenté, mais non réductible à un test ou à un comportement certain.

## Comment le limiter ou l’étudier correctement ?

Distinguer association mesurée, attitude explicite et comportement ; utiliser des mesures convergentes et préciser le contexte.

## Classement

- Nature scientifique : stéréotype ou association sociale opérant sans rapport conscient direct
- Tâche(s) du classement Wikipédia : non repris dans la liste anglaise contrôlée
- Sous-catégorie(s) (« flavors ») : non applicable
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; aucune page française individuelle validée dans cette édition

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Implicit_stereotype
- Français : aucune page individuelle équivalente validée dans cette édition ; résolution complémentaire prévue via Wikidata.

## Références scientifiques contrôlées

- Greenwald, A. G., & Banaji, M. R. (1995). Implicit social cognition: Attitudes, self-esteem, and stereotypes. *Psychological Review*, 102(1), 4–27. https://doi.org/10.1037/0033-295X.102.1.4
- Greenwald, A. G., McGhee, D. E., & Schwartz, J. L. K. (1998). Measuring individual differences in implicit cognition: The Implicit Association Test. *Journal of Personality and Social Psychology*, 74(6), 1464–1480. https://doi.org/10.1037/0022-3514.74.6.1464

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
