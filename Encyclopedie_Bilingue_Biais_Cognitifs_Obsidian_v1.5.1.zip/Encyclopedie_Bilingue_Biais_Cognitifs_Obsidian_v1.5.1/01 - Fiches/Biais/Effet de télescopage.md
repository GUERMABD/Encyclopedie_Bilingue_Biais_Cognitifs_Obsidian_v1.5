---
type: biais-mnesique
nom_fr: Effet de télescopage
nom_en: Telescoping effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Manque de sens
aliases: []
nature_scientifique: erreur de datation d’événements autobiographiques
robustesse: phénomène documenté, avec effets de frontière et incertitude de datation; direction variable selon l’ancienneté
---
# Effet de télescopage

> **English:** Telescoping effect

## Définition — français

Déplacement temporel d’un souvenir, souvent un événement ancien rappelé comme plus récent ou un événement récent comme plus éloigné.

## Definition — English

A temporal displacement of a memory, often recalling an old event as more recent or a recent event as more distant.

## Exemple

Une consultation vieille de dix-huit mois est située par erreur dans les douze derniers mois.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Incertitude de datation, reconstruction et limites de la période interrogée.

## Mécanisme probable

Incertitude de datation, reconstruction et limites de la période interrogée.

## Analyse critique

Le télescopage n’est pas une simple compression uniforme du temps; les erreurs dépendent de la fenêtre de rappel et des repères disponibles.

**Conclusion de l’audit :** phénomène documenté, avec effets de frontière et incertitude de datation; direction variable selon l’ancienneté.

## Comment le limiter ?

Utiliser des calendriers, des événements repères et des documents datés.

## Classement

- Nature scientifique : erreur de datation d’événements autobiographiques
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Telescoping_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Rubin, D. C., & Baddeley, A. D. (1989). Telescoping is not time compression: A model of the dating of autobiographical events. *Memory & Cognition*, 17(6), 653–661. https://doi.org/10.3758/BF03202626

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
