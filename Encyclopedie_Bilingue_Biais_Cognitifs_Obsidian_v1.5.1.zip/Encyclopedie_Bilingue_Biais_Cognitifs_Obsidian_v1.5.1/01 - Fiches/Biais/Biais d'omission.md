---
type: biais-cognitif
nom_fr: Biais d'omission
nom_en: Omission bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Inertia
codex:
- Trop d'informations
aliases: []
nature_scientifique: biais de jugement moral et décisionnel
robustesse: établie dans certains scénarios, dépendante du contexte
---
# Biais d'omission

> **English:** Omission bias

## Définition — français

Tendance à juger une conséquence dommageable moins grave lorsqu’elle résulte d’une omission que lorsqu’elle résulte d’une action, à résultat comparable.

## Definition — English

The tendency to judge a harmful outcome as less serious when caused by omission than by action, other things being comparable.

## Exemple

Refuser une intervention qui réduit le risque global parce que son rare dommage serait causé par une action, alors que l’inaction expose à un risque supérieur.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Responsabilité perçue, causalité directe, regret anticipé et norme de non-intervention.

## Mécanisme probable

Responsabilité perçue, causalité directe, regret anticipé et norme de non-intervention.

## Analyse critique

La distinction action–omission peut être moralement ou juridiquement pertinente dans certains contextes. Le biais apparaît lorsqu’elle est appliquée alors que les conséquences et responsabilités pertinentes sont comparables.

**Conclusion de l’audit :** établie dans certains scénarios, dépendante du contexte.

## Comment le limiter ?

Comparer explicitement les conséquences de l’action et de l’inaction, y compris leurs probabilités, et définir à l’avance le critère de responsabilité.

## Classement

- Nature scientifique : biais de jugement moral et décisionnel
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Omission_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Ritov, I., & Baron, J. (1990). Reluctance to vaccinate: Omission bias and ambiguity. *Journal of Behavioral Decision Making*, 3(4), 263–277. https://doi.org/10.1002/bdm.3960030404

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
