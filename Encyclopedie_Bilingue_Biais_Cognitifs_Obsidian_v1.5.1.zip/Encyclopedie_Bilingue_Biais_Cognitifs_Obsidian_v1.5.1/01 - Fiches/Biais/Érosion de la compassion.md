---
type: effet-affectif-decision
nom_fr: Érosion de la compassion
nom_en: Compassion fade
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: diminution de la réponse affective ou du don lorsque le nombre de victimes augmente
robustesse: effet documenté dans plusieurs expériences, mais modulé par cadrage, identification et représentation du groupe
---
# Érosion de la compassion

> **English:** Compassion fade

## Définition — français

Diminution de l’émotion compatissante et parfois de l’aide lorsque le nombre de personnes en détresse augmente.

## Definition — English

A decline in compassionate affect and sometimes helping as the number of people in need increases.

## Exemple

Un don est plus élevé pour un enfant identifié que pour deux enfants présentés séparément.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Limites de l’affect, difficulté à représenter les grands nombres et régulation émotionnelle.

## Mécanisme probable

Limites de l’affect, difficulté à représenter les grands nombres et régulation émotionnelle.

## Analyse critique

L’effet ne signifie pas que les humains sont incapables d’aider collectivement. Une présentation unifiée ou des règles de décision peuvent le réduire.

**Conclusion de l’audit :** effet documenté dans plusieurs expériences, mais modulé par cadrage, identification et représentation du groupe.

## Comment le limiter ?

Associer récits individuels et données agrégées, puis décider selon l’impact marginal mesuré.

## Classement

- Nature scientifique : diminution de la réponse affective ou du don lorsque le nombre de victimes augmente
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Compassion_fade
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Västfjäll, D., Slovic, P., Mayorga, M., & Peters, E. (2014). Compassion fade: Affect and charity are greatest for a single child in need. *PLOS ONE*, 9(6), e100115. https://doi.org/10.1371/journal.pone.0100115

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
