---
type: effet-de-repetition
nom_fr: Effet de vérité illusoire
nom_en: Illusory truth effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: augmentation de la crédibilité perçue d’une affirmation après répétition ou familiarisation
robustesse: effet robuste en moyenne, avec variations selon le contenu, la connaissance et les conditions de présentation
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex:
- Trop d'informations
aliases: []
---
# Effet de vérité illusoire

> **English:** Illusory truth effect

## Définition — français

Tendance à juger une affirmation plus vraie parce qu'elle est familière ou répétée.

## Definition — English

The tendency to judge a statement as more truthful because it is familiar or repeated.

## Exemple

Une fausse affirmation aperçue plusieurs fois sur différents réseaux sociaux finit par paraître familière, puis plus crédible qu’au premier contact.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : La fluidité de traitement est interprétée comme un indice de vérité.

## Mécanisme probable

La fluidité de traitement est interprétée comme un indice de vérité.

## Analyse critique

La répétition ou la familiarité peut augmenter la vérité perçue, notamment par fluidité de traitement. L’effet ne supprime pas systématiquement les connaissances antérieures et dépend de la plausibilité, de l’attention, de la source et du délai.

**Conclusion de l’audit :** effet de répétition bien documenté, mais non automatique.

## Comment le limiter ?

Vérifier la source primaire, distinguer familiarité et preuve, et éviter de répéter inutilement une fausse information dans une correction.

## Classement

- Nature scientifique : augmentation de la crédibilité perçue d’une affirmation après répétition ou familiarisation
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Illusory_truth_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Dechêne, A., Stahl, C., Hansen, J., & Wänke, M. (2010). The truth about the truth: A meta-analytic review of the truth effect. *Personality and Social Psychology Review*, 14(2), 238–257. https://doi.org/10.1177/1088868309352251

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
