---
type: effet-intergroupe
nom_fr: Favoritisme envers l'exogroupe
nom_en: Outgroup favoritism
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Self-perspective
codex: []
aliases: []
nature_scientifique: préférence explicite ou implicite pour un groupe extérieur, souvent de statut supérieur
robustesse: documenté dans certains rapports de statut et de légitimité, mais loin d’être universel
---
# Favoritisme envers l'exogroupe

> **English:** Outgroup favoritism

## Définition — français

Évaluation plus favorable d’un exogroupe que de son propre groupe.

## Definition — English

A more favorable evaluation of an outgroup than of one’s own group.

## Exemple

Des membres d’un groupe de faible statut associent davantage de prestige au groupe dominant.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Statut social, légitimité perçue, justification du système et identité sociale.

## Mécanisme probable

Statut social, légitimité perçue, justification du système et identité sociale.

## Analyse critique

Le phénomène dépend du domaine évalué et peut coexister avec un favoritisme intragroupe sur d’autres dimensions.

**Conclusion de l’audit :** documenté dans certains rapports de statut et de légitimité, mais loin d’être universel.

## Comment le limiter ?

Comparer les mêmes critères, examiner les rapports de pouvoir et mesurer attitudes explicites et implicites séparément.

## Classement

- Nature scientifique : préférence explicite ou implicite pour un groupe extérieur, souvent de statut supérieur
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Outgroup_favoritism
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Jost, J. T., Pelham, B. W., & Carvallo, M. R. (2002). Non-conscious forms of system justification: Implicit and behavioral preferences for higher status groups. *Journal of Experimental Social Psychology*, 38(6), 586–602. https://doi.org/10.1016/S0022-1031(02)00505-X

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
