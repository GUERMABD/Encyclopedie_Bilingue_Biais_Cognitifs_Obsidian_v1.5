---
type: biais-cognitif
nom_fr: Biais de quantification
nom_en: Quantification bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: biais de représentation et de gestion par les mesures
robustesse: concept récent et hétérogène; preuves directes limitées
---
# Biais de quantification

> **English:** Quantification bias

## Définition — français

Tendance à privilégier ce qui est facilement mesurable et à traiter la précision numérique comme une représentation suffisante de la réalité.

## Definition — English

The tendency to privilege what is easily measurable and to treat numerical precision as a sufficient representation of reality.

## Exemple

Un service optimise uniquement un indicateur chiffré en négligeant des aspects importants mais moins mesurables de la qualité.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Saillance et comparabilité des nombres, substitution de l’objectif par son indicateur.

## Mécanisme probable

Saillance et comparabilité des nombres, substitution de l’objectif par son indicateur.

## Analyse critique

Le terme recoupe surrogation, loi de Goodhart et biais de mesure. Il ne constitue pas encore un effet psychologique unitaire solidement délimité.

**Conclusion de l’audit :** concept récent et hétérogène; preuves directes limitées.

## Comment le limiter ?

Relier chaque mesure au construit visé, ajouter des indicateurs qualitatifs et surveiller les comportements d’optimisation de la métrique.

## Classement

- Nature scientifique : biais de représentation et de gestion par les mesures
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Quantification_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Assale, M., Bordogna, S., & Cabitza, F. (2020). Vague Visualizations to Reduce Quantification Bias in Shared Medical Decision Making. In *Proceedings of the 15th International Joint Conference on Computer Vision, Imaging and Computer Graphics Theory and Applications (VISIGRAPP 2020), Volume 3: IVAPP* (pp. 209–216). https://doi.org/10.5220/0008969802090216

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
