---
type: biais-cognitif
nom_fr: Biais de courtoisie
nom_en: Courtesy bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: biais de réponse et problème méthodologique
robustesse: bien reconnu en enquête qualitative et quantitative; taille dépendante du contexte et de la relation
---
# Biais de courtoisie

> **English:** Courtesy bias

## Définition — français

Tendance d’un répondant à fournir une réponse socialement aimable, respectueuse ou attendue plutôt que son évaluation réelle.

## Definition — English

The tendency for respondents to give a socially polite or expected answer rather than their actual evaluation.

## Exemple

Un bénéficiaire déclare qu’un service est excellent devant la personne qui le fournit, puis exprime des critiques anonymement.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Gestion de la relation, crainte des conséquences et désir d’éviter l’offense.

## Mécanisme probable

Gestion de la relation, crainte des conséquences et désir d’éviter l’offense.

## Analyse critique

Il recoupe désirabilité sociale, acquiescement et effets d’intervieweur. Dans des contextes de dépendance ou de violence, la réponse peut être une stratégie rationnelle de protection.

**Conclusion de l’audit :** bien reconnu en enquête qualitative et quantitative; taille dépendante du contexte et de la relation.

## Comment le limiter ?

Garantir la confidentialité, dissocier l’enquêteur du service évalué et comparer plusieurs modes de recueil.

## Classement

- Nature scientifique : biais de réponse et problème méthodologique
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Courtesy_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Parkinson, S. E. (2022). (Dis)courtesy bias: “Methodological cognates,” data validity, and ethics in violence-adjacent research. *Comparative Political Studies*, 55(3), 420–453. https://doi.org/10.1177/00104140211024309

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
