---
type: effet-de-jugement
nom_fr: Ancrage
nom_en: Anchoring bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet de jugement influencé par une valeur ou information initiale
robustesse: bien documenté, avec une amplitude variable selon les tâches et les contextes
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Baseline
codex:
- Trop d'informations
aliases:
- Anchoring
---
# Ancrage

> **English:** Anchoring bias

## Définition — français

Influence disproportionnée d'une première valeur ou information sur une estimation ultérieure.

## Definition — English

The disproportionate influence of an initial value or piece of information on a later estimate.

## Exemple

Un prix initial très élevé rend une remise ultérieure plus attractive, même si le prix final reste excessif.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Ajustement insuffisant à partir d'un point de départ saillant.

## Mécanisme probable

Ajustement insuffisant à partir d'un point de départ saillant.

## Analyse critique

L’effet d’ancrage est bien documenté, mais sa taille varie selon la pertinence de l’ancre, l’expertise, la tâche et les incitations. Une valeur initiale n’est donc pas toujours une erreur : elle devient un biais lorsqu’elle influence excessivement une estimation qui devrait reposer sur d’autres informations.

**Conclusion de l’audit :** effet établi, mais d’ampleur contextuelle.

## Comment le limiter ?

Établir une estimation indépendante avant de voir l'ancre et utiliser plusieurs références externes.

## Classement

- Nature scientifique : effet de jugement influencé par une valeur ou information initiale
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Anchoring_(cognitive_bias)
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Furnham, A., & Boo, H. C. (2011). A literature review of the anchoring effect. *The Journal of Socio-Economics*, 40(1), 35–42. https://doi.org/10.1016/j.socec.2010.10.008

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
