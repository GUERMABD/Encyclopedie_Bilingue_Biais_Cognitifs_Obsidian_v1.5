---
type: biais-cognitif
nom_fr: Biais de prévention
nom_en: Prevention bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: biais de répartition d’investissement en cybersécurité
robustesse: effet expérimental publié dans un domaine précis; réplications et généralisation encore limitées
---
# Biais de prévention

> **English:** Prevention bias

## Définition — français

Préférence excessive pour les mesures préventives au détriment de la détection et de la réponse lorsque leur rendement attendu est comparable.

## Definition — English

An excessive preference for preventive measures over detection and response when their expected returns are comparable.

## Exemple

Un budget de sécurité est presque entièrement consacré à empêcher les incidents, sans capacité suffisante pour les détecter ou y répondre.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attrait d’empêcher le dommage et perception plus concrète du contrôle préventif.

## Mécanisme probable

Attrait d’empêcher le dommage et perception plus concrète du contrôle préventif.

## Analyse critique

Le concept a été introduit dans des jeux de décision en sécurité de l’information. Il ne signifie pas que la prévention est généralement surfinancée dans tous les secteurs.

**Conclusion de l’audit :** effet expérimental publié dans un domaine précis; réplications et généralisation encore limitées.

## Comment le limiter ?

Comparer les rendements marginaux de prévention, détection et réponse selon des scénarios communs.

## Classement

- Nature scientifique : biais de répartition d’investissement en cybersécurité
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Prevention_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Safi, R., Browne, G. J., & Jalali Naini, A. (2021). Mis-spending on information security measures: Theory and experimental evidence. *International Journal of Information Management*, 57, 102291. https://doi.org/10.1016/j.ijinfomgt.2020.102291

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
