---
type: biais-cognitif
nom_fr: Attente exagérée
nom_en: Exaggerated expectation
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: biais formel d’estimation
robustesse: décrit dans un modèle intégrateur; base empirique spécifique plus étroite que l’étiquette générale
---
# Attente exagérée

> **English:** Exaggerated expectation

## Définition — français

Tendance, dans certaines estimations, à produire des attentes trop extrêmes lorsque l’information mémorisée ou intégrée est bruitée.

## Definition — English

In some estimation tasks, the tendency to form expectations that are too extreme when stored or integrated information is noisy.

## Exemple

À partir de signaux partiels favorables, une probabilité modérée est transformée en quasi-certitude.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Transformation non linéaire d’informations imparfaites et amplification des estimations extrêmes.

## Mécanisme probable

Transformation non linéaire d’informations imparfaites et amplification des estimations extrêmes.

## Analyse critique

L’expression ne doit pas être confondue avec toute attente optimiste ou avec l’effet des attentes sur le comportement. Elle provient surtout d’une taxonomie formelle.

**Conclusion de l’audit :** décrit dans un modèle intégrateur; base empirique spécifique plus étroite que l’étiquette générale.

## Comment le limiter ?

Calibrer les probabilités sur des fréquences observées et contrôler les prévisions par classes de confiance.

## Classement

- Nature scientifique : biais formel d’estimation
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Exaggerated_expectation
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Hilbert, M. (2012). Toward a synthesis of cognitive biases: How noisy information processing can bias human decision making. *Psychological Bulletin*, 138(2), 211–237. https://doi.org/10.1037/a0025940

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
