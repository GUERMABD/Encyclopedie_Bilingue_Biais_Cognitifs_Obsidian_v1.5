---
type: biais-cognitif
nom_fr: Effet d'espacement
nom_en: Spacing effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet d’apprentissage distribué
robustesse: robuste dans de nombreuses tâches; taille variable
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Effet d'espacement

> **English:** Spacing effect

## Définition — français

Meilleure rétention à long terme lorsque les répétitions sont distribuées plutôt que massées.

## Definition — English

Better long-term retention when repetitions are distributed rather than massed.

## Exemple

Quatre séances réparties sur plusieurs jours produisent généralement une meilleure rétention qu’une seule séance de même durée.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Récupération répétée avec effort, consolidation et diversité des contextes.

## Mécanisme probable

Récupération répétée avec effort, consolidation et diversité des contextes.

## Analyse critique

L’avantage concerne surtout la rétention différée. La pratique massée peut donner une impression immédiate de fluidité sans produire le même maintien.

**Conclusion de l’audit :** robuste dans de nombreuses tâches; taille variable.

## Comment le limiter ?

Répartir les révisions et inclure des rappels actifs.

## Classement

- Nature scientifique : effet d’apprentissage distribué
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Spacing_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Cepeda, N. J., Pashler, H., Vul, E., Wixted, J. T., & Rohrer, D. (2006). Distributed practice in verbal recall tasks: A review and quantitative synthesis. *Psychological Bulletin*, 132(3), 354–380. https://doi.org/10.1037/0033-2909.132.3.354

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
