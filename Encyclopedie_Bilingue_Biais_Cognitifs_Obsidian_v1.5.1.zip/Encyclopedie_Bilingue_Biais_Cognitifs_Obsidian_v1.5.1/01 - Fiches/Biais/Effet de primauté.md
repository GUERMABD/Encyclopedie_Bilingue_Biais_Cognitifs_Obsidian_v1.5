---
type: biais-cognitif
nom_fr: Effet de primauté
nom_en: Primacy effect
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: composante initiale de l’effet de position sérielle
robustesse: robuste dans les paradigmes de listes, modulée par la répétition
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Baseline
codex:
- Limites de la mémoire
aliases: []
---
# Effet de primauté

> **English:** Primacy effect

## Définition — français

Meilleur rappel des premiers éléments d’une séquence.

## Definition — English

Better recall of the first items in a sequence.

## Exemple

Les premiers noms d’une liste sont mieux retenus que ceux du milieu.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Temps de répétition et encodage plus élaboré des premiers éléments.

## Mécanisme probable

Temps de répétition et encodage plus élaboré des premiers éléments.

## Analyse critique

L’effet diminue lorsque la présentation est rapide ou lorsque la répétition est empêchée; il n’est pas une règle universelle de communication.

**Conclusion de l’audit :** robuste dans les paradigmes de listes, modulée par la répétition.

## Comment le limiter ?

Répéter les éléments centraux et utiliser des regroupements.

## Classement

- Nature scientifique : composante initiale de l’effet de position sérielle
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Limites de la mémoire
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Serial-position_effect#Primacy_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Murdock, B. B. (1962). The serial position effect of free recall. *Journal of Experimental Psychology*, 64(5), 482–488. https://doi.org/10.1037/h0045106

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
