---
type: biais-cognitif
nom_fr: Illusion de profondeur explicative
nom_en: Illusion of explanatory depth
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: surestimation métacognitive de la compréhension mécanistique
robustesse: effet expérimental bien documenté pour des systèmes complexes
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Illusion de profondeur explicative

> **English:** Illusion of explanatory depth

## Définition — français

Tendance à croire comprendre un mécanisme avec plus de profondeur qu’on ne peut réellement l’expliquer.

## Definition — English

The tendency to believe one understands a mechanism more deeply than one can actually explain it.

## Exemple

Une personne affirme comprendre une fermeture éclair puis découvre des lacunes en devant décrire chaque étape.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Familiarité avec le résultat, accès à des fragments d’information et absence de test d’explication.

## Mécanisme probable

Familiarité avec le résultat, accès à des fragments d’information et absence de test d’explication.

## Analyse critique

L’effet est particulièrement pertinent pour les systèmes causaux complexes; il ne signifie pas que toute compréhension intuitive est fausse.

**Conclusion de l’audit :** effet expérimental bien documenté pour des systèmes complexes.

## Comment le limiter ?

Écrire une explication causale étape par étape et identifier les points non expliqués.

## Classement

- Nature scientifique : surestimation métacognitive de la compréhension mécanistique
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Illusion_of_explanatory_depth
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Rozenblit, L., & Keil, F. (2002). The misunderstood limits of folk science: An illusion of explanatory depth. *Cognitive Science*, 26(5), 521–562. https://doi.org/10.1207/s15516709cog2605_1

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
