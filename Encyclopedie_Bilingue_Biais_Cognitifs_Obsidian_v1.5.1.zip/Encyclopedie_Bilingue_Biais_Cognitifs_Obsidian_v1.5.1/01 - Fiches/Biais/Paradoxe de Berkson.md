---
type: biais-statistique
nom_fr: Paradoxe de Berkson
nom_en: Berkson's paradox
statut_fr: terme français attesté; aucune page française individuelle validée dans cette édition
traduction: traduction française attestée
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: forme de biais de sélection par collisionneur
robustesse: mécanisme statistique établi
---
# Paradoxe de Berkson

> **English:** Berkson's paradox

## Définition — français

Association artificielle entre variables créée par la sélection d’observations selon une conséquence commune, historiquement illustrée par l’admission à l’hôpital.

## Definition — English

A spurious association between variables created by selecting observations on a shared consequence, historically illustrated by hospital admission.

## Exemple

Deux maladies indépendantes dans la population peuvent sembler négativement associées parmi les patients hospitalisés si chacune augmente la probabilité d’hospitalisation.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Conditionner l’analyse sur un collisionneur ouvre une association non causale entre ses causes.

## Mécanisme probable

Conditionner l’analyse sur un collisionneur ouvre une association non causale entre ses causes.

## Analyse critique

Il s’agit d’un artefact statistique et d’un cas particulier de biais de sélection, non d’un biais cognitif. Le mot « paradoxe » décrit un résultat contre-intuitif, mais le mécanisme est explicable par la structure de sélection.

**Conclusion de l’audit :** artefact statistique bien établi.

## Comment le limiter ou l’étudier correctement ?

Reconstituer la population source, éviter de conditionner sur des conséquences communes et utiliser des diagrammes causaux pour identifier les collisionneurs.

## Classement

- Nature scientifique : forme de biais de sélection par collisionneur
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : terme français attesté; aucune page française individuelle validée dans cette édition

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Berkson%27s_paradox
- Français : aucune page individuelle équivalente validée dans cette édition ; résolution complémentaire prévue via Wikidata.

## Références scientifiques contrôlées

- Berkson, J. (1946). Limitations of the application of fourfold table analysis to hospital data. *Biometrics Bulletin*, 2(3), 47–53. https://doi.org/10.2307/3002000
- Berkson, J. (2014). Limitations of the application of fourfold table analysis to hospital data. *International Journal of Epidemiology*, 43(2), 511–515. https://doi.org/10.1093/ije/dyu022

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
