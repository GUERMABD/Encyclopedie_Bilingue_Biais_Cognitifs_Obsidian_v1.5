---
type: biais-cognitif
nom_fr: Biais de genre
nom_en: Gender bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: catégorie générale de traitements ou jugements différenciés selon le genre
robustesse: discriminations documentées, mais direction et amplitude très dépendantes du domaine, de la composition et de la période
---
# Biais de genre

> **English:** Gender bias

## Définition — français

Ensemble de jugements ou décisions systématiquement influencés par le genre ou les attentes qui lui sont associées.

## Definition — English

A broad class of judgments or decisions systematically influenced by gender or gender-related expectations.

## Exemple

Deux candidatures équivalentes reçoivent des évaluations différentes selon le prénom associé au dossier.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Stéréotypes, normes sociales, composition du contexte et attentes de rôle.

## Mécanisme probable

Stéréotypes, normes sociales, composition du contexte et attentes de rôle.

## Analyse critique

« Biais de genre » n’est pas un effet unique. Les méta-analyses montrent des résultats variables selon les métiers, les groupes, les périodes et les protocoles.

**Conclusion de l’audit :** discriminations documentées, mais direction et amplitude très dépendantes du domaine, de la composition et de la période.

## Comment le limiter ?

Anonymiser lorsque c’est pertinent, définir les critères avant l’évaluation et analyser les résultats par étape et par contexte.

## Classement

- Nature scientifique : catégorie générale de traitements ou jugements différenciés selon le genre
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Gender_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Galos, D. R., & Coppock, A. (2023). Gender composition predicts gender bias: A meta-reanalysis of hiring discrimination audit experiments. *Science Advances*, 9(18), eade7979. https://doi.org/10.1126/sciadv.ade7979

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
