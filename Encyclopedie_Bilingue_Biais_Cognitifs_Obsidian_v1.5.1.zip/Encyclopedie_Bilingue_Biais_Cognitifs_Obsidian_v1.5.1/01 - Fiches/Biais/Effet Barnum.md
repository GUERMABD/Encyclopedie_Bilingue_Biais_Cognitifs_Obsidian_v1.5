---
type: biais-cognitif
nom_fr: Effet Barnum
nom_en: Barnum effect
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: acceptation de descriptions générales comme personnellement précises
robustesse: effet classique robuste en démonstration; modulé par la valence et l’autorité
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Outcome
codex:
- Nécessité d'agir rapidement
aliases:
- Forer effect
---
# Effet Barnum

> **English:** Barnum effect

## Définition — français

Tendance à juger très personnelle une description vague et largement applicable.

## Definition — English

The tendency to judge a vague, widely applicable description as highly personal.

## Exemple

Plusieurs personnes trouvent exact le même profil de personnalité composé d’énoncés généraux.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Validation subjective, recherche de correspondances et formulations positives.

## Mécanisme probable

Validation subjective, recherche de correspondances et formulations positives.

## Analyse critique

L’effet n’implique pas que toute évaluation personnelle soit vide; il vise les énoncés non discriminants qui paraissent spécifiques.

**Conclusion de l’audit :** effet classique robuste en démonstration; modulé par la valence et l’autorité.

## Comment le limiter ?

Demander des prédictions précises, falsifiables et comparées à un groupe de référence.

## Classement

- Nature scientifique : acceptation de descriptions générales comme personnellement précises
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Nécessité d'agir rapidement
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Barnum_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Forer, B. R. (1949). The fallacy of personal validation: A classroom demonstration of gullibility. *Journal of Abnormal and Social Psychology*, 44(1), 118–123. https://doi.org/10.1037/h0059240

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
