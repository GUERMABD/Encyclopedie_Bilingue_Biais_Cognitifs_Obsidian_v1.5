---
type: biais-cognitif
nom_fr: Biais d'optimisme
nom_en: Optimism bias
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: biais de jugement probabiliste
robustesse: à nuancer selon la méthode de mesure
---
# Biais d'optimisme

> **English:** Optimism bias

## Définition — français

Tendance à estimer que les événements favorables sont plus probables pour soi et les événements défavorables moins probables que pour des personnes comparables.

## Definition — English

The tendency to judge positive events as more likely, and negative events as less likely, for oneself than for comparable others.

## Exemple

Un conducteur estime son risque personnel d’accident inférieur à celui du conducteur moyen sans disposer d’éléments suffisants.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Comparaison égocentrée, contrôle perçu, désirabilité de l’issue et connaissance incomplète du groupe de référence.

## Mécanisme probable

Comparaison égocentrée, contrôle perçu, désirabilité de l’issue et connaissance incomplète du groupe de référence.

## Analyse critique

Le phénomène a été largement étudié, mais certaines mesures comparatives peuvent produire un biais apparent pour des raisons mathématiques ou méthodologiques. Il faut le distinguer de l’optimisme comme trait de personnalité.

**Conclusion de l’audit :** à nuancer selon la méthode de mesure.

## Comment le limiter ?

Utiliser des fréquences de référence adaptées, demander une estimation absolue avant la comparaison et contrôler les informations réellement disponibles.

## Classement

- Nature scientifique : biais de jugement probabiliste
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Optimism_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Weinstein, N. D. (1980). Unrealistic optimism about future life events. *Journal of Personality and Social Psychology*, 39(5), 806–820. https://doi.org/10.1037/0022-3514.39.5.806
- Harris, A. J. L., & Hahn, U. (2011). Unrealistic optimism about future life events: A cautionary note. *Psychological Review*, 118(1), 135–154. https://doi.org/10.1037/a0020997

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
