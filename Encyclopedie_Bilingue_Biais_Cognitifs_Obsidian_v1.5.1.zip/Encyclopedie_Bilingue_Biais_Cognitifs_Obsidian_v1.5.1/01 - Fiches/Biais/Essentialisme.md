---
type: biais-cognitif
nom_fr: Essentialisme
nom_en: Essentialism
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: famille de croyances sur la nature profonde et stable des catégories
robustesse: solidement documentée; contenu et intensité variables selon les catégories et les cultures
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Manque de sens
aliases: []
---
# Essentialisme

> **English:** Essentialism

## Définition — français

Tendance à considérer certaines catégories comme possédant une essence interne, naturelle et stable qui expliquerait leurs membres.

## Definition — English

The tendency to treat some categories as if they possessed a deep, natural, and stable essence explaining their members.

## Exemple

Une catégorie sociale est décrite comme homogène et immuable malgré sa diversité interne et son histoire.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Recherche d’une cause sous-jacente, stabilité perçue et réduction de la complexité des catégories.

## Mécanisme probable

Recherche d’une cause sous-jacente, stabilité perçue et réduction de la complexité des catégories.

## Analyse critique

L’essentialisme est un ensemble de croyances, pas un biais unique. Il peut concerner des espèces biologiques, des groupes sociaux ou des traits, avec des conséquences différentes.

**Conclusion de l’audit :** solidement documentée; contenu et intensité variables selon les catégories et les cultures.

## Comment le limiter ?

Employer des descriptions dimensionnelles, rappeler la variation interne et distinguer convention sociale, hérédité et causalité.

## Classement

- Nature scientifique : famille de croyances sur la nature profonde et stable des catégories
- Tâche(s) du classement Wikipédia : aucune
- Sous-catégorie(s) (« flavors ») : aucune
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Essentialism
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Haslam, N., Rothschild, L., & Ernst, D. (2000). Essentialist beliefs about social categories. *British Journal of Social Psychology*, 39(1), 113–127. https://doi.org/10.1348/014466600164363

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
