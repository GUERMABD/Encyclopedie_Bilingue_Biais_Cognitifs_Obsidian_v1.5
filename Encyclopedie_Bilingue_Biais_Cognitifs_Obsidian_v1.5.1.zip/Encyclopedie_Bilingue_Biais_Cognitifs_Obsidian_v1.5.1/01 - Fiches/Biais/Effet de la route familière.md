---
type: effet-temporel
nom_fr: Effet de la route familière
nom_en: Well travelled road effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Inertia
codex:
- Manque de sens
aliases:
- Well–traveled road effect
nature_scientifique: sous-estimation rétrospective de durées routinières ou familières
robustesse: la compression temporelle liée à la routine est documentée; l’étiquette spécifique aux routes est moins standardisée
---
# Effet de la route familière

> **English:** Well travelled road effect

## Définition — français

Tendance à se souvenir d’un trajet familier comme ayant duré moins longtemps qu’un trajet moins routinier.

## Definition — English

The tendency to remember a familiar journey as shorter than a less routine one.

## Exemple

Un trajet quotidien paraît avoir pris quinze minutes alors que le relevé indique vingt minutes.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Moins de changements contextuels mémorisés et traitement plus automatisé.

## Mécanisme probable

Moins de changements contextuels mémorisés et traitement plus automatisé.

## Analyse critique

La familiarité peut réellement améliorer l’efficacité; il faut donc distinguer durée objective et durée ressentie. L’effet s’inverse parfois lorsque la personne surveille le temps pendant l’activité.

**Conclusion de l’audit :** la compression temporelle liée à la routine est documentée; l’étiquette spécifique aux routes est moins standardisée.

## Comment le limiter ?

Utiliser un historique GPS ou un chronomètre plutôt que le souvenir du trajet.

## Classement

- Nature scientifique : sous-estimation rétrospective de durées routinières ou familières
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Manque de sens
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Well_travelled_road_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Avni-Babad, D., & Ritov, I. (2003). Routine and the perception of time. *Journal of Experimental Psychology: General*, 132(4), 543–550. https://doi.org/10.1037/0096-3445.132.4.543

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
