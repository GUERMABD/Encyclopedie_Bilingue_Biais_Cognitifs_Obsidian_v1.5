---
type: biais-cognitif
nom_fr: Effet de référence à soi
nom_en: Self-relevance effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: avantage mnésique de l’encodage auto-référentiel
robustesse: effet moyen robuste, avec variations selon le matériel et le soi
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Trop d'informations
aliases:
- Self–relevance effect
---
# Effet de référence à soi

> **English:** Self-relevance effect

## Définition — français

Meilleure mémorisation d’informations traitées en relation avec soi-même.

## Definition — English

Better memory for information processed in relation to oneself.

## Exemple

Un adjectif évalué par rapport à sa propre personnalité est mieux rappelé qu’un adjectif traité superficiellement.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Organisation riche du concept de soi et élaboration.

## Mécanisme probable

Organisation riche du concept de soi et élaboration.

## Analyse critique

L’effet ne signifie pas que les souvenirs auto-référentiels sont plus exacts; ils peuvent aussi être reconstruits ou biaisés.

**Conclusion de l’audit :** effet moyen robuste, avec variations selon le matériel et le soi.

## Comment le limiter ?

Utiliser des exemples personnels pour apprendre, puis vérifier séparément l’exactitude factuelle.

## Classement

- Nature scientifique : avantage mnésique de l’encodage auto-référentiel
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Self-reference_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Symons, C. S., & Johnson, B. T. (1997). The self-reference effect in memory: A meta-analysis. *Psychological Bulletin*, 121(3), 371–394. https://doi.org/10.1037/0033-2909.121.3.371

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
