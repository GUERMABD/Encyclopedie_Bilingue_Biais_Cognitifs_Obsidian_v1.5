---
type: biais-cognitif
nom_fr: Biais des incitations extrinsèques
nom_en: Extrinsic incentives bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: asymétrie d’attribution de la motivation
robustesse: effet documenté dans un programme fondateur; portée et réplications moins étendues que les théories générales de motivation
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases:
- Extrinsic incentive error
---
# Biais des incitations extrinsèques

> **English:** Extrinsic incentives bias

## Définition — français

Tendance à surestimer le rôle des récompenses externes dans la motivation d’autrui, tout en accordant davantage de poids aux motivations intrinsèques pour soi-même.

## Definition — English

The tendency to overestimate external rewards as motivators of others while attributing more intrinsic motivation to oneself.

## Exemple

Un dirigeant suppose que les salariés travaillent surtout pour l’argent alors qu’ils déclarent valoriser aussi l’intérêt du travail.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Asymétrie soi-autrui et théories profanes de l’agence.

## Mécanisme probable

Asymétrie soi-autrui et théories profanes de l’agence.

## Analyse critique

Les incitations extrinsèques sont parfois réellement dominantes. Le biais porte sur l’écart systématique d’attribution, non sur l’idée que l’argent ne motive jamais.

**Conclusion de l’audit :** effet documenté dans un programme fondateur; portée et réplications moins étendues que les théories générales de motivation.

## Comment le limiter ?

Mesurer directement plusieurs motivations et tester les incitations plutôt que les supposer.

## Classement

- Nature scientifique : asymétrie d’attribution de la motivation
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Extrinsic_incentives_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Heath, C. (1999). On the social psychology of agency relationships: Lay theories of motivation overemphasize extrinsic incentives. *Organizational Behavior and Human Decision Processes*, 78(1), 25–62. https://doi.org/10.1006/obhd.1999.2826

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
