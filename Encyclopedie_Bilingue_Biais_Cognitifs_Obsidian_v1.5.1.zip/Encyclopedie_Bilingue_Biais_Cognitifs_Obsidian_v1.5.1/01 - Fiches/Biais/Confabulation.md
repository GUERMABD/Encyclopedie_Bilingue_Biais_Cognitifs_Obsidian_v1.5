---
type: biais-cognitif
nom_fr: Confabulation
nom_en: Confabulation
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Manque de sens
aliases: []
nature_scientifique: syndrome et symptôme neuropsychologique de mémoire
robustesse: phénomène clinique établi; mécanismes multiples et classifications encore discutés
---
# Confabulation

> **English:** Confabulation

## Définition — français

Production sincère de souvenirs ou récits inexacts sans intention de tromper, souvent dans un contexte neurologique ou amnésique.

## Definition — English

The sincere production of inaccurate memories or narratives without intent to deceive, often in a neurological or amnesic context.

## Exemple

Un patient décrit avec conviction une activité récente qui appartient en réalité à une autre période de sa vie.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Défaillances de récupération, de contexte temporel, de contrôle exécutif et d’évaluation de la réalité.

## Mécanisme probable

Défaillances de récupération, de contexte temporel, de contrôle exécutif et d’évaluation de la réalité.

## Analyse critique

La confabulation n’est pas un simple mensonge ni toute erreur ordinaire de mémoire. Ses formes provoquées et spontanées ont des profils différents.

**Conclusion de l’audit :** phénomène clinique établi; mécanismes multiples et classifications encore discutés.

## Comment le limiter ?

Vérifier les sources externes, éviter les questions suggestives et recourir à une évaluation clinique lorsqu’elle est persistante ou fonctionnellement grave.

## Classement

- Nature scientifique : syndrome et symptôme neuropsychologique de mémoire
- Tâche(s) du classement Wikipédia : aucune
- Sous-catégorie(s) (« flavors ») : aucune
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Confabulation
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Metcalf, K., Langdon, R., & Coltheart, M. (2007). Models of confabulation: A critical review and a new framework. *Cognitive Neuropsychology*, 24(1), 23–47. https://doi.org/10.1080/02643290600694901

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
