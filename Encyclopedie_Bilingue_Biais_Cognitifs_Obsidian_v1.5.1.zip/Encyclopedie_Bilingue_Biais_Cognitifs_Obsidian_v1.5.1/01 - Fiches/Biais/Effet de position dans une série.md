---
type: biais-cognitif
nom_fr: Effet de position dans une série
nom_en: Serial recall effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet de rappel sériel
robustesse: effet établi; terme partiellement chevauchant avec effet de position sérielle
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Limites de la mémoire
aliases: []
---
# Effet de position dans une série

> **English:** Serial recall effect

## Définition — français

Influence de l’emplacement d’un élément dans une séquence sur sa probabilité de rappel.

## Definition — English

The influence of an item’s location in a sequence on its recall probability.

## Exemple

Une information présentée au milieu d’une longue séquence est moins accessible que des informations placées aux extrémités.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Encodage, répétition et disponibilité variables selon la position.

## Mécanisme probable

Encodage, répétition et disponibilité variables selon la position.

## Analyse critique

Cette entrée recouvre largement l’effet de position sérielle; elle est conservée comme variante terminologique plutôt que comme phénomène indépendant.

**Conclusion de l’audit :** effet établi; terme partiellement chevauchant avec effet de position sérielle.

## Comment le limiter ?

Structurer les séquences en petits groupes et répéter les éléments centraux.

## Classement

- Nature scientifique : effet de rappel sériel
- Tâche(s) du classement Wikipédia : aucune
- Sous-catégorie(s) (« flavors ») : aucune
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Recall_(memory)#Serial_recall
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Murdock, B. B. (1962). The serial position effect of free recall. *Journal of Experimental Psychology*, 64(5), 482–488. https://doi.org/10.1037/h0045106

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
