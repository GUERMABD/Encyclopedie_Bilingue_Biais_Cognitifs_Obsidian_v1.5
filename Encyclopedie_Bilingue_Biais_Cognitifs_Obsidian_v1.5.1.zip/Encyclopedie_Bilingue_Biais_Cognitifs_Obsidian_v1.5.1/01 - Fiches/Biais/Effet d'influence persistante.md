---
type: biais-cognitif
nom_fr: Effet d'influence persistante
nom_en: Continued influence effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: persistance d’une information corrigée dans le raisonnement
robustesse: effet robuste, mais sensible au type de correction
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Inertia
codex:
- Trop d'informations
aliases: []
---
# Effet d'influence persistante

> **English:** Continued influence effect

## Définition — français

Maintien d’une influence de l’information erronée après qu’elle a été explicitement corrigée.

## Definition — English

The continued influence of misinformation after it has been explicitly corrected.

## Exemple

Une explication initiale fausse continue d’orienter l’interprétation d’un événement malgré un démenti.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Modèle causal incomplet, familiarité et récupération concurrente de l’erreur et de la correction.

## Mécanisme probable

Modèle causal incomplet, familiarité et récupération concurrente de l’erreur et de la correction.

## Analyse critique

Une correction peut réduire l’erreur sans l’effacer totalement. Les effets varient selon la crédibilité, le délai et la présence d’une explication de remplacement.

**Conclusion de l’audit :** effet robuste, mais sensible au type de correction.

## Comment le limiter ?

Corriger rapidement, expliquer pourquoi l’information est fausse et fournir une explication alternative cohérente.

## Classement

- Nature scientifique : persistance d’une information corrigée dans le raisonnement
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Inertia
- Codex : Trop d'informations
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Confirmation_bias#continued_influence_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Lewandowsky, S., Ecker, U. K. H., Seifert, C. M., Schwarz, N., & Cook, J. (2012). Misinformation and its correction: Continued influence and successful debiasing. *Psychological Science in the Public Interest*, 13(3), 106–131. https://doi.org/10.1177/1529100612451018

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
