---
type: biais-cognitif
nom_fr: Biais de détection d'agent
nom_en: Agent detection bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: hypothèse de surdétection d’agents
robustesse: hypothèse influente mais résultats empiriques mixtes; modèle hypersensible non établi comme universel
---
# Biais de détection d'agent

> **English:** Agent detection bias

## Définition — français

Tendance supposée à détecter un agent intentionnel dans des signaux ambigus, particulièrement lorsque le coût d’une omission paraît élevé.

## Definition — English

A proposed tendency to detect an intentional agent in ambiguous signals, especially when the cost of missing one seems high.

## Exemple

Un bruit indéterminé dans l’obscurité est immédiatement interprété comme la présence de quelqu’un.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Seuil de détection abaissé face à une menace possible et avantage asymétrique des fausses alertes.

## Mécanisme probable

Seuil de détection abaissé face à une menace possible et avantage asymétrique des fausses alertes.

## Analyse critique

Des expériences ciblées n’ont pas confirmé toutes les prédictions du dispositif hypersensible de détection d’agent. Il faut distinguer détection perceptive, attribution d’intention et croyance religieuse.

**Conclusion de l’audit :** hypothèse influente mais résultats empiriques mixtes; modèle hypersensible non établi comme universel.

## Comment le limiter ?

Mesurer les faux positifs et les omissions dans une tâche contrôlée plutôt que déduire le biais d’une seule interprétation.

## Classement

- Nature scientifique : hypothèse de surdétection d’agents
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Agent_detection_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Maij, D. L. R., van Schie, H. T., & van Elk, M. (2019). The boundary conditions of the hypersensitive agency detection device: An empirical investigation of agency detection in threatening situations. *Religion, Brain & Behavior*, 9(1), 23–51. https://doi.org/10.1080/2153599X.2017.1362662

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
