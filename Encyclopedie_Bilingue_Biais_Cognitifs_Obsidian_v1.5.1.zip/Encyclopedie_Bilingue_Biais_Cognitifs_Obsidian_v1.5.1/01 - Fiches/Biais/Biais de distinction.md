---
type: biais-cognitif
nom_fr: Biais de distinction
nom_en: Distinction bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Baseline
codex:
- Trop d'informations
aliases: []
nature_scientifique: biais de comparaison en évaluation conjointe
robustesse: effet classique documenté dans plusieurs choix; dépend du mode d’évaluation
---
# Biais de distinction

> **English:** Distinction bias

## Définition — français

Tendance à surestimer l’importance de petites différences lorsque plusieurs options sont comparées côte à côte.

## Definition — English

The tendency to overestimate the importance of small differences when options are evaluated side by side.

## Exemple

Deux écrans presque identiques paraissent très différents en magasin, alors que la différence serait imperceptible lors d’un usage séparé.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Attention dirigée vers les attributs distinctifs disponibles en comparaison simultanée.

## Mécanisme probable

Attention dirigée vers les attributs distinctifs disponibles en comparaison simultanée.

## Analyse critique

Certaines petites différences sont importantes à long terme. Le biais concerne l’écart entre préférence en comparaison et expérience réelle séparée.

**Conclusion de l’audit :** effet classique documenté dans plusieurs choix; dépend du mode d’évaluation.

## Comment le limiter ?

Évaluer chaque option isolément dans son contexte d’usage avant la comparaison finale.

## Classement

- Nature scientifique : biais de comparaison en évaluation conjointe
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Baseline
- Codex : Trop d'informations
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Distinction_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Hsee, C. K., & Zhang, J. (2004). Distinction bias: Misprediction and mischoice due to joint evaluation. *Journal of Personality and Social Psychology*, 86(5), 680–695. https://doi.org/10.1037/0022-3514.86.5.680

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
