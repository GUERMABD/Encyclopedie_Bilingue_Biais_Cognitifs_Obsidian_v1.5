---
type: biais-cognitif
nom_fr: Effet de projecteur
nom_en: Spotlight effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: surestimation de la visibilité de soi pour autrui
robustesse: effet social expérimental documenté; amplitude dépendante du contexte
taches_wikipedia:
- Estimation
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases: []
---
# Effet de projecteur

> **English:** Spotlight effect

## Définition — français

Tendance à surestimer à quel point son apparence ou ses actions sont remarquées par les autres.

## Definition — English

The tendency to overestimate how much one’s appearance or actions are noticed by others.

## Exemple

Une personne pense qu’une petite tache sur son vêtement a été vue par presque tout le groupe.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Ancrage sur sa propre perspective et ajustement insuffisant vers celle d’autrui.

## Mécanisme probable

Ancrage sur sa propre perspective et ajustement insuffisant vers celle d’autrui.

## Analyse critique

Dans certaines situations publiques, l’attention d’autrui est réellement élevée. L’effet concerne une surestimation moyenne, non l’absence d’observation.

**Conclusion de l’audit :** effet social expérimental documenté; amplitude dépendante du contexte.

## Comment le limiter ?

Demander des estimations externes et considérer que les autres sont également centrés sur leurs propres préoccupations.

## Classement

- Nature scientifique : surestimation de la visibilité de soi pour autrui
- Tâche(s) du classement Wikipédia : Estimation
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Spotlight_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Gilovich, T., Medvec, V. H., & Savitsky, K. (2000). The spotlight effect in social judgment. *Journal of Personality and Social Psychology*, 78(2), 211–222. https://doi.org/10.1037/0022-3514.78.2.211

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
