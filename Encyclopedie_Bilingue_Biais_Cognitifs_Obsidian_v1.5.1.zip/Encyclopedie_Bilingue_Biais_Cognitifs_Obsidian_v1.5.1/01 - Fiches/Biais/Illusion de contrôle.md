---
type: biais-cognitif
nom_fr: Illusion de contrôle
nom_en: Illusion of control
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: biais de jugement sur le contrôle
robustesse: établie mais contextuelle
---
# Illusion de contrôle

> **English:** Illusion of control

## Définition — français

Surestimation de son influence sur un résultat lorsque celui-ci dépend en grande partie ou entièrement du hasard.

## Definition — English

The overestimation of one’s influence over an outcome that is largely or entirely determined by chance.

## Exemple

Attribuer une meilleure chance de gagner à un billet de loterie choisi soi-même plutôt qu’à un billet attribué aléatoirement.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Des indices habituellement liés à la compétence — choix, familiarité, participation ou compétition — sont transférés à une situation aléatoire.

## Mécanisme probable

Des indices habituellement liés à la compétence — choix, familiarité, participation ou compétition — sont transférés à une situation aléatoire.

## Analyse critique

La définition exige que le contrôle objectif soit faible ou nul. Dans les situations complexes où l’action modifie réellement les probabilités, une confiance élevée n’est pas nécessairement illusoire.

**Conclusion de l’audit :** établie mais contextuelle.

## Comment le limiter ?

Décrire le mécanisme causal, comparer les résultats avec un groupe sans contrôle et distinguer influence réelle, variance aléatoire et sentiment de participation.

## Classement

- Nature scientifique : biais de jugement sur le contrôle
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Illusion_of_control
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Langer, E. J. (1975). The illusion of control. *Journal of Personality and Social Psychology*, 32(2), 311–328. https://doi.org/10.1037/0022-3514.32.2.311

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
