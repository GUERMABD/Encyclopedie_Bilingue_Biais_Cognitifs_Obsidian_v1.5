---
type: biais-cognitif
nom_fr: Effet de verbatim
nom_en: Verbatim effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: perte plus rapide de la forme exacte que du sens
robustesse: effet classique de mémoire du discours
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Effet de verbatim

> **English:** Verbatim effect

## Définition — français

Tendance à conserver le sens général d’un message mieux que sa formulation exacte.

## Definition — English

The tendency to retain the gist of a message better than its exact wording.

## Exemple

Une personne reconnaît l’idée d’une phrase mais ne peut reproduire ses mots précis.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Extraction rapide du sens et dégradation des détails de surface.

## Mécanisme probable

Extraction rapide du sens et dégradation des détails de surface.

## Analyse critique

Le contenu général peut lui-même être reconstruit. Cet effet ne permet pas de traiter une paraphrase comme une citation exacte.

**Conclusion de l’audit :** effet classique de mémoire du discours.

## Comment le limiter ?

Conserver le texte source pour les citations et signaler clairement les paraphrases.

## Classement

- Nature scientifique : perte plus rapide de la forme exacte que du sens
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Verbatim_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Sachs, J. S. (1967). Recognition memory for syntactic and semantic aspects of connected discourse. *Perception & Psychophysics*, 2, 437–442. https://doi.org/10.3758/BF03208784

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
