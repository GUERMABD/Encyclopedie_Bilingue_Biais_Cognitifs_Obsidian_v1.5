---
type: biais-cognitif
nom_fr: Effet « troisième personne »
nom_en: Third-person effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: écart perçu entre l’influence des médias sur soi et sur autrui
robustesse: effet de perception largement étudié; direction variable pour les messages désirables
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases:
- Third–person effect
---
# Effet « troisième personne »

> **English:** Third-person effect

## Définition — français

Tendance à estimer qu’un message médiatique influence davantage les autres que soi-même.

## Definition — English

The tendency to estimate that media messages influence others more than oneself.

## Exemple

Une personne juge une publicité manipulatrice pour le public, mais affirme qu’elle-même n’y est pas sensible.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Comparaison sociale, autoprotection et perception de vulnérabilité relative.

## Mécanisme probable

Comparaison sociale, autoprotection et perception de vulnérabilité relative.

## Analyse critique

Pour les effets jugés souhaitables, l’écart peut s’inverser. La perception d’influence ne mesure pas directement l’influence réelle.

**Conclusion de l’audit :** effet de perception largement étudié; direction variable pour les messages désirables.

## Comment le limiter ?

Mesurer séparément exposition, changement réel et estimation subjective pour soi et autrui.

## Classement

- Nature scientifique : écart perçu entre l’influence des médias sur soi et sur autrui
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Third-person_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Davison, W. P. (1983). The third-person effect in communication. *Public Opinion Quarterly*, 47(1), 1–15. https://doi.org/10.1086/268763

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
