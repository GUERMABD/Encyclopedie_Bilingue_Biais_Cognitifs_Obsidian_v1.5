---
type: biais-cognitif
nom_fr: Biais téléologique
nom_en: Teleological bias
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: tendance à préférer des explications par le but
robustesse: robuste chez l’enfant et observée chez l’adulte sous certaines contraintes; domaine et formulation importants
---
# Biais téléologique

> **English:** Teleological bias

## Définition — français

Tendance à expliquer l’existence d’un objet ou d’un phénomène par la fonction ou le but qu’il servirait.

## Definition — English

The tendency to explain why an object or phenomenon exists by the function or purpose it appears to serve.

## Exemple

Des rochers pointus sont expliqués comme ayant cette forme pour empêcher les animaux de s’y asseoir.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Intuition finaliste et disponibilité des explications fonctionnelles.

## Mécanisme probable

Intuition finaliste et disponibilité des explications fonctionnelles.

## Analyse critique

Les artefacts ont réellement des fonctions intentionnelles et certaines fonctions biologiques sont scientifiquement pertinentes. Le biais concerne l’extension injustifiée du but à l’origine causale.

**Conclusion de l’audit :** robuste chez l’enfant et observée chez l’adulte sous certaines contraintes; domaine et formulation importants.

## Comment le limiter ?

Demander quel mécanisme historique ou physique a produit le phénomène, puis traiter séparément sa fonction éventuelle.

## Classement

- Nature scientifique : tendance à préférer des explications par le but
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Teleological_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kelemen, D. (1999). Why are rocks pointy? Children’s preference for teleological explanations of the natural world. *Developmental Psychology*, 35(6), 1440–1452. https://doi.org/10.1037/0012-1649.35.6.1440
- Mækelæ, M. J., Kreis, I. V., & Pfuhl, G. (2024). Teleological reasoning bias is predicted by pupil dynamics. *Psychophysiology*, 61. https://doi.org/10.1111/psyp.14532

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
