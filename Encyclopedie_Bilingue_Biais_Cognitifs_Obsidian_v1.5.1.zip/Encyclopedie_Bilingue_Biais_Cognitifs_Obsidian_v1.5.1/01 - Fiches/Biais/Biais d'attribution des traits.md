---
type: biais-cognitif
nom_fr: Biais d'attribution des traits
nom_en: Trait ascription bias
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Nécessité d'agir rapidement
aliases: []
nature_scientifique: asymétrie de description de soi et d’autrui
robustesse: effets observés mais définition étroite et littérature ancienne; pas une loi générale
---
# Biais d'attribution des traits

> **English:** Trait ascription bias

## Définition — français

Tendance à décrire autrui par des traits plus stables et soi-même par des états, contextes ou variations plus nombreux.

## Definition — English

The tendency to describe others in terms of more stable traits while describing oneself through states, contexts, or greater variability.

## Exemple

Une personne qualifie un collègue de désordonné, mais explique son propre désordre par une semaine exceptionnelle.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Accès asymétrique aux contextes de son propre comportement et observation plus limitée d’autrui.

## Mécanisme probable

Accès asymétrique aux contextes de son propre comportement et observation plus limitée d’autrui.

## Analyse critique

Le concept recoupe l’asymétrie acteur-observateur, dont la forme générale est contestée. Les différences peuvent aussi refléter une connaissance objectivement plus riche de soi.

**Conclusion de l’audit :** effets observés mais définition étroite et littérature ancienne; pas une loi générale.

## Comment le limiter ?

Rechercher plusieurs situations pour chaque personne et formuler des descriptions conditionnelles plutôt que des étiquettes globales.

## Classement

- Nature scientifique : asymétrie de description de soi et d’autrui
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Nécessité d'agir rapidement
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Trait_ascription_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kammer, D. (1982). Differences in trait ascriptions to self and friend: Unconfounding intensity from variability. *Psychological Reports*, 51(1), 99–102. https://doi.org/10.2466/pr0.1982.51.1.99
- Pronin, E., & Ross, L. (2006). Temporal differences in trait self-ascription: When the self is seen as an other. *Journal of Personality and Social Psychology*, 90(2), 197–209. https://doi.org/10.1037/0022-3514.90.2.197

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
