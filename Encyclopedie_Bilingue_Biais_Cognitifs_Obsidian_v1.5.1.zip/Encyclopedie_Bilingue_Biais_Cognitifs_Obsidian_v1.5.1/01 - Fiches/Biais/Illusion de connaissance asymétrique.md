---
type: biais-cognitif
nom_fr: Illusion de connaissance asymétrique
nom_en: Illusion of asymmetric insight
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: asymétrie de jugement sur la connaissance de soi et d’autrui
robustesse: effet classique surtout établi par auto-évaluations et tâches de laboratoire
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases: []
---
# Illusion de connaissance asymétrique

> **English:** Illusion of asymmetric insight

## Définition — français

Tendance à croire que l’on comprend mieux autrui qu’il ne nous comprend, tout en estimant son propre esprit moins lisible.

## Definition — English

The tendency to believe that one understands others better than they understand oneself, while viewing one’s own mind as less transparent.

## Exemple

Dans un conflit, chacun pense connaître les motivations cachées de l’autre et se croit lui-même mal compris.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Accès aux pensées privées de soi et inférence confiante à partir du comportement d’autrui.

## Mécanisme probable

Accès aux pensées privées de soi et inférence confiante à partir du comportement d’autrui.

## Analyse critique

L’effet ne prouve pas que toute impression sur autrui est fausse. Son ampleur dépend de la relation, des informations disponibles et de la mesure.

**Conclusion de l’audit :** effet classique surtout établi par auto-évaluations et tâches de laboratoire.

## Comment le limiter ?

Séparer observation, inférence et degré de confiance; demander une reformulation réciproque des intentions.

## Classement

- Nature scientifique : asymétrie de jugement sur la connaissance de soi et d’autrui
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Illusion_of_asymmetric_insight
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Pronin, E., Kruger, J., Savitsky, K., & Ross, L. (2001). You don’t know me, but I know you: The illusion of asymmetric insight. *Journal of Personality and Social Psychology*, 81(4), 639–656. https://doi.org/10.1037/0022-3514.81.4.639

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
