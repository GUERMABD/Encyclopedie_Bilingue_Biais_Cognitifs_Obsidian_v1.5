---
type: biais-cognitif
nom_fr: Effet inter-races
nom_en: Cross-race effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: déficit relatif de reconnaissance des visages d’un autre groupe racial
robustesse: effet moyen robuste; fortement modulé par le contact et le contexte
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Self-perspective
codex:
- Manque de sens
aliases:
- Cross–race effect
---
# Effet inter-races

> **English:** Cross-race effect

## Définition — français

Reconnaissance généralement moins précise des visages appartenant à un groupe racial moins familier.

## Definition — English

Generally poorer recognition of faces from a less familiar racial group.

## Exemple

Un témoin distingue moins bien des visages d’un groupe avec lequel il a peu de contacts individuants.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Expérience perceptive, catégorisation sociale et attention aux traits individuels.

## Mécanisme probable

Expérience perceptive, catégorisation sociale et attention aux traits individuels.

## Analyse critique

Ce n’est pas une mesure morale d’une personne ni une preuve directe de préjugé explicite. L’ampleur varie avec le contact et les conditions d’identification.

**Conclusion de l’audit :** effet moyen robuste; fortement modulé par le contact et le contexte.

## Comment le limiter ?

Recourir à des procédures d’identification rigoureuses et éviter les alignements suggestifs.

## Classement

- Nature scientifique : déficit relatif de reconnaissance des visages d’un autre groupe racial
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Self-perspective
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Cross-race_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Singh, B., Mellinger, C., Earls, H. A., Tran, J., Bardsley, B., & Correll, J. (2022). Does cross-race contact improve cross-race face perception? A meta-analysis of the cross-race deficit and contact. *Personality and Social Psychology Bulletin*, 48(6), 865–887. https://doi.org/10.1177/01461672211024463

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
