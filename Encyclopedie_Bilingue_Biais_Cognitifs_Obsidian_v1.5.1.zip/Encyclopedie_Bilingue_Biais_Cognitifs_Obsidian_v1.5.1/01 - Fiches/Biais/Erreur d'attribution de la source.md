---
type: biais-cognitif
nom_fr: Erreur d'attribution de la source
nom_en: Misattribution of memory
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: erreur mnésique de surveillance de la source
robustesse: phénomène bien établi; recouvre plusieurs sous-types
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Limites de la mémoire
aliases: []
---
# Erreur d'attribution de la source

> **English:** Misattribution of memory

## Définition — français

Attribution incorrecte d’un souvenir, d’une idée ou d’une perception à sa source.

## Definition — English

Incorrect attribution of a memory, idea, or perception to its source.

## Exemple

Un détail imaginé pendant une discussion est ensuite attribué à l’événement original.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Comparaison imparfaite des caractéristiques perceptives, contextuelles et cognitives.

## Mécanisme probable

Comparaison imparfaite des caractéristiques perceptives, contextuelles et cognitives.

## Analyse critique

Cette entrée chevauche la confusion de la source et constitue une famille d’erreurs, non un mécanisme unique.

**Conclusion de l’audit :** phénomène bien établi; recouvre plusieurs sous-types.

## Comment le limiter ?

Demander séparément « que sais-je ? » et « d’où vient cette information ? ».

## Classement

- Nature scientifique : erreur mnésique de surveillance de la source
- Tâche(s) du classement Wikipédia : aucune
- Sous-catégorie(s) (« flavors ») : aucune
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Misattribution_of_memory
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Johnson, M. K., Hashtroudi, S., & Lindsay, D. S. (1993). Source monitoring. *Psychological Bulletin*, 114(1), 3–28. https://doi.org/10.1037/0033-2909.114.1.3

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
