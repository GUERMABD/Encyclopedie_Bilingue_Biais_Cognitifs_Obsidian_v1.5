---
type: biais-cognitif
nom_fr: Biais de saillance
nom_en: Salience bias
statut_fr: terme français normalisé; article individuel à vérifier
traduction: traduction française normalisée; existence de l’article à vérifier
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Hypothesis assessment
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: catégorie large d’effets attentionnels et attributifs
robustesse: rôle de la saillance bien établi; étiquette trop large pour une taille d’effet unique
---
# Biais de saillance

> **English:** Salience bias

## Définition — français

Tendance à accorder un poids disproportionné aux éléments les plus visibles, distinctifs ou accessibles dans une situation.

## Definition — English

The tendency to give disproportionate weight to the most visible, distinctive, or accessible elements in a situation.

## Exemple

Dans une discussion, la personne placée face à l’observateur paraît avoir davantage dirigé l’échange.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Capture attentionnelle et accessibilité accrue lors du jugement ou du rappel.

## Mécanisme probable

Capture attentionnelle et accessibilité accrue lors du jugement ou du rappel.

## Analyse critique

La saillance peut signaler une information réellement importante. Le terme couvre plusieurs paradigmes et ne doit pas être utilisé comme explication complète sans préciser ce qui est saillant et pour qui.

**Conclusion de l’audit :** rôle de la saillance bien établi; étiquette trop large pour une taille d’effet unique.

## Comment le limiter ?

Présenter les informations sous un format équilibré et vérifier les données moins visibles avant de conclure.

## Classement

- Nature scientifique : catégorie large d’effets attentionnels et attributifs
- Tâche(s) du classement Wikipédia : Hypothesis assessment
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : terme français normalisé; article individuel à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Salience_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Taylor, S. E., & Fiske, S. T. (1978). Salience, attention, and attribution: Top of the head phenomena. *Advances in Experimental Social Psychology*, 11, 249–288. https://doi.org/10.1016/S0065-2601(08)60009-X

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
