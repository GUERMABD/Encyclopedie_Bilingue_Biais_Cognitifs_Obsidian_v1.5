---
type: biais-cognitif
nom_fr: Cécité à la répétition
nom_en: Repetition blindness
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: limitation perceptive et mnésique de l’individuation des occurrences
robustesse: effet expérimental établi dans des présentations rapides
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
---
# Cécité à la répétition

> **English:** Repetition blindness

## Définition — français

Difficulté à détecter ou rappeler la seconde occurrence d’un élément répété dans une séquence rapide.

## Definition — English

Difficulty detecting or recalling the second occurrence of a repeated item in a rapid sequence.

## Exemple

Dans une phrase brièvement affichée, le second mot identique peut ne pas être rapporté.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Reconnaissance du type sans individuation correcte de chaque occurrence.

## Mécanisme probable

Reconnaissance du type sans individuation correcte de chaque occurrence.

## Analyse critique

L’effet dépend fortement de la vitesse, de la similarité et du format de présentation; ce n’est pas une incapacité générale à voir les répétitions.

**Conclusion de l’audit :** effet expérimental établi dans des présentations rapides.

## Comment le limiter ?

Ralentir la présentation et différencier visuellement les occurrences importantes.

## Classement

- Nature scientifique : limitation perceptive et mnésique de l’individuation des occurrences
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : non recensé
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Repetition_blindness
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Kanwisher, N. G. (1987). Repetition blindness: Type recognition without token individuation. *Cognition*, 27(2), 117–143. https://doi.org/10.1016/0010-0277(87)90016-3

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
