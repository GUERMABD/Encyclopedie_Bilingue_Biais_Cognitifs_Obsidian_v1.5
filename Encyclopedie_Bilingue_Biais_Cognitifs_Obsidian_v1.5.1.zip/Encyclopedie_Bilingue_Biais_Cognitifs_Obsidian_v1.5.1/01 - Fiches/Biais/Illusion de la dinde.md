---
type: metaphore-epistemique
nom_fr: Illusion de la dinde
nom_en: Turkey illusion
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Causal attribution
saveurs_classement_wikipedia:
- Outcome
codex: []
aliases: []
nature_scientifique: métaphore du problème de l’induction et des ruptures de régime
robustesse: illustration conceptuelle, non effet psychologique standardisé
---
# Illusion de la dinde

> **English:** Turkey illusion

## Définition — français

Erreur consistant à extrapoler une tendance stable sans considérer qu’un changement de mécanisme peut l’interrompre brutalement.

## Definition — English

The error of extrapolating a stable trend without considering that a regime change may abruptly end it.

## Exemple

Une dinde nourrie chaque jour croit la sécurité toujours plus probable jusqu’à la veille de son abattage.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Induction à partir d’un historique limité et ignorance du processus générateur.

## Mécanisme probable

Induction à partir d’un historique limité et ignorance du processus générateur.

## Analyse critique

Il s’agit d’une parabole issue de la philosophie de l’induction, pas d’un biais doté d’un protocole de mesure établi.

**Conclusion de l’audit :** illustration conceptuelle, non effet psychologique standardisé.

## Comment le limiter ?

Analyser les causes, scénarios de rupture et données extérieures à la série observée.

## Classement

- Nature scientifique : métaphore du problème de l’induction et des ruptures de régime
- Tâche(s) du classement Wikipédia : Causal attribution
- Sous-catégorie(s) (« flavors ») : Outcome
- Codex : absent
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Turkey_illusion
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Russell, B. (1912). *The Problems of Philosophy*. Williams and Norgate.
- Taleb, N. N. (2007). *The Black Swan*. Random House.

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
