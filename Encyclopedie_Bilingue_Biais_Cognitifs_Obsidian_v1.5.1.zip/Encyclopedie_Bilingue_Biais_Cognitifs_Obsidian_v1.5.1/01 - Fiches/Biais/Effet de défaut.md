---
type: biais-cognitif
nom_fr: Effet de défaut
nom_en: Default effect
statut_fr: traduction de travail; article français à vérifier
traduction: traduction de travail
present_liste_wikipedia_en_2026: true
present_codex_historique: false
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex: []
aliases: []
nature_scientifique: effet d’architecture du choix
robustesse: établie, mécanismes multiples
---
# Effet de défaut

> **English:** Default effect

## Définition — français

Influence de l’option présélectionnée ou appliquée en l’absence de choix explicite sur la décision finale.

## Definition — English

The influence of a preselected option, or the option applied without an active choice, on the final decision.

## Exemple

Le taux d’adhésion change fortement selon que l’inscription à un programme est automatique ou nécessite une démarche volontaire.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Effort de changement, procrastination, interprétation du défaut comme recommandation et préférence pour le statu quo.

## Mécanisme probable

Effort de changement, procrastination, interprétation du défaut comme recommandation et préférence pour le statu quo.

## Analyse critique

L’effet de défaut est largement observé, mais son mécanisme et son ampleur varient. Le défaut ne révèle pas nécessairement la préférence réelle et peut améliorer ou détériorer le bien-être selon sa conception.

**Conclusion de l’audit :** établie, mécanismes multiples.

## Comment le limiter ?

Rendre le défaut visible, expliquer ses conséquences, faciliter le changement et vérifier que l’option par défaut correspond à l’intérêt probable des personnes concernées.

## Classement

- Nature scientifique : effet d’architecture du choix
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : absent du Codex historique
- Statut français : traduction de travail; article français à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Default_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Johnson, E. J., & Goldstein, D. (2003). Do Defaults Save Lives? *Science*, 302(5649), 1338–1339. https://doi.org/10.1126/science.1091721

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
