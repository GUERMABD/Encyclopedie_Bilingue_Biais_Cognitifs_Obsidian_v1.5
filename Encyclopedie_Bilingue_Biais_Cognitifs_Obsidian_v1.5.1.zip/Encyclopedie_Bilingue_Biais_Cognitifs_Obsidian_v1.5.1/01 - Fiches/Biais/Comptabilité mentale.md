---
type: biais-cognitif
nom_fr: Comptabilité mentale
nom_en: Mental accounting
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Manque de sens
aliases: []
nature_scientifique: modèle descriptif de catégorisation des décisions économiques
robustesse: modèle établi ; ce n’est pas un biais unique
---
# Comptabilité mentale

> **English:** Mental accounting

## Définition — français

Modèle décrivant la manière dont les personnes regroupent, codent et évaluent séparément des revenus, dépenses, gains et pertes pourtant fongibles.

## Definition — English

A descriptive model of how people separately code, categorize, and evaluate income, spending, gains, and losses that are economically fungible.

## Exemple

Refuser d’utiliser une épargne affectée aux vacances pour payer une dette coûteuse, alors que l’argent est économiquement interchangeable.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Création de comptes mentaux, budgets catégoriels, évaluation relative à des références et distinction entre utilité d’acquisition et utilité de transaction.

## Mécanisme probable

Création de comptes mentaux, budgets catégoriels, évaluation relative à des références et distinction entre utilité d’acquisition et utilité de transaction.

## Analyse critique

La comptabilité mentale est une théorie descriptive regroupant plusieurs effets, pas une erreur cognitive unique. Les comptes mentaux peuvent parfois aider à la discipline budgétaire ou au contrôle de soi.

**Conclusion de l’audit :** modèle établi ; ce n’est pas un biais unique.

## Comment le limiter ?

Examiner le patrimoine et les flux dans leur ensemble, comparer les taux et coûts réels, puis conserver les catégories uniquement lorsqu’elles servent un objectif explicite.

## Classement

- Nature scientifique : modèle descriptif de catégorisation des décisions économiques
- Tâche(s) du classement Wikipédia : non renseignée dans le classement
- Sous-catégorie(s) (« flavors ») : non renseignée dans le classement
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Mental_accounting
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Thaler, R. (1985). Mental Accounting and Consumer Choice. *Marketing Science*, 4(3), 199–214. https://doi.org/10.1287/mksc.4.3.199

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
