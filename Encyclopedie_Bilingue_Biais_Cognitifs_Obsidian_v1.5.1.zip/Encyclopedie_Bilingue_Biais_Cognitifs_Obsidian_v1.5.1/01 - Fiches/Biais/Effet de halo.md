---
type: biais-cognitif
nom_fr: Effet de halo
nom_en: Halo effect
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia:
- Opinion reporting
saveurs_classement_wikipedia:
- Association
codex:
- Manque de sens
aliases: []
nature_scientifique: biais de jugement et de notation
robustesse: établie mais dépendante de la tâche
---
# Effet de halo

> **English:** Halo effect

## Définition — français

Influence d’une impression générale, ou d’un trait saillant, sur l’évaluation d’autres caractéristiques qui devraient être jugées séparément.

## Definition — English

The influence of an overall impression or a salient trait on ratings of other attributes that should be evaluated independently.

## Exemple

Un candidat jugé très charismatique reçoit aussi de meilleures notes sur sa compétence technique, sans preuve supplémentaire.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Les évaluateurs construisent rapidement une impression globale puis ajustent insuffisamment les jugements particuliers.

## Mécanisme probable

Les évaluateurs construisent rapidement une impression globale puis ajustent insuffisamment les jugements particuliers.

## Analyse critique

Le terme recouvre plusieurs formes de contamination entre jugements. Il ne signifie pas que toute corrélation entre évaluations est erronée : certains traits peuvent réellement être liés.

**Conclusion de l’audit :** établie mais dépendante de la tâche.

## Comment le limiter ?

Noter les critères séparément, utiliser des exemples comportementaux précis et masquer les informations non nécessaires à l’évaluation.

## Classement

- Nature scientifique : biais de jugement et de notation
- Tâche(s) du classement Wikipédia : Opinion reporting
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Manque de sens
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Halo_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Thorndike, E. L. (1920). A Constant Error in Psychological Ratings. *Journal of Applied Psychology*, 4, 25–29. https://doi.org/10.1037/h0071663

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
