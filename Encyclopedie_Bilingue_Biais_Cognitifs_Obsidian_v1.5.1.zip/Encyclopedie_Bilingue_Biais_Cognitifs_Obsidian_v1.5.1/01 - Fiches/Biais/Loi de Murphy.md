---
type: aphorisme
nom_fr: Loi de Murphy
nom_en: Murphy's Law
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: false
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
taches_wikipedia: []
saveurs_classement_wikipedia: []
codex:
- Manque de sens
aliases: []
nature_scientifique: aphorisme sur la possibilité d’échec, souvent utilisé comme rappel de fiabilité
robustesse: aucun effet cognitif autonome standardisé; valeur surtout rhétorique et ingénierique
---
# Loi de Murphy

> **English:** Murphy's Law

## Définition — français

Formule selon laquelle ce qui peut mal tourner finira par mal tourner.

## Definition — English

The aphorism that anything that can go wrong will eventually go wrong.

## Exemple

Une équipe ajoute une protection parce qu’une erreur de branchement reste physiquement possible.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Saillance des défaillances, mémoire sélective et raisonnement de sûreté.

## Mécanisme probable

Saillance des défaillances, mémoire sélective et raisonnement de sûreté.

## Analyse critique

Ce n’est ni une loi probabiliste ni la preuve que tout risque se réalisera. Son utilité tient à l’anticipation des modes de défaillance.

**Conclusion de l’audit :** aucun effet cognitif autonome standardisé; valeur surtout rhétorique et ingénierique.

## Comment le limiter ?

Quantifier probabilité et gravité, puis concevoir des barrières plutôt que raisonner par fatalisme.

## Classement

- Nature scientifique : aphorisme sur la possibilité d’échec, souvent utilisé comme rappel de fiabilité
- Tâche(s) du classement Wikipédia : non repris dans la liste anglaise contrôlée
- Sous-catégorie(s) (« flavors ») : non applicable
- Codex : Manque de sens
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Murphy's_law
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Spark, N. T. (2006). *A History of Murphy’s Law*. Periscope Film.

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
