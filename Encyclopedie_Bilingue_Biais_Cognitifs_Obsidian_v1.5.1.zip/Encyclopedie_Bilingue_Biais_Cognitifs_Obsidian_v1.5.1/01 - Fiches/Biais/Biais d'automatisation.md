---
type: biais-cognitif
nom_fr: Biais d'automatisation
nom_en: Automation bias
statut_fr: présent dans la liste française principale
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: erreur d’interaction humain-automatisation
robustesse: bien documenté dans les systèmes d’aide; dépendant de la fiabilité et de la conception
taches_wikipedia:
- Decision
saveurs_classement_wikipedia:
- Association
codex:
- Manque de sens
aliases: []
---
# Biais d'automatisation

> **English:** Automation bias

## Définition — français

Tendance à accepter une recommandation automatisée ou à négliger une information contradictoire.

## Definition — English

The tendency to accept automated recommendations or overlook contradictory information.

## Exemple

Un opérateur suit une alerte logicielle erronée malgré des indices visibles indiquant le contraire.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Confiance calibrée de manière inadéquate, réduction de vigilance et transfert d’autorité.

## Mécanisme probable

Confiance calibrée de manière inadéquate, réduction de vigilance et transfert d’autorité.

## Analyse critique

Le problème inclut les erreurs de commission et d’omission. Une utilisation rationnelle d’un système fiable n’est pas en soi un biais.

**Conclusion de l’audit :** bien documenté dans les systèmes d’aide; dépendant de la fiabilité et de la conception.

## Comment le limiter ?

Afficher l’incertitude, maintenir une compétence manuelle et imposer une vérification indépendante pour les décisions critiques.

## Classement

- Nature scientifique : erreur d’interaction humain-automatisation
- Tâche(s) du classement Wikipédia : Decision
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Manque de sens
- Statut français : présent dans la liste française principale

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Automation_bias
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Parasuraman, R., & Manzey, D. H. (2010). Complacency and bias in human use of automation. *Human Factors*, 52(3), 381–410. https://doi.org/10.1177/0018720810376055

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
