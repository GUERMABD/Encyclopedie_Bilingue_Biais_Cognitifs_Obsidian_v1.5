---
type: biais-cognitif
nom_fr: Effet Google
nom_en: Google effect
statut_fr: nom français attesté dans le Codex; article à vérifier
traduction: traduction du Codex
present_liste_wikipedia_en_2026: true
present_codex_historique: true
date_verification: '2026-08-01'
exemple_pratique: true
date_exemple_pratique: 2026-08-02
audit_scientifique: initial critique avec références
nature_scientifique: effet de mémoire transactive lié à l’accès externe à l’information
robustesse: résultat fondateur documenté; généralisations à une dégradation globale de la mémoire non justifiées
taches_wikipedia:
- Recall
saveurs_classement_wikipedia:
- Association
codex:
- Limites de la mémoire
aliases: []
---
# Effet Google

> **English:** Google effect

## Définition — français

Tendance à mieux mémoriser où retrouver une information que l’information elle-même lorsqu’un accès externe est attendu.

## Definition — English

The tendency to remember where information can be found rather than the information itself when external access is expected.

## Exemple

Une personne retient le dossier ou le moteur de recherche permettant de retrouver un fait, mais moins bien le fait.

**Ce que cela illustre :** le mécanisme en jeu est le suivant : Répartition de la mémoire entre la personne et une ressource externe.

## Mécanisme probable

Répartition de la mémoire entre la personne et une ressource externe.

## Analyse critique

L’étude fondatrice ne montre pas qu’Internet détruit globalement la mémoire. Elle décrit une adaptation de ce qui est encodé lorsque l’accès futur est anticipé.

**Conclusion de l’audit :** résultat fondateur documenté; généralisations à une dégradation globale de la mémoire non justifiées.

## Comment le limiter ?

Mémoriser directement les connaissances fondamentales et externaliser surtout les détails retrouvables.

## Classement

- Nature scientifique : effet de mémoire transactive lié à l’accès externe à l’information
- Tâche(s) du classement Wikipédia : Recall
- Sous-catégorie(s) (« flavors ») : Association
- Codex : Limites de la mémoire
- Statut français : nom français attesté dans le Codex; article à vérifier

## Articles Wikipédia

- Anglais : https://en.wikipedia.org/wiki/Google_effect
- Français : aucune page individuelle validée dans cette édition ; résolution prévue via Wikidata.

## Références scientifiques contrôlées

- Sparrow, B., Liu, J., & Wegner, D. M. (2011). Google effects on memory: Cognitive consequences of having information at our fingertips. *Science*, 333(6043), 776–778. https://doi.org/10.1126/science.1207745

## Sources et attribution

- Audit documentaire effectué le 2026-08-01.
- Les références ci-dessus soutiennent la définition et la conclusion critique de cette fiche ; elles ne constituent pas une revue systématique exhaustive.
- L’appartenance à la liste Wikipédia ou au Codex ne constitue pas une validation scientifique.
- Tout texte importé doit conserver le titre résolu, l’URL, le numéro de révision, la date de récupération, la licence et la mention des transformations.
- Chaque média Wikimedia conserve sa propre attribution et sa propre licence.
