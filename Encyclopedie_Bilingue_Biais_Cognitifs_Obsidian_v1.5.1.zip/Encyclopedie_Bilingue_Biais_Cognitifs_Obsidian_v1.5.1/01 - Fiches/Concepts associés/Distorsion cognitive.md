---
type: concept
date_verification: 2026-08-01
exemple_pratique: true
date_exemple_pratique: 2026-08-02
---

# Distorsion cognitive

Pensée récurrente et déformée, notamment étudiée en psychologie clinique. Le terme recoupe partiellement les biais cognitifs sans leur être équivalent.

## Exemple concret

Après avoir échoué à un examen, un étudiant conclut : « Je rate toujours tout ». Il transforme un événement précis en jugement général, malgré plusieurs réussites récentes.

**Ce que cela illustre :** La pensée ne se contente pas de décrire l’échec : elle l’agrandit et l’étend à toute l’identité de la personne.

## Liens

- [[00 - Accueil]]
- [[06 - Légende critique]]
