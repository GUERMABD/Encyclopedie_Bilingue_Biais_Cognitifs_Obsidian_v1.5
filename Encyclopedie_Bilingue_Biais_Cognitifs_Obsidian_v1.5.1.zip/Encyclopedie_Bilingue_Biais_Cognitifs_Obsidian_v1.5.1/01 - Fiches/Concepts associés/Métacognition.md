---
type: concept
date_verification: 2026-08-01
exemple_pratique: true
date_exemple_pratique: 2026-08-02
---

# Métacognition

Capacité à observer et évaluer ses propres processus mentaux. Elle aide au contrôle, mais l'introspection seule ne suffit pas à éliminer les biais.

## Exemple concret

Une étudiante pense connaître son cours parce que la relecture lui paraît facile. Elle ferme ensuite ses notes et tente de restituer le plan de mémoire ; les oublis lui montrent que son sentiment de maîtrise était trop optimiste.

**Ce que cela illustre :** La métacognition consiste ici à évaluer son propre apprentissage à l’aide d’un test plutôt qu’à se fier uniquement à une impression.

## Liens

- [[00 - Accueil]]
- [[06 - Légende critique]]
