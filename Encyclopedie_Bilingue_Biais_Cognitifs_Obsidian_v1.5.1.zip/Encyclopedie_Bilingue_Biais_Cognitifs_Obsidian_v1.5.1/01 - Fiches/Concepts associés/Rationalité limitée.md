---
type: concept
date_verification: 2026-08-01
exemple_pratique: true
date_exemple_pratique: 2026-08-02
---

# Rationalité limitée

Idée selon laquelle les décisions sont contraintes par le temps, l'information disponible et les capacités de calcul.

## Exemple concret

Pour choisir une assurance avant une échéance, une personne compare trois offres accessibles, vérifie les garanties essentielles puis retient la première solution satisfaisante. Elle ne recherche pas l’option théoriquement parfaite parmi toutes les offres du marché.

**Ce que cela illustre :** La décision est adaptée aux limites de temps, d’information et de calcul ; elle n’est pas nécessairement irrationnelle.

## Liens

- [[00 - Accueil]]
- [[06 - Légende critique]]
