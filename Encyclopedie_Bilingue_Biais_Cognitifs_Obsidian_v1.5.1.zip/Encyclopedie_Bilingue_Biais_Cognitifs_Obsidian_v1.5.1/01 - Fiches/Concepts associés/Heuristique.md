---
type: concept
date_verification: 2026-08-01
exemple_pratique: true
date_exemple_pratique: 2026-08-02
---

# Heuristique

Raccourci cognitif permettant une décision rapide avec une information ou un temps limité. Une heuristique peut être adaptée sans être systématiquement biaisée.

## Exemple concret

Dans une gare inconnue, une personne suit le flux principal de voyageurs pour trouver la sortie. Ce raccourci fonctionne souvent et permet d’agir vite, mais il peut échouer si la foule se dirige vers un quai particulier.

**Ce que cela illustre :** Une heuristique est une règle pratique : utile dans de nombreux cas, sans garantir la bonne réponse dans chaque situation.

## Liens

- [[00 - Accueil]]
- [[06 - Légende critique]]
