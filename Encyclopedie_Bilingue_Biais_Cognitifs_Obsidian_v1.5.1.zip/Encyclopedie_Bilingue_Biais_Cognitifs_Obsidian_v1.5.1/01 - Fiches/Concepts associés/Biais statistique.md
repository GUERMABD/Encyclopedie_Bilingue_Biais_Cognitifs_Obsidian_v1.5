---
type: concept
date_verification: 2026-08-01
exemple_pratique: true
date_exemple_pratique: 2026-08-02
---

# Biais statistique

Écart systématique introduit par la méthode d'échantillonnage, de mesure ou d'estimation. Il ne doit pas être confondu avec un biais cognitif individuel.

## Exemple concret

Une enquête sur la satisfaction d’un service est envoyée uniquement aux utilisateurs qui ouvrent régulièrement l’application. Les personnes ayant abandonné le service ne répondent jamais ; le résultat surestime donc la satisfaction de l’ensemble des clients.

**Ce que cela illustre :** L’erreur vient ici de la méthode d’échantillonnage, même si chaque répondant répond honnêtement.

## Liens

- [[00 - Accueil]]
- [[06 - Légende critique]]
