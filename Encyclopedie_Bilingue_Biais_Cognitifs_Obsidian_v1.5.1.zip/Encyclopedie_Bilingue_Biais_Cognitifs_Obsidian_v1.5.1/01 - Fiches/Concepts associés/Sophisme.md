---
type: concept
date_verification: 2026-08-01
exemple_pratique: true
date_exemple_pratique: 2026-08-02
---

# Sophisme

Raisonnement invalide ou trompeur. Un sophisme décrit une structure argumentative ; un biais cognitif décrit plutôt une tendance psychologique.

## Exemple concret

Quelqu’un affirme : « Depuis que la nouvelle direction est arrivée, les ventes ont baissé ; la direction a donc causé la baisse ». La succession temporelle est utilisée comme preuve de causalité, sans examiner la saison, les prix ou la concurrence.

**Ce que cela illustre :** Le problème se situe dans la structure du raisonnement : la conclusion ne découle pas suffisamment des prémisses.

## Liens

- [[00 - Accueil]]
- [[06 - Légende critique]]
