---
type: concept
date_verification: 2026-08-01
exemple_pratique: true
date_exemple_pratique: 2026-08-02
---

# Débiaisement

Ensemble des méthodes destinées à réduire les erreurs systématiques de jugement. L'efficacité dépend du biais, du contexte et de la procédure.

## Exemple concret

Avant une réunion d’estimation, chaque membre chiffre seul la durée du projet et note ses hypothèses. Les estimations ne sont mises en commun qu’ensuite. Cette procédure limite l’ancrage sur la première personne qui parle et oblige chacun à expliciter son raisonnement.

**Ce que cela illustre :** Le débiaisement ne consiste pas à devenir parfaitement objectif : il modifie la procédure de décision pour réduire une erreur prévisible.

## Liens

- [[00 - Accueil]]
- [[06 - Légende critique]]
